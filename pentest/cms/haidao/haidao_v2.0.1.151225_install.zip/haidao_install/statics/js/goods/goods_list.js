var list_action = (function() {
	return{
		change_status : function(url,id,row){
			$.post(url,{id:id},function(data){
				if(data.status == 1){
					if(!row.hasClass("cancel")){
						row.addClass("cancel");
						row.attr("title","点击关闭");
					}else{
						row.removeClass("cancel");
						row.attr("title","点击开启");
					}
				}else{
					return false;
				}
			},'json');
		},
		change_name : function(url,id,name){
			$.post(url,{id:id,name:name},function(data){
				if(data.status == 1){
					return true;
				}else{
					return false;
			    }
			},'json');
		},
		change_sort : function(url,id,sort){
			$.post(url,{id:id,sort:sort},function(data){
				if(data.status == 1){
				return true;
				}else{
					return false;
				}
			},'json');
		}
	};
})()