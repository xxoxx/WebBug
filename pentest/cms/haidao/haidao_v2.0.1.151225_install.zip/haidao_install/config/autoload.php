<?php
$_autoload = array();
$_autoload['config'] = 'database,template';
$_autoload['library'] = '';
$_autoload['function'] = '';