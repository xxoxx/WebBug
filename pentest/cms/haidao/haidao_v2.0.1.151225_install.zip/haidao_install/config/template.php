<?php

/**
 * [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 * 
 * This is NOT a freeware, use is subject to license terms
 * 
 * 
 * http://www.haidao.la
 * tel:400-600-2042
 */

/**
 * 模板配置配置文件
 */

return array(

	'TPL_THEME'                     => 'default',
	'TPL_SUFFIX'                    => '.html',
	'TAGLIB_BEGIN'                  => '{',
	'taglib_end'                    => '}',
	'taglib_name'                   => 'hd',
	'taglib_cache'                  => 3600,

);