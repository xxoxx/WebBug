<?php
if(!defined('HD_VERSION')) {
	define('HD_VERSION', '2.0.1.151225');
	define('HD_RELEASE', '20151225');
	define('HD_BRANCH', 'develop');
	define('HD_FIXBUG', '00000001');
}