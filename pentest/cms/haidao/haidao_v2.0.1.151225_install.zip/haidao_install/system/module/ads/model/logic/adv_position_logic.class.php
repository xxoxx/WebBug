<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class adv_position_logic extends logic {
	public function __construct() {
		$this->model = model('ads/adv_position');
	}

	public function getdetail($params = array()) {
		$data = array();
		$map = array();
		$map['status'] = array('EQ', 1);
		$map['id'] = array('EQ', $params['position']);

		if (array_key_exists("order", $params)) {
			$order = $params['order'];
		}
		if (array_key_exists("limit", $params)) {
			$limit = $params['limit'];
		}
		//广告位
		$data = $this->model->where($map)->find();
		//广告明细
		unset($map);
		$map['starttime'] = array("LT", time());
		$map['endtime'] = array("GT", time());
		$map['status'] = array('EQ', 1);
		$map['position_id'] = array('EQ', $params['position']);
		$data['list'] = model('adv')->where($map)->limit($limit)->order($order)->select();
		return dstripslashes($data);
	}

}
