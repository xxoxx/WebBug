<?php
/**
 *      广告位设置服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class adv_position_service extends service {
		
	protected $count;
    protected $pages;
	
	public function __construct() {
		$this->model = model('adv_position','table');
	}
	/**
     * 获广告位列表
     * @param type $sqlmap
     * @return type
     */
    public function getposition($sqlmap = array()) {
        $advs = $this->model->where($sqlmap)->select();
		return $advs;
    }
	/**
     * 查询单个信息
     * @param int $id 主键ID
     * @param string $field 被查询字段
     * @return mixed
     */
    public function fetch_by_id($id, $field = NULL) {
        $r = $this->model->find($id);
        if(!$r) return FALSE;
        return ($field !== NULL) ? $r[$field] : $r;
    }

	/**
	 * [更新广告位]
	 * @param array $data 数据
	 * @param bool $valid 是否M验证
	 * @return bool
	 */
	public function save($data, $valid = TRUE) {
		$result = $this->model->update($data, $valid);
		return $result;
	}
	/**
	 * [启用禁用广告位]
	 * @param string $id 支付方式标识
	 * @return TRUE OR ERROR
	 */
	public function change_status($id) {
		$result = $this->model->where(array('id' => $id))->save(array('status' => array('exp', '1-status')));
		if ($result == 1) {
			$result = TRUE;
		} else {
			$result = $this->model->getError();
		}
		return $result;
	}

}
