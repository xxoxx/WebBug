<?php
return array(
	'_UPDATE_ADV_SUCCESS_' => '设置广告成功',
	'_UPDATE__ADV_ERROR_' => '设置广告失败',
	'_DEL_ADV_SUCCESS_' => '删除广告成功' ,
	'_STATUS_SUCCESS_' => '改变状态成功' ,
	'_STATUS_ERROR_' => '改变状态失败' ,
	'_DEL_ADV_POSITION_SUCCESS_' => '删除广告位成功' ,
	'_UPDATE_ADV_POSITION_SUCCESS_' => '更新广告位成功' ,
	'_NO_ADVPOSITION_'=>'请先添加广告位',
);