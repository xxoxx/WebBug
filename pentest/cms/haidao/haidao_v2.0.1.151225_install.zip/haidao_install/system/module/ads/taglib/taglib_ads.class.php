<?php
class taglib_ads{
	public function __construct() {
		$this->logic = model('ads/adv_position','logic');
	}

	public function lists($sqlmap = array(), $options = array()) {
		return $this->logic->getdetail(array_merge($sqlmap,$options));
	}
};