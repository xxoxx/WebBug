<?php
/**
 *		文章服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class article_service extends service {
	public function __construct() {
		$this->logic = model('article','logic');
		$this->db = model('article','table');
	}
	/**
	 * [add 添加文章]
	 * @param [array] $params [文章信息]
	 * @return [boolean]         [返回添加结果]
	 */
	public function add($params){
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑文章]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function edit($params){
		$result = $this->logic->edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [delete 删除文章]
	 * @param [array] $params [文章信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function delete($params){
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_article_by_id 根据id获取文章信息]
	 * @param  [type] $id [文章id]
	 * @return [type]     [description]
	 */
	public function get_article_by_id($id){
		$result = $this->logic->get_article_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [ajax_edit 改变标题]
	 * @param  [array] $params [文章id和title]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_edit($id,$type){
		$result = $this->logic->ajax_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	* [fieldinc 增加字段值]
	* @param integer $id    id
	* @return [boolean]     [返回更改结果]
	*/
	public function hits($id){
		return $this->db->where(array('id' => $id))->setInc('hits');
	}
}