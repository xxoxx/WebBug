<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class friendlink_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->service = model('friendlink','service');
		helper('attachment');
	}
	/**
	 * [index 列表]
	 */
	public function index(){
		$sqlmap = array();
		$_GET['limit'] = isset($_GET['limit']) ? $_GET['limit'] : 10;
		$friendlink = model('friendlink')->where($sqlmap)->page($_GET['page'])->limit($_GET['limit'])->order("sort DESC")->select();
        $count = model('friendlink')->where($sqlmap)->count();
        $pages = $this->admin_pages($count, $_GET['limit']);
		include $this->admin_tpl('friendlink_index');
	}
	/**
	 * [add 添加]
	 */
	public function add(){
		if(checksubmit('dosubmit')){
			if(!empty($_FILES['logo']['name'])) {
				$code = attachment_init(array('path'=>'friendlink','mid'=>$this->admin['id'],'allow_exts'=>array('bmp','jpg','png','jpeg','gif')));
				$_GET['logo'] = model('attachment/attachment', 'service')->setConfig($code)->upload('logo');
				if(!$_GET['logo']){
					showmessage(model('attachment/attachment', 'service')->error);
				}
				model('attachment/attachment', 'service')->attachment($_GET['logo'],$info['logo']);
			}
			$result = $this->service->add($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功','','1');
			}
		}else{
			include $this->admin_tpl('friendlink_edit');
		}
	}
	/**
	 * [edit 编辑]
	 */
	public function edit(){
		$info = $this->service->get_friendlink_by_id($_GET['id']);
		if(checksubmit('dosubmit')){
			if(!empty($_FILES['logo']['name'])) {
				$code = attachment_init(array('path'=>'friendlink','mid'=>$this->admin['id'],'allow_exts'=>array('bmp','gif','jpg','jpeg','png')));
				$_GET['logo'] = model('attachment/attachment', 'service')->setConfig($code)->upload('logo');
				if(!$_GET['logo']){
					showmessage(model('attachment/attachment', 'service')->error);
				}
				model('attachment/attachment', 'service')->attachment($_GET['logo'],$info['logo']);
			}
			$result = $this->service->edit($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功','','1');
			}
		}else{
			include $this->admin_tpl('friendlink_edit');
		}
	}
	/**
	 * [delete 删除]
	 */
	public function delete(){
		$result = $this->service->delete($_GET);
		if(!$result){
			showmessage($this->service->error);
		}
		showmessage('操作成功',url('misc/friendlink/index'),'1');
	}
	/**
	 * [ajax_edit ajax编辑]
 	 */
	public function ajax_edit(){
		$result = $this->service->ajax_edit($_GET);
		$this->ajaxReturn($result);
	}
}