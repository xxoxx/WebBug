<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class navigation_control extends init_control {
	protected $service = '';
	public function _initialize() {
		parent::_initialize();
		$this->service = model('navigation','service');
	}
	/**
	 * [index 文章列表]
 	 */
	public function index(){
		$navigation = $this->service->lists(array('order'=>'sort ASC'));
		include $this->admin_tpl('navigation_index');
	}
	/**
	 * [add 添加]
 	 */
	public function add(){
		if(checksubmit('dosubmit')){
			$result = $this->service->add($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功','','1');
			}
		}else{
			include $this->admin_tpl('navigation_edit');
		}		
	}
	/**
	 * [ajax_edit ajax编辑]
	 */
	public function ajax_edit(){
		$result = $this->service->ajax_edit($_GET);
		$this->ajaxReturn($result);
	}
	/**
	 * [edit 编辑]
	 */
	public function edit(){
		if(checksubmit('dosubmit')){
			$result = $this->service->edit($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功','','1');
			}
		}else{
			$info = $this->service->get_navigation_by_id($_GET['id']);
			include $this->admin_tpl('navigation_edit');
		}
	}
	/**
	 * [delete 删除]
	 */
	public function delete(){
		$result = $this->service->delete($_GET);
		if(!$result){
			showmessage($this->service->error);
		}
		showmessage('操作成功',url('misc/navigation/index'),'1');
	}
}