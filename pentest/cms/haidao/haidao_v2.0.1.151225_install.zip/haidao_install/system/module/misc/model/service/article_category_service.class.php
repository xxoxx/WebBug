<?php
/**
 *		文章分类服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class article_category_service extends service {
	public function __construct() {
		$this->logic = model('article_category','logic');
	}
	/**
	 * [get_category_by_id 根据id获取文章分类信息]
	 * @param  [type] $id [description]
	 * @field  [srting] 字段
 	 * @return [type]     [description]
	 */
	public function get_category_by_id($id,$field){
		$result = $this->logic->get_category_by_id($id,$field);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑分类]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function edit($params){
		$result = $this->logic->edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [delete_category 删除分类]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function delete($params){
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_category_tree 获取文章分类树]
	 * @return [type] [description]
	 */
	public function get_category_tree(){		
		$result = $this->logic->get_category_tree();
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [add_category 增加分类]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回添加结果]
	 */
	public function add($params){
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [ajax_category ajax获取分类]
	 */
	public function ajax_son_class($params){
		$result = $this->logic->ajax_son_class($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [change_name 编辑分类名称]
 	 */
	public function ajax_edit($params){
		$result = $this->logic->ajax_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_category_by 获取一条分类信息]
 	 */
	public function get_category_by($id,$type){
		$id = (int)$id;
		if($id < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		$data = array();
		$data['id'] = array('eq',$id);
		$row = model('article_category')->where($data)->find();
		if($type){
			return $row[$type];
		}
		return $row;
	}
}