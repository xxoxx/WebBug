<?php
/**
 *		友情链接服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class friendlink_service extends service {
	public function __construct() {
		$this->logic = model('friendlink','logic');
	}
	/**
	 * [add 添加友链]
	 * @params [array] [传输添加数据]
	 * @return [type] [description]
	 */
	public function add($params){	
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_friendlink_by_id 查询某条数据]
	 * @params [array] [传输添加数据]
	 * @return [type] [description]
	 */
	public function get_friendlink_by_id($id){	
		$result = $this->logic->get_friendlink_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑]
	 * @params [array] [传输数据]
	 * @return [type] [description]
	 */
	public function edit($params){	
		$result = $this->logic->edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [ajax_edit 编辑]
	 * @params [array] [传输数据]
	 * @return [type] [description]
	 */
	public function ajax_edit($params){	
		$result = $this->logic->ajax_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [delete 删除]
	 * @params [array] [传输数组]
	 * @return [type] [description]
	 */
	public function delete($params){	
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
}