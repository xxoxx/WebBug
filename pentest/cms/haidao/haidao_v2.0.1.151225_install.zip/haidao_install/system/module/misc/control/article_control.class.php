<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class article_control extends init_control {
	protected $service = '';
	public function _initialize() {
		parent::_initialize();
		$this->service = model('article', 'service');
		$this->category_service = model('article_category','service');
		helper('attachment');
	}
	/**
	 * [index 文章列表]
 	 */
	public function index(){
		$sqlmap = array();
		$_GET['limit'] = isset($_GET['limit']) ? $_GET['limit'] : 10;
		$article = model('article')->where($sqlmap)->page($_GET['page'])->limit($_GET['limit'])->order("sort DESC")->select();
		foreach($article as $key => $value){
		   $article[$key]['category'] = model('article_category')->where(array('id' =>array('eq',$value['category_id'])))->getField('name');
		   $article[$key]['dataline'] = date('Y-m-d H:i:s',$value['dataline']);
	    }
        $count = model('article')->where($sqlmap)->count();
        $pages = $this->admin_pages($count, $_GET['limit']);
		include $this->admin_tpl('article_index');
	}
	/**
	 * [article_category_choose 选择框]
 	 */
	public function article_category_choose(){
		$category = $this->category_service->get_category_tree();
		include $this->admin_tpl('article_category_choose');
	}
	/**
	 * [add 添加文章]
 	 */
	public function add(){
		if(checksubmit('dosubmit')){
			if(!empty($_FILES['thumb']['name'])) {
				$code = attachment_init(array('path'=>'article','mid'=>$this->admin['id'],'allow_exts'=>array('bmp','jpg','jpeg','gif','png')));
				$_GET['thumb'] = model('attachment/attachment', 'service')->setConfig($code)->upload('thumb');
				if(!$_GET['thumb']){
					showmessage(model('attachment/attachment', 'service')->error);
				}
				model('attachment/attachment', 'service')->attachment($_GET['thumb'], $info['thumb']);
			}
			$result = $this->service->add($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功',url('index'));
			}
		}else{
			include $this->admin_tpl('article_edit');
		}
	}
	/**
	 * [edit 编辑文章]
 	 */
	public function edit(){
		$info = $this->service->get_article_by_id($_GET['id']);
		if(checksubmit('dosubmit')){
			if(!empty($_FILES['thumb']['name'])) {
				$code = attachment_init(array('path'=>'article','mid'=>$this->admin['id'],'allow_exts'=>array('bmp','jpg','jpeg','gif','png')));
				$_GET['thumb'] = model('attachment/attachment', 'service')->setConfig($code)->upload('thumb');
				if(!$_GET['thumb']){
					showmessage(model('attachment/attachment', 'service')->error);
				}
				model('attachment/attachment', 'service')->attachment($_GET['thumb'], $info['thumb']);
			}
			$result = $this->service->edit($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功',url('index'));
			}
		}else{
			include $this->admin_tpl('article_edit');
		}
	}
	/**
	 * [delete 删除文章]
 	 */
	public function delete(){
		$result = $this->service->delete($_GET);
		if(!$result){
			showmessage($this->service->error);
		}
		showmessage('操作成功',url('misc/article/index'),1);
	}
	/**
	 * [ajax_edit 编辑文章]
 	 */
	public function ajax_edit(){
		$result = $this->service->ajax_edit($_GET);
		$this->ajaxReturn($result);
	}
}