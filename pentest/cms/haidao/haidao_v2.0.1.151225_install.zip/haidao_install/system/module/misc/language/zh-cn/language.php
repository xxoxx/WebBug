<?php
return array(
    'USERNAME_NOT_EXIST' => '用户名不能为空',
    'PASSWORD_NOT_EXIST' => '密码不能为空',
    'ADMIN_USER_NOT_EXIST' => '账号不存在',
    'PASSWORD_CHECKED_ERROR' => '登陆密码验证失败',
    'NO_LOGIN' => '尚未登录或已过期',
);
