<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class help_control extends init_control {
	protected $service = '';
	public function _initialize() {
		parent::_initialize();
		$this->service = model('help','service');
	}
	/**
	 * [index 帮助列表]
	 */
	public function index(){
		$help = $this->service->get_index();
		include $this->admin_tpl('help_index');
	}
	/**
	 * [edit 编辑主题]
 	 */
	public function edit(){
		if(checksubmit('dosubmit')){
			$result = $this->service->edit($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage('操作成功','','1');
			}
		}else{
			$info = $this->service->get_help_by_id($_GET['id']);
			if($info['parent_id'] == 0){
				include $this->admin_tpl('help_edit_top');
			}else{
				$parent = $this->service->get_parents();
				include $this->admin_tpl('help_edit_son');
			}
		}
	}
	/**
	 * [delete 删除文章]
 	 */
	public function delete(){
		$result = $this->service->delete($_GET);
		if(!$result){
			showmessage($this->service->error);
		}
		showmessage('操作成功',url('misc/help/index'),'1');
	}
	/**
	 * [batch 批量添加]
 	 */
	public function batch(){
		$result = $this->service->batch($_GET);
		if(!$result){
			showmessage($this->service->error);
		}else{
			showmessage('操作成功',url('index'),'1');
		}
	}
	public function ajax_edit(){
		 $result = $this->service->ajax_edit($_GET);
		 $this->ajaxReturn($result);
	 }
}