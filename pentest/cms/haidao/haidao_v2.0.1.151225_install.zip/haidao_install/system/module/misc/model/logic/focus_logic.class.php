<?php
/**
 *		幻灯片逻辑层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class focus_logic extends logic {
	public function __construct() {
		$this->db = model('focus');	
		$this->article_logic = model('article','logic');	
	}
	/**
	 * [lists 列表]
	 * @return [type] [description]
	 */
	public function lists(){
		$result = $this->db->select();
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return $result;
	}
		/**
	 * [add 添加]
	 * @return [type] [description]
	 */
	public function add($params){
		$data = array();
		$data['title'] = $params['title'];
		$data['thumb'] = $params['thumb'] ? $params['thumb']: '';
		$data['url'] = $params['url'];
		$data['target'] = $params['target'];
		$data['sort'] = $params['sort'];
		$result = $this->db->update($data);
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_focus_by_id 查询某条数据]
	 * @id [number] 传入的id
	 * @return [type] [description]
	 */
	public function get_focus_by_id($id){
		if((int)$id < 1){
			$this->error = '幻灯片不存在';
			return FALSE;
		}
		$result = $this->db->find($id);
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑]
	 * @return [type] [description]
	 */
	public function edit($params){
		if(!isset($params['id'])){
			$this->error = '幻灯片不存在';
			return FALSE;
		}
		$data = array();
		$data['id'] = $params['id'];
		$data['title'] = $params['title'];
		$data['url'] = $params['url'];
		$data['target'] = $params['target'];
		if($params['thumb']){
			$data['thumb'] = $params['thumb'];
		}
		$data['url'] = $params['url'];
		$data['sort'] = $params['sort'];
		$result = $this->db->update($data);
		if($result === FALSE){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
	}
	/**
	 * [delete 删除]
	 * @return [type] [description]
	 */
	public function delete($params){
		if(!$this->article_logic->is_array_null($params)){
			$this->error = '幻灯片不存在';
			return FALSE;
		}
		$data = array();
		$data['id'] = array('IN', explode(',',$params['id'][0]));
		$result = $this->db->where($data)->delete();
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return $result;
	}
		/**
	 * [ajax_edit 编辑]
	 * @return [type] [description]
	 */
	public function ajax_edit($params){
		if(!isset($params['id'])){
			$this->error = '幻灯片不存在';
			return FALSE;
		}
		$result = $this->db->update($this->article_logic->assembl_array($params));
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return $result;
	}
	/**
	 * [total 总记录数]
	 * @return [type]     [返回查询结果结果]
	 */
	public function total(){		
		$result = $this->db->count;
		if(!$result){
    		$this->error = $this->db->getError();
    		return FALSE;
    	}
		return $result;
	}
}