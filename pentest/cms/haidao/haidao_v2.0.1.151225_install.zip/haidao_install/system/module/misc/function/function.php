<?php
/**
 * 		文章公共函数
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
	/**
	 * [crumbs 文章模块下的面包屑导航]
	 * @param  [type] $id  [description]
	 * @param  [type] $type  [文章列表]
	 * @return [type]         [description]
	 */
	function crumbs($id,$type) {
		$symbol = " > ";
		if($type){
			$category = model('misc/article_category','service')->get_category_by_id($id);
			$category_id = array_reverse(array_unique($category['category_id']));
			$category['category'] = explode(">",$category['parent']);
		}else{
			$category = model('misc/article','service')->get_article_by_id($id);
			$category_id = array_reverse(array_unique($category['category_ids']));
			$category['category'] = explode(">",$category['category']);
		}
		foreach($category['category'] as $k => $v){
			$url = url('misc/index/article_lists', array('category_id' =>$category_id[$k]));
			$pos .= "<a href=".$url.">".$v."</a><em>".$symbol."</em>";
		}
		$pos = substr($pos,0,strlen($pos)-8);
		return $pos;
	}