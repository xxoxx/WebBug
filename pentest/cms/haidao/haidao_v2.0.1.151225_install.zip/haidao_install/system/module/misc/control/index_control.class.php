<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'goods');
class index_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->category = model('article_category','service');
		$this->article = model('article','service');
	}
	/**
	 * [help_lists 前台帮助列表]
	 */
	public function help_lists($id){
		$id = (int) $_GET['id'];
		$row = model('help','service')->get_help_by_id($id);
		if(!$row)
			showmessage('参数错误');
		extract($row);
		$SEO = seo($title.' - 帮助中心');
		include template('help_lists');
	}
	/**
	 * [article_lists 文章列表]
	 */
	public function article_lists(){
		$title = $this->category->get_category_by($_GET['category_id'],'name');
		$SEO = seo($title.' - 文章列表');
		include template('article_lists');
	}
	/**
	 * [article_detail 文章详情页]
	 */
	public function article_detail(){
		$id = (int) $_GET['id'];
		$row = $this->article->get_article_by_id($id);
		if(!$row) 
			showmessage('文章不存在');
		$this->article->hits($id);
		$row['hits'] += 1;
		extract($row);
		$SEO = seo($title.' - 文章详情',$keywords);
		include template('article_detail');
	}
}