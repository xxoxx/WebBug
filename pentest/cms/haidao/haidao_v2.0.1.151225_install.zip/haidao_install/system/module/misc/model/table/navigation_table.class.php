<?php
/**
 *	    友情链接数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class navigation_table extends table {
    protected $_validate = array(
        array('name','require','文章名称必须存在',0),
		array('sort','number','排序必须为数字',2),
    );
    protected $_auto = array(
    	array('sort','100'),
    );
}