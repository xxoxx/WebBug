<?php
/**
 *		导航服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class navigation_service extends service {
	public function __construct() {
		$this->logic = model('misc/navigation','logic');
	}
	/**
	 * [lists 列表]
	 * @return [type] [description]
	 */
	public function lists($sqlmap = array(),$options = array()){
		$result = $this->logic->lists($sqlmap,$options);
		if(!$result){
			$this->error = $this->logic->error;
			return false;
		}
		return $result;
	}
	/**
	 * [add 添加]
	 * @params [array] [传输添加数据]
	 * @return [type] [description]
	 */
	public function add($params){	
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [ajax_edit 编辑]
	 * @params [array] [传输添加数据]
	 * @return [type] [description]
	 */
	public function ajax_edit($params){	
		$result = $this->logic->ajax_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑]
	 * @params [array] [传输数据]
	 * @return [type] [description]
	 */
	public function edit($params){	
		$result = $this->logic->edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_navigation_by_id 导航查询]
	 * @params [array] [传输添加数据]
	 * @return [type] [description]
	 */
	public function get_navigation_by_id($id){	
		$result = $this->logic->get_navigation_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [delete 删除]
	 * @params [array] [传输数组]
	 * @return [type] [description]
	 */
	public function delete($params){	
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
}