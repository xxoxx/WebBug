<?php
/**
 *		帮助服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class help_service extends service {
	public function __construct() {
		$this->logic = model('help','logic');
	}
	/**
	 * [get_index 获取文章列表]
	 * @return [type] [description]
	 */
	public function get_index(){	
		$result = $this->logic->get_index();
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [change_title 编辑文章]
	 * @param  [array] $params [帮助文章id和名称数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_edit($params){
		$result = $this->logic->ajax_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [edit 编辑文章]
	 * @param  [array] $params [帮助文章id和名称数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function edit($params){
		$result = $this->logic->edit($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [ajax_add 添加主题]
	 * @param  [array] $params [文章id和名称数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_add($params){
		$result = $this->logic->ajax_add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_help_by_id 根据id获取文章信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_help_by_id($id){
		$result = $this->logic->get_help_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [delete 删除文章]
	 * @param [array] $params [文章信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function delete($params){
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_parents 获取所有的父分类]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function get_parents(){
		$result = $this->logic->get_parents();
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [batch 获取所有的父分类]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function batch($params){
		$result = $this->logic->batch($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
}