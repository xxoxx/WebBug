<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class comment_service extends service
{
	protected $sqlmap = array();

	public function __construct() {
		$this->table = model('comment/comment', 'table');
		$this->goods = model('order/order_sku', 'service');
	}

	public function lists($sqlmap = array(), $limit = 20, $order = 'id DESC', $page = 1) {
		$this->sqlmap = array_merge($this->sqlmap, $sqlmap);
		$DB = $this->table->where($this->sqlmap);
		$lists = &$DB->page($page)->limit($limit)->order($order)->select();
		$count = $this->table->where($this->sqlmap)->count();
        foreach ($lists as $key => $value) {
            $sku = model('goods/goods_sku', 'service')->goods_detail($value['sku_id']);
            $value['username'] = cut_str($value['username'], 1, 0).'**'.cut_str($value['username'], 1, -1);
            if($sku === false) continue;
            $value['imgs'] = ($value['imgs']) ? json_decode($value['imgs']) : array();
        	$value['_sku'] = $sku;
        	$value['_datetime'] = date('Y-m-d', $value['datetime']);
        	$lists[$key] = $value;
        }
        return array('count' => $count, 'lists' => $lists);
	}

	public function get($id) {
		return $this->table->find($id);
	}

	public function add($params) {
		$r = $this->goods->detail((int) $params['tid']);
		if($r === false) {
			$this->error = $this->goods->error;
			return false;
		}
		/* 是否评论过 */
		if($params['mid'] < 1 || $params['mid'] != $r['buyer_id']) {
			$this->error = '没有权限';
			return false;
		}
		if($r['iscomment'] == 1) {
			$this->error = '请勿重复发表';
			return false;
		}
		$params['spu_id'] = model('goods/goods_sku')->where(array('sku_id'=>$r['sku_id']))->getField('spu_id');
		$params['sku_id'] = $r['sku_id'];
		$params['order_sn'] = $r['order_sn'];
		$result = $this->update($params);
		if(!$result) {
			return false;
		}
		return true;
	}
	public function change_status($id){
		$data = array();
		$data['is_shield']=array('exp',' 1-is_shield ');
		$result = $this->table->where(array('id' => $id))->save($data);
		if($result === false) {
			return false;
		}
		return true;
	}
	public function update($params) {
		$params['id'] = (int) $params['id'];
		$params['mid'] = (int) $params['mid'];
		$params['spu_id'] = (int) $params['spu_id'];
		$params['order_sn'] = $params['order_sn'];
		$params['content'] = $params['content'];
		if($params['mid'] < 1) {
			$this->error = '会员信息异常';
			return false;
		}
		if($params['spu_id'] < 1 || $params['sku_id'] < 1) {
			$this->error = '商品信息异常';
			return false;
		}
		if(empty($params['order_sn'])) {
			$this->error = '订单号异常';
			return false;
		}
		if(!in_array($params['mood'], array('positive','neutral','negative'))) {
			$this->error = '评价信息异常';
			return false;
		}
		if(strlen($params['content']) < 5) {
			$this->error = '评价内容不能为空';
			return false;
		}
		if($params['imgs'] && is_array($params['imgs'])) {
			$attachment = implode(',', $params['imgs']);
			$params['imgs'] = json_encode($params['imgs']);
		}
		$result = $this->table->update($params);
		if($result === false) {
			$this->error = $this->table->getError();
			return false;
		}
		/* 操作附件 */
		if($attachment) model('attachment/attachment', 'service')->attachment($attachment);
		/* 处理订单商品表 */
		model('order/order_sku', 'table')->where(array('id' => $params['tid']))->setField('iscomment', 1);
		return true;
	}

	/* 回复评价信息 */
	public function reply($id, $content) {
		$r = $this->get($id);
		if(!$r) {
			$this->error = '评价不存在';
			return false;
		}
		$data = array();
		$data['id'] = $id;
		$data['reply_content'] = $content;
		$data['reply_time'] = TIMESTAMP;
		$result = $this->table->update($data);
		if($result === false) {
			$this->error = $this->table->getError();
			return false;
		}
		return true;
	}
	/*获取统计*/
	public function get_count($spu_id){
		$result['positive'] = $this->table->where(array('spu_id'=>$spu_id,'mood'=>'positive','is_shield' => 1))->count();
		$result['neutral'] = $this->table->where(array('spu_id'=>$spu_id,'mood'=>'neutral','is_shield' => 1))->count();
		$result['negative'] = $this->table->where(array('spu_id'=>$spu_id,'mood'=>'negative','is_shield' => 1))->count();
		return $result;
	}
	/* 删除指定评价信息 */
	public function delete($ids = array()) {
		foreach ($ids as $id) {
			if(!is_numeric($id) || $id < 1) continue;
			$this->table->delete($id);
		}
		return true;
	}
}