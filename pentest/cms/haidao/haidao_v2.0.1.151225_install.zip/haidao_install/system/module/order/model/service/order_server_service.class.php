<?php
/**
 * 		订单售后服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_server_service extends service {

	public function __construct() {
		$this->table = model('order/order_server');
		$this->table_return = model('order/order_return');
		$this->table_refund = model('order/order_refund');
		$this->table_order  = model('order/order');
		$this->table_sub    = model('order/order_sub');
		$this->table_sku    = model('order/order_sku');
		$this->table_member = model('member/member');

		$this->table_return_log = model('order/order_return_log');
		$this->table_refund_log = model('order/order_refund_log');

		$this->server_sku = model('order/order_sku','service');
		// 状态(-2：未通过，-1：已取消，0：待审核，1：通过)
		$this->status = array(-2 => '未通过',-1 => '已取消',0 => '待审核' , 1 => '通过' , 2 => '已退货');
	}

	/**
	 * 获取售后列表
	 * @param  integer $type     类型(1：退货并退款，2：仅退款)
	 * @param  integer $buyer_id 买家ID
	 * @return [result]
	 */
	public function get_servers($type = 0 ,$buyer_id = 0 ,$limit = 10,$page = 1) {
		$sqlmap = array();
		if (in_array($type, array(1,2))) {
			$sqlmap['type'] = $type;
		}
		if ((int)$buyer_id) {
			$sqlmap['buyer_id'] = $buyer_id;
		}
		$result = $this->table->where($sqlmap)->page($page)->limit($limit)->order('id DESC')->select();
		// 组装售后信息
		foreach ($result as $k => $v) {
			// 获取退货退款详情
			$result[$k]['_server'] = $this->_server($v);
			// 获取售后所有商品
			$result[$k]['_skus'] = $this->_skus($v);
		}
		$lists['lists'] = $result;
		$lists['count'] = $this->table->where($sqlmap)->count();
		return $lists;
	}

	/**
	 * 创建退货并退款记录
	 * @param  int  	$o_sku_id 订单sku表主键id
	 * @param  int 		$amount   退款金额
	 * @param  string  	$cause    原因
	 * @param  string  	$desc 	  描述
	 * @param  array   	$images   上传截图
	 * @return [boolean]
	 */
	public function create_return($o_sku_id ,$amount = 0 ,$cause , $desc = '',$images = array()) {
		$o_sku_id = (int) $o_sku_id;
		$amount   = (float)  remove_xss($amount);
		$cause    = (string) remove_xss($cause);
		$desc     = (string) remove_xss($desc);
		if ($amount == 0) {
			$this->error = '退款金额必须大于0';
			return FALSE;
		}
		if (!$cause) {
			$this->error = '请选择退货原因';
			return FALSE;
		}
		$o_sku = model('order/order_sku')->find($o_sku_id);
		if (!$o_sku) {
			$this->error = '该订单商品不存在';
			return FALSE;
		}
		if ($amount > $o_sku['real_price']) {
			$this->error = '退款金额不能大于：'.$o_sku['real_price'];
			return FALSE;
		}
		$check_has = $this->table_return->where(array('o_sku_id'=>$o_sku_id))->count();
		if ($check_has > 0) {
			$this->error = '您已申请售后，请勿重复提交';
			return FALSE;
		}
		$data = $server = $log = array();
		$data['order_sn'] = $o_sku['order_sn'];
		$data['sub_sn']   = $o_sku['sub_sn'];
		$data['o_sku_id'] = $o_sku_id;
		$data['buyer_id'] = $o_sku['buyer_id'];
		$data['cause']    = $cause;
		$data['number']   = $o_sku['buy_nums'];
		$data['amount']   = $amount;
		$data['desc']     = $desc;
		if (!empty($images)) {
			$data['images'] = json_encode($images);
		}
		$result = $this->table_return->update($data);
		if (!$result) {
			$this->error = $this->table_return->getError();
			return FALSE;
		}
		// 创建索引表记录
		$server['type'] = 1;
		$server['order_sn']  = $o_sku['order_sn'];
		$server['sub_sn']    = $o_sku['sub_sn'];
		$server['buyer_id']  = $o_sku['buyer_id'];
		$server['return_id'] = $result;
		$this->table->update($server);
		// 写入退货日志
		$operator = get_operator();	// 获取操作者信息
		$log['return_id']     = $result;
		$log['order_sn']      = $o_sku['order_sn'];
		$log['sub_sn']        = $o_sku['sub_sn'];
		$log['o_sku_id']      = $o_sku_id;
		$log['action']        = '申请退货并退款';
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];		
		$log['msg']           = $desc;
		model('order/order_return_log')->update($log);
		return $result;
	}

	/**
	 * 创建退款记录
	 * @param int 		$type 退款类型(1：退货并退款 ，2：仅退款)
	 * @param string 	$sub_sn 子订单号
	 * @param float 	$amount 退款金额
	 * @param string 	$desc 退款描述
	 * @param string 	$id 退款商品id(当type=1：退货主键id，type=2：订单商品id)
	 * @param array 	$images 图片(选填)
	 * @return [boolean]
	 */
	public function create_refund($type ,$sub_sn ,$amount = 0 ,$desc = '' ,$id = 0,$images = array()) {
		$type   = (int) $type;
		$sub_sn = (string) remove_xss($sub_sn);
		$amount = (float)  remove_xss($amount);
		$desc   = (string) remove_xss($desc);
		$id     = (int) $id;
		if (!in_array($type, array(1,2))) {
			$this->error = '操作类型有误';
			return FALSE;
		}
		if ($amount < 0) {
			$this->error = '退款金额必须大于0';
			return FALSE;
		}
		$order = $this->table_sub->where(array('sub_sn' => $sub_sn))->find();
		if (!$order) {
			$this->error = '该订单不存在';
			return FALSE;
		}
		if ($type == 1) {
			$return = $this->table_return->find($id);	// 获取退货记录信息
			if (!$return) {
				$this->error = $this->table_return->getError();
				return FALSE;
			}
			if ($amount > $return['amount']) {
				$this->error = '退款金额不能大于：'.$return['amount'];
				return FALSE;
			}
			$o_sku_id = $return['o_sku_id'];
		} else {
			$order_sku = $this->table_sku->find($id);	// 订单商品信息
			if (!$order_sku) {
				$this->error = $this->table_sku->getError();
				return FALSE;
			}
			if ($amount > $order_sku['real_price']) {
				$this->error = '退款金额不能大于：'.$order_sku['real_price'];
				return FALSE;
			}
			$o_sku_id = $id;
		}
		$check_has = $this->table_refund->where(array('o_sku_id'=>$o_sku_id))->count();
		if ($check_has > 0) {
			$this->error = '您已申请售后，请勿重复提交';
			return FALSE;
		}
		$data = $log = $server = array();
		switch ($type) {
			case 1:	// 退货并退款
				$data['return_id'] = $return['id'];
				$data['order_sn']  = $order['order_sn'];
				$data['sub_sn']    = $order['sub_sn'];
				$data['o_sku_id']  = $return['o_sku_id'];
				$data['buyer_id']  = $order['buyer_id'];
				$data['type']      = 1;
				$data['amount']    = $return['amount'];
				$data['desc']      = '退货并退款，创建订单退款记录';
				if (!empty($images)) {
					$data['images'] = json_encode($images);
				}
				$data['cause'] = $return['cause'];
				$log['order_sn'] = $order['order_sn'];
				$log['sub_sn']   = $order['sub_sn'];
				$log['action']   = '创建退货并退款的退款记录';
				$log['o_sku_id'] = $return['o_sku_id'];
				break;
			case 2:	// 仅退款
				$data['o_sku_id'] = $id;
				$data['order_sn'] = $order['order_sn'];
				$data['sub_sn']   = $order['sub_sn'];
				$data['buyer_id'] = $order['buyer_id'];
				$data['type']     = 2;
				$data['amount']   = $amount;
				$data['desc']     = $desc;
				if (!empty($images)) {
					$data['images'] = json_encode($images);
				}

				$log['order_sn'] = $order['order_sn'];
				$log['sub_sn']   = $order['sub_sn'];
				$log['action']   = '申请仅退款';
				$log['o_sku_id'] = $id;

				$server['order_sn'] = $order['order_sn'];
				$server['sub_sn']   = $order['sub_sn'];
				break;
		}
		$result = $this->table_refund->update($data);
		if (!$result) {
			$this->error = $this->table_refund->getError();
			return FALSE;
		}
		// 索引表记录(退货并退款:添加退款主键ID,仅退款||取消订单退款：创建退款记录)
		if ($type == 1) {
			$this->table->where(array('return_id' => $id))->setField('refund_id' ,$result);
		} else {
			$server['type'] = 2;
			$server['refund_id'] = $result;
			$server['buyer_id']  = $order['buyer_id'];
			$this->table->update($server);
		}
		// 创建退款日志
		$operator = get_operator();	// 获取操作者信息
		$log['refund_id']     = $result;
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];
		$log['msg']           = $data['desc'];
		model('order/order_refund_log')->update($log);
		return $result;
	}

	/** 
	 * 处理退货申请
	 * @param int $id 	  订单退货表主键ID
	 * @param int $status 处理状态
	 * @param string $msg 操作备注
	 * @return [boolean]
	 */
	public function handle_return($id = 0 ,$status = 0 ,$msg = '') {
		$id     = (int) $id;
		$status = (int) $status;
		$msg    = (string) remove_xss($msg);
		$info   = $this->table_return->find($id);
		if (!$info) {
			$this->error = '要操作的记录不存在';
			return FALSE;
		}
		if (in_array($info['status'], array(-2,-1,2))) {
			$this->error = '该记录禁止该操作';
			return FALSE;
		}
		$data = array();
		$data['id'] = $id;
		$data['status'] = $status;
		$data['admin_id'] = ADMIN_ID;
		$data['admin_desc'] = $msg;
		$data['admin_time'] = time();
		$result = $this->table_return->update($data);
		if (!$result) {
			$this->error = $this->table_return->getError();
			return FALSE;
		}
		// 退货日志
		$operator = get_operator();	// 获取操作者信息
		$log = array();
		$log['return_id']   = $id;
		$log['order_sn']    = $info['order_sn'];
		$log['sub_sn']      = $info['sub_sn'];
		$log['o_sku_id']    = $info['o_sku_id'];
		$log['action']      = '处理退货';
		$log['operator_id'] = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];
		$str = '';
		if (!empty($msg)) $str = '&nbsp;&nbsp; 操作日志：'.$msg;
		$log['msg'] = $operator['_operator_type'].'处理退货单为'.$this->status[$status].$str;
		$this->table_return_log->update($log);
		return $result;
	}

	/** 
	 * 处理退款申请
	 * @param int $id 	订单退款表主键ID
	 * @param int $status 处理状态
	 * @param string $msg 操作备注
	 * @return [boolean]
	 */
	public function handle_refund($id = 0 ,$status = 0 ,$msg = '') {
		$id     = (int) $id;
		$status = (int) $status;
		$msg    = (string) remove_xss($msg);
		$info   = $this->table_refund->find($id);
		if (!$info) {
			$this->error = '要操作的记录不存在';
			return FALSE;
		}
		if ($info['status'] != 0) {
			$this->error = '该记录禁止该操作';
			return FALSE;
		}
		$data = array();
		$data['id'] = $id;
		$data['status'] = $status;
		$data['admin_id'] = ADMIN_ID;
		$data['admin_desc'] = $msg;
		$data['admin_time'] = time();
		$result = $this->table_refund->update($data);
		if (!$result) {
			$this->error = $this->table_refund->getError();
			return FALSE;
		}
		// 退款日志
		$operator = get_operator();	// 获取操作者信息
		$log = array();
		$log['refund_id'] = $id;
		$log['order_sn']  = $info['order_sn'];
		$log['sub_sn']    = $info['sub_sn'];
		$log['o_sku_id']  = $info['o_sku_id'];
		$log['action']    = '处理退款';
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];
		$str = '';
		if (!empty($msg)) $str = '&nbsp;&nbsp; 操作日志：'.$msg;
		$log['msg'] = $operator['_operator_type'].'处理退款单为'.$this->status[$status].$str;
		$this->table_refund_log->update($log);
		return $result;
	}

	/** 
	 * 买家退货
	 * @param int 	 $id 	退货表主键ID
	 * @param string $name 	物流名称
	 * @param string $sn 	运单号
	 * @return [boolean]
	 */
	public function return_goods($id ,$name ,$sn) {
		$id = (int) $id;
		$name = (string) trim($name);
		$sn   = (string) trim($sn);
		if (empty($name)) {
			$this->error = '物流名称不能为空';
			return FALSE;
		}
		if (empty($sn)) {
			$this->error = '运单号不能为空';
			return FALSE;
		}
		$return = $this->table_return->find($id);
		if (!$return) {
			$this->error = $this->table_return->getError();
			return FALSE;
		}
		if ($return['status'] != 1) {
			$this->error = '该记录禁止该操作';
			return FALSE;
		}
		$data = array('delivery_name' => $name , 'delivery_sn' => $sn ,'status' => 2);
		$result = $this->table_return->where(array('id' => $id))->setField($data);
		if (!$result) {
			$this->error = $this->table_return->getError();
			return FALSE;
		}
		// 生成退款单记录
		$this->create_refund(1 ,$return['sub_sn'] ,$return['amount'] ,'' ,$return['id'],json_decode($return['images'],TRUE));
		return $result;
	}

	/**
	 * 获取售后详情
	 * @param  string $sn 主订单号
	 * @return [result]
	 */
	public function get_after_by_sn($sn = '') {
		$sn = (string) remove_xss($sn);
		$servers = $this->table->where(array('order_sn' => $sn))->select();
		foreach ($servers as $k => $val) {
			$servers[$k] = $this->_server($val);
		}
		return $servers;
	}

	/**
	 * 获取退货列表
	 * @param  array  $options 参数说明 [page : 分页，limit：显示条数]
	 * @param  array  $sqlmap 查询条件
	 * @return [result]
	 */
	public function get_returns($options = array(),$sqlmap = array()) {
		$page = isset($options['page']) ? (int) $options['page'] : 1;
		$limit = isset($options['limit']) ? (int) $options['limit'] : 10;
		$infos = $result = array();
		$result = $this->table_return->where($sqlmap)->page($page)->limit($limit)->order('id DESC')->select();
		foreach ($result as $k => $v) {
			$result[$k] = $this->_more($v);
		}
		$infos['lists'] = $result;
		$infos['count'] = $this->table_return->where($sqlmap)->count();
		return $infos;
	}

	/**
	 * 获取退款列表
	 * @param  array  $options 参数说明 [page : 分页，limit：显示条数]
	 * @param  array  $sqlmap 查询条件
	 * @return [result]
	 */
	public function get_refunds($options = array(),$sqlmap = array()) {
		$page = isset($options['page']) ? (int) $options['page'] : 1;
		$limit = isset($options['limit']) ? (int) $options['limit'] : 10;
		$infos = $result = array();
		$result = $this->table_refund->where($sqlmap)->page($page)->limit($limit)->order('id DESC')->select();
		foreach ($result as $k => $v) {
			$result[$k] = $this->_more($v);
			if ($v['iscancel'] == 1) {
				$result[$k]['_type'] = '取消订单并退款';
			} else if($v['type'] == 1) {
				$result[$k]['_type'] = '退货并退款';
			} else {
				$result[$k]['_type'] = '仅退款';
			}
		}
		$infos['lists'] = $result;
		$infos['count'] = $this->table_refund->where($sqlmap)->count();
		return $infos;
	}

	/* 获取记录所有数据 */
	private function _more($info = array()) {
		if (empty($info)) return FALSE;
		$sku = $buyer = array();
		// 获取商品信息  注：取消订单并退款的查询出所有订单skus
		if (isset($info['iscancel']) && $info['iscancel'] == 1) {
			$skus = $this->table_sku->where(array('order_sn' => $info['order_sn']))->field('sku_name ,sku_thumb,sku_spec,real_price,buy_nums')->select();
			$info['_sku'] = $skus[0];
			$info['_skus'] = $skus;
			if ($info['iscancel'] == 1) {
				$info['_type'] = '取消订单并退款';
			} else if($info['type'] == 1) {
				$info['_type'] = '退货并退款';
			} else {
				$info['_type'] = '仅退款';
			}
		} else {
			$sku = $this->table_sku->field('sku_name ,sku_thumb,sku_spec,real_price,buy_nums')->find($info['o_sku_id']);
			$info['_sku'] = $sku;
		}
		// 获取会员信息
		$buyer = $this->table_member->field('username ,mobile')->find($info['buyer_id']);
		$info['_buyer'] = $buyer;
		$info['_status'] = $this->status[$info['status']];
		if ($info['images']) $info['_images'] = json_decode($info['images'] ,TRUE);
		return $info;
	}

	/* 获取退货退款详情 */
	private function _server($server) {
		$arr = $logs1 = $logs2 = array();
		$arr['type'] = '仅退款';
		$refund = $this->table_refund->find($server['refund_id']);
		if ($server['type'] == 1) {	// 退货并退款
			$return = $this->table_return->find($server['return_id']);
			$arr['type'] = '退货并退款';
			$arr['cause'] = $return['cause'];
			$arr['amount'] = $return['amount'];
			$arr['images'] = json_decode($return['images']);
			$arr['status'] = $return['status'];
			$arr['axis']['create'] = $return['dateline'];	// 申请售后时间
			$arr['axis']['admin_time'] = $return['admin_time'];	// 卖家处理时间
			$arr['axis']['delivery'] = 0;	// 买家退货发货时间
			$arr['axis']['finish'] = 0;	// 完成时间
			if ($refund) {
				$arr['axis']['delivery'] = $refund['dateline'];	// 买家退货发货时间
				$arr['axis']['finish'] = $refund['admin_time'];	// 完成时间
				$arr['_status'] = $refund['status'];
			}
			$logs1 = model('order/order_return_log')->where(array('return_id' => $server['return_id']))->order('id DESC')->select();
		} else {
			$arr['cause'] = $refund['cause'];
			$arr['amount'] = $refund['amount'];
			$arr['images'] = json_decode($refund['images']);
			$arr['axis']['create'] = $refund['dateline'];	// 申请售后时间
			$arr['status'] = $refund['status'];
			$arr['axis']['finish'] = $refund['admin_time'];	// 完成时间
		}
		$logs2 = model('order/order_refund_log')->where(array('refund_id' => $server['refund_id']))->order('id DESC')->select();
		$arr['logs'] = array_merge($logs2 ? $logs2 : array() ,$logs1 ? $logs1 : array());
		return $arr;
	}

	/* 获取售后商品 */
	private function _skus($server) {
		$skus = array();
		if ($server['iscancel'] == 1) {	// 取消订单&退款
			$skus = $this->server_sku->get_by_order_sn($server['order_sn']);
		} else {
			if ($server['type'] == 1) {	// 退货并退款
				$o_sku_id = $this->table_return->where(array('id' => $server['return_id']))->getField('o_sku_id');
			} else {	// 仅退款
				$o_sku_id = $this->table_refund->where(array('id' => $server['refund_id']))->getField('o_sku_id');
			}
			$skus = $this->table_sku->where(array('id' => $o_sku_id))->select();
		}
		return $skus;
	}

	/**
	 * 获取退货详情
	 * @param  int $id return表主键id
	 * @return [result]
	 */
	public function return_detail($id) {
		$result = $this->table_return->find($id);
		$result = $this->_more($result);
		$result['logs'] = $this->table_return_log->where(array('return_id' => $id))->order('id DESC')->select();
		return $result;
	}

	/**
	 * 获取退款详情
	 * @param  int $id return表主键id
	 * @return [result]
	 */
	public function refund_detail($id) {
		$result = $this->table_refund->find($id);
		$result = $this->_more($result);
		$result['logs'] = $this->table_refund_log->where(array('refund_id' => $id))->order('id DESC')->select();
		return $result;
	}

	/**
	 * 生成查询条件
	 * @param  array  $params
	 * @return [sqlmap]
	 */
	public function build_map($params = array()) {
		$sqlmap = array();
		if (isset($params['type'])) {
			switch ($params['type']) {
				case 1:	// 已处理
					$sqlmap['status'] = array('NEQ' ,0);
					break;
				default:	// 待处理
					$sqlmap['status'] = 0;
					break;
			}
		}
		if (isset($params['keywords']) && $params['keywords']) {
			switch ($params['keywords']) {
				// 会员手机||账号
				case ((is_mobile($params['keywords']) == TRUE) || (strlen($params['keywords']) != 20)):
					$map = array();
					$map['username|mobile'] = array('LIKE','%'.$params['keywords'].'%');
					$sqlmap['buyer_id'] = $this->table_member->where($map)->getField('id');
					break;
				// 订单号
				default:
					$sqlmap['order_sn|sub_sn']  = $params['keywords'];
					break;
			}
		}
		return $sqlmap;
	}
}