<?php
/**
 * 		订单跟踪服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_track_service extends service {

	public function __construct() {
		$this->table = model('order/order_track');
		$this->table_delivery = model('order/delivery');
		$this->table_o_delivery = model('order/order_delivery');
	}

	/**
	 * 添加
	 * @param  string 	$order_sn  	主订单号
	 * @param  string 	$sub_sn  	子订单号
	 * @param  string 	$msg  		内容
	 * @param  int 		$time  		时间
	 * @param  int 		$delivery_id 订单物流关联id
	 * @return [boolean]
	 */
	public function add($order_sn = '' ,$sub_sn = '' ,$msg = '' ,$time = 0 ,$delivery_id = 0) {
		$data = array();
		$data['order_sn'] = (string) remove_xss($order_sn);
		$data['sub_sn']   = (string) remove_xss($sub_sn);
		$data['msg']      = (string) remove_xss($msg);
		$data['time']     = ((int) $time == 0) ? time() : $time;
		if ($delivery_id > 0) $data['delivery_id'] = (int) remove_xss($delivery_id);
		$result = $this->table->update($data);
		if (!$result) {
			$this->error = $this->table->getError();
			return FALSE;
		}
		return $result;
	}
	/**
	 * 更新快递100数据
	 * @param  string 	$sub_sn  子订单号
	 * @param  string 	$o_d_id  订单物流主键
	 * @return [boolean]
	 */
	public function update_api100($sub_sn,$o_d_id){
		$o_d_id = (int) $o_d_id;
		$o_d_info = $this->table_o_delivery->find($o_d_id);
		if (!$o_d_info) {
			$this->error = '订单物流信息不存在';
			return FALSE;
		}
        if(!$o_d_info['delivery_sn']){
        	$this->error = "运单号不存在";
        	return FALSE;
        }
        // 获取物流标识
       	$identif = $this->table_delivery->getFieldById($o_d_info['delivery_id'] ,'identif');
       	if (!$identif) {
       		$this->error = '物流标识不存在';
       		return FALSE;
       	}
        $datas = $this->kuaidi100($identif,$o_d_info['delivery_sn']);
        if ($datas == FALSE) return FALSE;
		krsort($datas['data']);
		// 统计当前已发货物流跟踪条数、和最后一条记录
		$sqlmap = array();
		$sqlmap['delivery_id'] = $o_d_id;
		$sqlmap['sub_sn'] = $sub_sn;
		$count = $this->table->where($sqlmap)->count();
		$track = $this->table->where($sqlmap)->field('order_sn,time')->order('id DESC')->find();
		foreach($datas['data'] as $v){
			$_time = strtotime($v['time']);
			if ($count != 1 && $_time <= $track['time']) {
				continue;
			}
			$this->add($track['order_sn'],$sub_sn,$v['context'],$_time,$o_d_id);
		}
        return TRUE;
	}
	/**
	 * 根据子订单号获取订单跟踪列表
	 * @param  $sub_sn  	子订单号
	 * @param  $order  		排序(默认：id降序)
	 * @return [result]
	 */
	public function get_tracks_by_sn($sub_sn = '' ,$order = 'id DESC') {
		$sub_sn = (string) trim($sub_sn);
		$order    = (string) trim($order);
		if (empty($sub_sn)) {
			$this->error = '订单号不能为空';
			return FALSE;
		}
		$sqlmap = array();
		$sqlmap['sub_sn'] = $sub_sn;
		return $this->table->where($sqlmap)->order($order)->select();
	}

	/**
	 * 获取订单跟踪详情
	 * @param  int 		$id  	 物流id
	 * @param  string 	$sn  	 快递单号
	 * @param  string 	$sub_sn  子订单号
	 * @return [result]
	 */
	public function get_tracks($id , $sn ,$sub_sn) {
		$delivery_com = model('order/delivery')->getFieldById($id,'identif');
		if (empty($delivery_com)) {
			$this->error = '物流代码有误';
			return FALSE;
		}
		$result = $this->kuaidi100($delivery_com , $sn);
		if (!$result) return FALSE;
		// 获取当前订单的跟踪信息
		$last_time = model('order/order_track')->where(array('sub_sn' => $sub_sn))->order('id DESC')->getField('time');
		krsort($result['data']);
		foreach ($result['data'] as $key => $val) {
			if (strtotime($val['time']) > $last_time) {	// 未更新的写入track表
				$this->add($sub_sn , $val['context'] ,strtotime($val['time']));
			}
		}
		return TRUE;
	}

	/**
	 * 快递100API
	 * @param  string 	$com  	快递代码
	 * @param  string 	$nu  	快递单号
	 * @return [result]
	 */
	public function kuaidi100($com = '' , $nu = '') {
		if(empty($com) || empty($nu)) {
			$this->error = '参数有误';
			return FALSE;
		}
		$url = 'http://www.kuaidi100.com/query?';
		$par = array();
		$par['id']     = 1;		// id
		$par['type']   = $com;	// 物流代码
		$par['postid'] = $nu;	// 快递单号
		$result = dfsockopen($url.http_build_query($par));
		if($result) {
			$result =  json_decode($result, TRUE);
			if ($result['status'] == 200) {
				unset($result['status']);
				switch ($result['state']) {
					case '0':
						$result['message'] = '在途';
						break;
					case '1':
						$result['message'] = '揽件';
						break;
					case '2':
						$result['message'] = '疑难';
						break;
					case '3':
						$result['message'] = '签收';
						break;
					case '4':
						$result['message'] = '退签';
						break;
					case '5':
						$result['message'] = '派件';
						break;
					case '6':
						$result['message'] = '退回';
						break;
					default:
						$result['message'] = '其他';
						break;
				}
				return $result;
			} else if($result['status'] == 201) {
				$this->error = $result['message'];
				return FALSE;
			} else if($result['status'] == 2) {
				$this->error = '接口出现异常';
				return FALSE;
			} else {
				$this->error = '物流单暂无结果';
				return FALSE;
			}
		} else {
			$this->error = '查询失败，请稍候重试';
			return FALSE;
		}
	}
}