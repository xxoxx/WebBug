<?php
/**
 * 		前台订单控制器
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_control extends control {

	public function _initialize() {
		parent::_initialize();
		$this->member = model('member/member', 'service')->init();
		if ($this->member['id'] == 0) {
			$url_forward = $_GET['url_forward'] ? $_GET['url_forward'] : urlencode($_SERVER['REQUEST_URI']);
			showmessage('请登录后操作', url('member/public/login',array('url_forward'=>$url_forward)),0);
		}
		$this->table = model('order/order');
		$this->service = model('order/order','service');
		$this->service_cart = model('order/cart','service');
		$this->service_delivery = model('order/delivery','service');
	}

	/* 购物车结算 */
	public function settlement() {
		// 会员收货地区id，便于加载配送物流
		$district_id = $this->member['_address'][0]['district_id'];
		$skuids = $_GET['skuids'];
		if (isset($_GET['district_id']) && is_numeric($_GET['district_id'])) {
			$district_id = (int) $_GET['district_id'];
		}
		$pay_type = (int) $_GET['pay_type'];
		$deliverys = (array) $_GET['deliverys'];
		$order_prom = (array) $_GET['order_prom'];
		$sku_prom = (array) $_GET['sku_prom'];
		$remarks = (array) $_GET['remarks'];
		$invoices = (array) $_GET['invoices'];
		// 购物车商品
		$carts =  $this->service->create($this->member['id'], $skuids , $district_id, $pay_type, $deliverys, $order_prom, $sku_prom, $remarks, $invoices, false);
		if (empty($carts)) showmessage("结算商品不存在");
		// 收货地址
		$address = $this->member['_address'];
		foreach ($address as $k => $val) {
			$area = model('admin/district','service')->fetch_position($val['district_id']);
			$address[$k]['_area'] = $area[2].' '.$area[3];
		}
		// 读取后台设置
		$setting = model("admin/setting",'service')->get_setting();
		// 支付方式
		$pay_type = array();
		switch ($setting['pay_type']) {
			case 2:
				$pay_type = array(1 => '在线支付');
				break;
			case 3:
				$pay_type = array(2 => '货到付款');
				break;
			default:
				$pay_type = array(1 => '在线支付',2 =>'货到付款');
				break;
		}
		// 所有一级地区
		$districts = model('admin/district','service')->get_children();
		$SEO = seo('核对订单信息');
		include template('cart_settlement');
	}

	public function get() {
		// 会员收货地区id，便于加载配送物流
		$district_id = $this->member['_address'][0]['district_id'];
		$skuids = $_GET['skuids'];
		if (isset($_GET['district_id']) && is_numeric($_GET['district_id'])) {
			$district_id = (int) $_GET['district_id'];
		}
		$pay_type = (int) $_GET['pay_type'];
		$deliverys = (array) $_GET['deliverys'];
		$order_prom = (array) $_GET['order_prom'];
		$sku_prom = (array) $_GET['sku_prom'];
		$remarks = (array) $_GET['remarks'];
		$invoices = (array) $_GET['invoices'];
		$result =  $this->service->create($this->member['id'], $skuids , $district_id, $pay_type, $deliverys, $order_prom, $sku_prom, $remarks, $invoices, false);
		if($result === false) {
			showmessage($this->service->error);
		} else {
			showmessage($this->service->error, url('index'), 1, $result);
		}
	}

	public function ajax_settlement(){
		showmessage('操作成功',url('order/order/settlement'),1);
	}
	/* 根据地区id获取下级地区 */
	public function ajax_get_district_childs() {
		$id = (int) $_GET['id'];
		$result = model('admin/district','service')->get_children($id);
		echo json_encode($result);
	}

	/* 获取商家物流信息 */
	public function get_deliverys() {
		unset($_GET['page']);
		$deliverys = array();
		$deliverys = $this->service_delivery->get_deliverys($_GET['district_id'] , $_GET['skuids']);
		echo json_encode($deliverys);
	}

	/* 获取该物流的支付方式 */
	public function get_methods() {
		$delivery = $this->service_delivery->get_by_id($_GET['delivery_id']);
		echo json_encode($delivery['method']);
	}

	/* 获取物流费用 */
	public function get_payable() {
		$payable = model('order/delivery_district')->where(array("id" => $_GET['id']))->find();
		echo json_encode($payable);
	}

	/**
	 * 创建订单
	 * @param 	array
	 * @return  [boolean]
	 */
	public function create() {
		// 会员收货地区id，便于加载配送物流
		$district_id = $this->member['_address'][0]['district_id'];
		$skuids = $_GET['skuids'];
		if (isset($_GET['district_id']) && is_numeric($_GET['district_id'])) {
			$district_id = (int) $_GET['district_id'];
		}
		$pay_type = (int) $_GET['pay_type'];
		$deliverys = (array) $_GET['deliverys'];
		$order_prom = (array) $_GET['order_prom'];
		$sku_prom = (array) $_GET['sku_prom'];
		$remarks = (array) $_GET['remarks'];
		$invoices = (array) $_GET['invoices'];
		$result =  $this->service->create($this->member['id'], $skuids , $district_id, $pay_type, $deliverys, $order_prom, $sku_prom, $remarks, $invoices, true);
		if (!$result) {
			showmessage($this->service->error);
		}
		showmessage('订单创建成功',url('order/order/detail',array('order_sn'=>$result)),1,'json');
	}

	public function detail() {
		$order_sn = trim($_GET['order_sn']);
		if (empty($order_sn)) showmessage("请勿非法访问");
		$order = $this->table->detail($order_sn)->output();
		if ($this->member['id'] != $order['buyer_id']) {
			showmessage("抱歉，您无法查看此订单");
		}
		if ($order['pay_type'] == 1 && $order['pay_status'] != 0) {
			showmessage("抱歉，该订单当前不是支付状态");
		}
		if($order['real_amount'] == 0) {
			redirect(url('order/order/pay_success',array('sn'=>$sn)));
		}
		if (checksubmit('dosubmit')) {
			unset($_GET['page']);
			$result = $this->service->detail_payment($_GET);
			if ($result == FALSE) showmessage($this->service->error);
			redirect($result['referer']);
		} else {
			if ($order['pay_type'] == 2) {	// 货到付款
				include template('order_success');
				return FALSE;
			}
			// 后台设置-余额支付 1:开启，0：关闭
			$setting = model('admin/setting','service')->get_setting();
			$balance_pay = $setting['balance_pay'];
			$member_info = $this->member;
			$pays = $setting['pays'];
			$payments = model('pay/payment','service')->getpayments('pc', $pays);
			$SEO = seo('订单支付');
			include template('detail_payment');
		}
	}

	/* 获取支付状态 */
	public function get_pay_status() {
		$order_sn = $_GET['order_sn'];
		$order = $this->table->detail($order_sn)->output();
		if (!$order || $order['buyer_id'] != $this->member['id']) {
			showmessage('抱歉，您无法查看此订单');
		}
		if ($order['_status']['now'] == 'pay') {
			showmessage('该订单已支付',url('order/order/pay_success',array('order_sn'=>$order_sn)),1,'json');
		} else {
			showmessage('该订单未支付');
		}
	}

	/* 支付成功 */
	public function pay_success() {
		$order_sn = $_GET['order_sn'];
		$order = $this->table->detail($order_sn)->output();
		if (!$order) showmessage("该订单不存在");
		if ($order['buyer_id'] != $this->member['id']) showmessage("您无权查看此订单");
		$SEO = seo('支付成功');
		include template('order_success');
	}
}