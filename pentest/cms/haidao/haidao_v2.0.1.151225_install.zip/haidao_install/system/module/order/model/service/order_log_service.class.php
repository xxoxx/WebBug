<?php
/**
 * 		订单日志服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_log_service extends service {

	public function __construct() {
		$this->table = model('order/order_log');
	}

	/**
	 * 写入订单日志
	 * @param $params
	 * @return [boolean]
	 */
	public function add($params = array()) {
		$params = array_filter($params);
		if (empty($params)) {
			$this->error = '订单日志信息不能为空';
			return FALSE;
		}
		$result = $this->table->update($params);
		if (!$result) {
			$this->error = $this->table->getError();
			return FALSE;
		}
		return $result;
	}

	/**
	 * 根据订单号查日志
	 * @param $sub_sn : 订单号
	 * @param $order  : 排序
	 * @return [boolean]
	 */
	public function get_by_order_sn($sub_sn = '' , $order = '') {
		$sub_sn = (string) trim($sub_sn);
		if (empty($sub_sn)) {
			$this->error = '订单号不能为空';
			return FALSE;
		}
		$order = (string) trim($order);
		if (empty($order)) {
			$order = 'id ASC';
		}
		$sqlmap = array();
		$sqlmap['sub_sn'] = $sub_sn;
		return $this->table->where($sqlmap)->order($order)->select();
	}
}