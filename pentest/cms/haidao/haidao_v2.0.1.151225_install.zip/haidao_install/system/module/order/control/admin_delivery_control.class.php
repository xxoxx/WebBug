<?php
/**
 * 		后台物流 控制器
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class admin_delivery_control extends init_control {

	public function _initialize() {
		parent::_initialize();
		$this->model = model('order/delivery');
		$this->service = model('order/delivery','service');
		$this->service_district = model('admin/district','service');
	}

	/* 物流配置管理 */
	public function index() {
		$sqlmap = array();
		$deliverys = $this->model->page($_GET['page'])->limit(5)->lists();
		$count = $this->model->where($sqlmap)->count();
        $pages = $this->admin_pages($count, 5);
		include $this->admin_tpl('delivery_index');
	}

	/* [添加|编辑] 物流 */
	public function update() {
		if (checksubmit('do_submit')) {
			unset($_GET['do_submit']);
			unset($_GET['formhash']);
			$result = $this->service->update($_GET);
			if (!$result) showmessage($this->service->error,'',0,'json');
			showmessage(lang('操作成功'),url('index'),1,'json');
		} else {
			$delivery = array();
			$id = (int) $_GET['id'];
			// 获取当前物流信息
			if ($id > 0) {
				$delivery = $this->service->get_by_id($id);
			}
			include $this->admin_tpl('delivery_update');
		}
	}
	
	public function ajax_district_select() {
		@ini_set('memory_limit','256M');
		/* 查询三级 */
		$districts = $this->service_district->fetch_all_by_tree(0, 3);
		include $this->admin_tpl('ajax_district_select');
	}

	/* 根据地区id获取下级地区 */
	public function ajax_get_district_childs() {
		$district_id = (int) $_GET['district_id'];
//		if ($district_id < 1) showmessage('地区ID必须为正整数');
		$result = $this->service_district->get_children($district_id);
		echo json_encode($result);
	}

	/* ajax删除物流地区 */
	public function ajax_delete_district() {
		if (checksubmit('dosubmit')) {
			$result = $this->service->ajax_delete_district($_GET['delete_id']);
			if (!$result) showmessage($this->service->error);
			showmessage(lang('删除成功'),'',1,'json');
		} else {
			showmessage(lang('请勿非法请求'));
		}
	}

	/* 根据物流ID更改物流字段值 */
	public function update_field_by_id() {
		if (checksubmit('dosubmit')) {
			$result = $this->service->update_field_by_id($_GET['id'],$_GET['field'],$_GET['val']);
			if (!$result) showmessage($this->service->error);
			showmessage(lang('更改成功'),'',1,'json');
		} else {
			showmessage(lang('请勿非法请求'));
		}
	}

	/* 删除物流(支持多条) */
	public function deletes() {
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		$ids = (array)$_GET['ids'];
		$result = $this->service->deletes($ids);
		if (!$result) showmessage($this->service->error);
		showmessage(lang('删除成功'),url('index'),1,'json');	
	}

	/* 物流快递模版 */
	public function delivery_tpl() {
		if (checksubmit('dosubmit')) {
			if (empty($_GET['content']) || !isset($_GET['id'])) {
				showmessage('提交参数有误');
			}
			$result = $this->model->where(array('id' => $_GET['id']))->setField('tpl', $_GET['content']);
			if ($result === false) showmessage($this->model->getError());
			showmessage(lang('操作成功'),url('order/admin_delivery/delivery_tpl',array('id'=>$_GET['id'])),1,'json');
		} else {
			$delivery = $this->service->get_by_id($_GET['id']);
			// 兼容js报错
			if(empty($delivery['tpl'])) {
				$content = array('width' => 1000 ,'height' => 650);
			} else {
				$content = json_decode($delivery['tpl'], TRUE);
			}
			include $this->admin_tpl('delivery_tpl');
		}
	}

	/* 打印快递模版 */
	public function print_kd($sn = '') {
		$sn = (string) trim($_GET['sn']);
		if (empty($sn)) showmessage('您的订单号有误');
		/* 查找该订单的快递图片名称 */ 
		$order = model('order/order')->where(array('sn' => $sn))->find();
		// 收货人地区
		$district = model('admin/district','service')->fetch_position($order['delivery_address_district']);
		$district = implode(' ', $district);
		/* 读取该快递模版的编辑信息 */
		$delivery = $this->service->get_by_id($order['delivery_id']);
		$content = json_decode($delivery['tpl'], TRUE);
		// 替换值
		foreach ($content['list'] as $k => $v) {
			$str = str_replace('left','x',json_encode($v));
			$str = str_replace('{accept_name}',$order['delivery_address_name'],$v);	// 收货人
			$str = str_replace('{mobile}',$order['delivery_address_mobile'],$str);	// 收货人手机
			$str = str_replace('{address}',$district.' '.$order['delivery_address_address'],$str);	// 收货人地址
			$str = str_replace('{real_amount}',$order['real_amount'],$str);	// 实付金额
			$content['list'][$k] = $str;
		}
		include $this->admin_tpl('print_kd');
	}

}