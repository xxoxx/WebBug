<?php
/**
 * 		订单商品服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_goods_service extends service {

	protected $sqlmap = array();

	public function __construct() {
		$this->logic = model('order/order_goods','logic');
		$this->table = model('order/order_goods', 'table');
	}

	/**
	 * 创建订单商品
	 * @param  array	$params 订单商品相关参数
	 * @return [boolean]
	 */
	public function create_all($params) {
		$result = $this->logic->create_all($params);
		if (!$result) {
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}

	/**
	 * 根据订单号获取订单商品
	 * @param 	$sn : 订单号
	 * @return 	[result]
	 */
	public function get_by_order_sn($sn = '') {
		$result = $this->logic->get_by_order_sn($sn);
		if (!$result) {
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}

	/**
	 * 获取订单商品详情
	 * @param 	$id : 订单商品ID
	 * @return 	[result]
	 */
	public function detail($id = 0) {
		$result = $this->logic->detail($id);
		if (!$result) {
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}

	public function member_id($mid) {
		if((int) $mid > 0) {
			$this->sqlmap['member_id'] = $mid;
		}
		return $this;
	}

	/**
	 * 通用列表接口
	 * @param  array   $sqlmap 附加条件
	 * @param  integer $limit  [description]
	 * @param  integer $page   [description]
	 * @return [type]          [description]
	 */
	public function lists($sqlmap = array(), $limit = 20, $order = 'id DESC', $page = 1) {
		$this->sqlmap = array_merge($this->sqlmap, $sqlmap);
        $DB = $this->table->where($this->sqlmap);
        $lists = &$DB->page($page)->limit($limit)->order($order)->select();
        foreach ($lists as $key => $value) {
        	$value['sku_spec'] = json_decode($value['sku_spec'], true);
        	$spec_str = '';
        	foreach ($value['sku_spec'] AS $spec) {
        		$spec_str .= $spec['name'].':'.$spec['value'].'&nbsp;&nbsp;&nbsp;';
        	}
        	$value['spec_str'] = $spec_str;
        	$lists[$key] = $value;
        }
        $count = $this->table->where($this->sqlmap)->count();
        return array('count' => $count, 'lists' => $lists);
	}
	/**
	 * 获取订单商品的成交记录
	 * @param int 	$sid 	商品sku_id||spu_id
	 * @param bool 	$isspu 	是否spu_id (当前为TRUE时，$all为TRUE)
	 * @param bool  $all 	是否查找所有sku的记录
	 * @return 	[result]
	 */
	public function records($sid = 0, $isspu = TRUE , $all = TRUE ,$options = array()) {
		$result = $this->logic->records($sid, $isspu, $all ,$options);
		if (!$result) {
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
}