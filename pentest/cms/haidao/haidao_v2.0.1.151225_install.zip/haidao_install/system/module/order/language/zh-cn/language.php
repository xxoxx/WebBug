<?php
/**
 *      订单语言包
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
return array(
	// -----   订单
	'ORDER_NOT_EXIST'                 => '该订单不存在',
	
	'ORDER_SUBMIT_SUCCESS'            => '订单提交成功',
	'ORDER_SUBMIT_ERROR'              => '订单提交失败',
	
	'ORDER_SN_NOT_NULL'               => '订单号不能为空',
	'ORDER_SN_ERROR'                  => '订单号有误',
	'ORDER_SN_ALREADY_EXIST'          => '订单号已存在',
	
	'ORDER_STATUS_NOT_NULL'           => '订单状态不能为空',
	'ORDER_STATUS_ERROR'              => '订单状态只能为正整数',
	
	'ORDER_SOURCE_NOT_NULL'           => '订单来源不能为空',
	'ORDER_SOURCE_ERROR'              => '订单来源只能为正整数',
	
	'ORDER_MEMBER_ID_NOT_NULL'        => '会员ID不能为空',
	'ORDER_MEMBER_ID_ERROR'           => '会员ID只能为正整数',
	
	'ORDER_DELIVERY_METHOD_NOT_NULL'  => '配送方式不能为空',
	'ORDER_DELIVERY_METHOD_ERROR'     => '配送方式只能为正整数',
	
	'ORDER_PAY_STATUS_NOT_NULL'       => '支付状态不能为空',
	'ORDER_PAY_STATUS_ERROR'          => '支付状态只能为正整数',
	
	'ORDER_DELIVERY_STATUS_NOT_NULL'  => '配送状态不能为空',
	'ORDER_DELIVERY_STATUS_ERROR'     => '配送状态只能为正整数',
	
	'ORDER_PAYABLE_AMOUNT_NOT_NULL'   => '商品总额不能为空',
	'ORDER_PAYABLE_AMOUNT_ERROR'      => '商品总额只能为实数(保留两位小数)',
	
	'ORDER_REAL_AMOUNT_NOT_NULL'      => '应付总额不能为空',
	'ORDER_REAL_AMOUNT_ERROR'         => '应付总额只能为实数(保留两位小数)',
	
	'ORDER_ADDRESS_NAME_NOT_NULL'     => '收货人姓名不能为空',
	'ORDER_ADDRESS_MOBILE_NOT_NULL'   => '收货人手机不能为空',
	
	'ORDER_ADDRESS_DISTRICT_NOT_NULL' => '收货人地区ID不能为空',
	'ORDER_ADDRESS_DISTRICT_ERROR'    => '收货人地区ID只能为正整数',
	
	'ORDER_ADDRESS_ADDRESS_NOT_NULL'  => '收货人详细地址不能为空',
	
	// ---------- 购物车
	'CART_ADD_SUCCESS'    => '购物车添加成功',
	'CART_UPDATE_SUCCESS' => '购物车修改成功',
	'CART_DELETE_SUCCESS' => '购物车删除成功',
	'CART_CLEAR_SUCCESS'  => '购物车清空成功',
	'CART_KEY_ERROR'      => '购物车加密Key为32位',
	
	// ---------- 当前状态
	'CREATE'              => '创建订单',
	'PAY'                 => '已付款',
	'CONFIRM'             => '已确认',
	'DELIVERY'            => '已发货',
	'COMPLETION'          => '已完成',
	'CANCEL'              => '已取消',
	'RECYCLE'             => '已回收',
	'DELETE'              => '已删除',
	'RETURN'              => '已退货',
	'REFUND'              => '已退款',
	
	// ---------- 待操作状态
	'WAIT_PAY'            => '待付款',
	'WAIT_CONFIRM'        => '待确认',
	'WAIT_DELIVERY'       => '待发货',
	'WAIT_COMPLETION'     => '待确认完成',
);