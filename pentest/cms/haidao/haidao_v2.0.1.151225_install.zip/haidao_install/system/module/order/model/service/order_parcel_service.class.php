<?php
/**
 * 		发货单服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_parcel_service extends service {

	public function __construct() {
		$this->table = model('order/order_parcel');
		$this->table_log = model('order/order_parcel_log');
		$this->table_order = model('order/order');
		$this->table_member = model('member/member');
		$this->service_track  = model('order/order_track','service');
	}

	/**
	 * 创建发货单
	 * @param  array 	$sub 子订单信息
	 * @return [boolean]
	 */
	public function create($sub) {
		// 获取主订单信息
		$main_order = $this->table_order->where(array('sn' => $sub['order_sn']))->find();
		$member_name = $this->table_member->getFieldById($main_order['buyer_id'] ,'username');
		// 生成发货单
		$data = array();
		$data['order_sn'] = $sub['order_sn'];
		$data['sub_sn']   = $sub['sub_sn'];
		$data['member_name']    = $member_name;
		$data['address_name']   = $main_order['address_name'];
		$data['address_mobile'] = $main_order['address_mobile'];
		$data['address_detail'] = $main_order['address_detail'];
		$data['delivery_name']  = $sub['delivery_name'];
		$data['system_time']    = time();
		$result = $this->table->update($data);
		if (!$result) {
			$this->error = $this->table->getError();
			return FALSE;
		}
		// 物流跟踪
		//$this->service_track->add($sub['order_sn'] ,$sub['sub_sn'] , '您的订单正在配货');
		// 发货单日志
		$operator = get_operator();
		$data = array();
		$data['parcel_id']     = $result;
		$data['order_sn']      = $sub['order_sn'];
		$data['sub_sn']        = $sub['sub_sn'];
		$data['buyer_id']      = $sub['buyer_id'];
		$data['member_name']   = $member_name;
		$data['action']        = '生成发货单';
		$data['msg']           = '生成发货单，待发货...';
		$data['operator_id']   = $operator['id'];
		$data['operator_name'] = $operator['username'];
		$data['system_time']   = time();
		$this->table_log->update($data);
		return $result;
	}
	/**
	 * 更改配送状态
	 * @param  array 	 配送信息
	 * @return [boolean]
	 */
	public function complete_parcel($params){
		if((int)$params['id'] < 1){
			$this->error = "发货单不存在";
			return false;
		}
		$data = array();
		$data['id'] = $params['id'];
		$data['status'] = $params['status'];
		$result = $this->table->update($data);
		if($result === FALSE){
			$this->error = $this->table->getError();
			return false;
		}
		$parcel = $this->table->fetch_by_id($params['id']);
		$parcel['parcel_status'] = $data['status'];
		/*添加日志*/
		if(!$this->table_log->add_log($parcel,$params['log'])){
			$this->error = $this->table_log->getError();
			return false;
		}
		return true;
	}
	/**
	 * 删除发货单
	 * @id  array 	 发货单id
	 * @return [boolean]
	 */
	 public function delete_parcel($id) {
		 if((int)$id < 1){
			 $this->error = '非法操作';
			 return false;
		 }
		 $data = array();
		 $data['id'] = array('eq',$id);
		 $result = $this->table->where($data)->delete();
		 if(!$result){
			 $this->error = $this->table->getError();
			 return false;
		 }
		 /*删除日志*/
		 if($this->table_log->where(array('parcel_id'=>array('eq',$id)))->delete() === FALSE){
			 $this->error = $this->table->getError();
			 return false;
		 }
		 return true;
	 }
}