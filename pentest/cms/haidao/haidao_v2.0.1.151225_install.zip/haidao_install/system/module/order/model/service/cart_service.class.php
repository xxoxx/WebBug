<?php
/**
 * 		购物车服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class cart_service extends service {

	public function __construct() {
		$this->table = model('order/cart');
		$this->service_goods_sku = model('goods/goods_sku','service');
	}

	/**
	 * 购物车添加商品(支持数组)
	 * @param  array	$params ：array('sku_id' => 'nums'[,'sku_id' => 'nums'...])
	 * @param  int 		$buyer_id ：会员id(游客为0)
	 * @return [boolean]
	 */
	public function cart_add($params ,$buyer_id = 0 ,$buynow = FALSE) {
		if (empty($params)) {
			$this->error = '参数错误';
			return FALSE;
		}
		foreach ($params as $skuid => $nums) {
			$skuid = (int) $skuid;
			$sku_info = model('goods/goods_sku')->find($skuid);	// 获取商品信息
			unset($sku_info['content']);
			if (!$sku_info || $sku_info['status'] != 1) continue;
			$nums = ((int) $nums === 0) ? 1 : $nums;
    		$this->_add($skuid , $nums , $buyer_id ,$buynow);
		}
		if ($buyer_id > 0) { // 清空 购物车cookie
			cookie('cart_nums', 0);
        	cookie('cart', NULL);
		}
        return TRUE;
	}

	/* 执行添加购物车 */
	private function _add($sku_id ,$nums ,$buyer_id = 0 ,$buynow = FALSE) {
		$sqlmap = $data = array();
		if ($buyer_id > 0) {
			$data['buyer_id'] = $sqlmap['buyer_id'] = $buyer_id;
			$data['sku_id'] = $sqlmap['sku_id'] = $sku_id;
			$data['nums']   = $nums;
            $cart = $this->table->where($sqlmap)->find();
            if ($cart) {
            	if ($buynow == TRUE) {
            		$nums = max($nums ,$cart['nums']);
            	} else {
            		$nums = (int) $cart['nums'] + $nums;
            	}
            	return $this->set_nums($sku_id,$nums,$buyer_id);
            } else {
            	return $this->table->update($data);
            }
		} else {
			$all_item = json_decode(cookie('cart'), TRUE);
        	$sku_ids = array_keys($all_item);
            if (count($all_item) > 0 && in_array($sku_id,$sku_ids)) {
        		$item = explode(',', $all_item[$sku_id]);
        		if ($buynow == TRUE) {
            		$nums = max($nums ,$item[1]);
            	} else {
            		$nums = (int) $item[1] + $nums;
            	}
            	return $this->set_nums($sku_id,$nums,$buyer_id);
            } else {
            	$all_item[$sku_id] = $sku_id.','.$nums;
            }
            cookie('cart_nums', count($all_item));
			cookie('cart', json_encode($all_item));
            return $all_item;
		}
	}

	/**
	 * 获取当前用户购物车
	 * @param [boolean] $group 是否根据商家分组,默认FALSE
	 * @return [result]
	 */
	public function get_all($group = FALSE ,$buyer_id = 0) {
		$result = array();
		$buyer_id = (int) $buyer_id;
		if ($buyer_id > 0) {
            $sqlmap = array();
            $sqlmap['buyer_id'] = $buyer_id;
            $all_item = $this->table->where($sqlmap)->order("id DESC")->getField('sku_id,nums');
			foreach($all_item as $skuid => $num) {
				$all_item[$skuid] = $skuid.','.$num;
			}
        } else {
            $all_item = json_decode(cookie('cart'), TRUE);
        }
		if(!$all_item) {
			cookie('cart_nums', 0);
			$result['sku_count'] = 0;
			$result['all_count'] = 0;
			$result['all_subtotal'] = 0;
			return $result;
		}
		$all_count = $all_subtotal = $sold_count = 0;
		foreach ($all_item as $skuid => $val) {
            list($sku_id, $nums) = explode(',',$val);
            /* 检测商品是否存在，不存在注销该变量 */
            $sku_info = $this->service_goods_sku->goods_detail($skuid);
            if ($sku_info == FALSE) unset($all_item[$skuid]);
            // 若sku库存小于当前购买量，则更改购物车数量为当前sku库存
            if ($sku_info['number'] < $nums) {
            	$nums = $sku_info['number'];
            	$this->set_nums($sku_id , $nums);
            }
			$result['list'][$skuid]['sku_id'] = $sku_id;
			$result['list'][$skuid]['nums']   = $nums;
            if ($sku_info['number'] == 0) {
            	// 该sku是否已售馨
            	$result['list'][$sku_id]['issold'] = TRUE;
            	++$sold_count;
            }
            // 获取商品数据
			$sku = array();
			$sku = $this->_get_sku($sku_id);
			$sku['shop_price'] = $sku['prom_price'];
			$result['list'][$skuid]['_sku'] = $sku;
			// 小计总价
			$result['list'][$skuid]['subtotal'] = sprintf("%.2f",$sku['shop_price'] * $nums);
			// 商品总数
			$all_count += $nums;
			// 商品总价
			$all_subtotal = $all_subtotal + ($sku['shop_price'] * $nums);
        }
        // 商品多少种
        $result['sku_count'] = count($result['list']);
        // 商品总数
        $result['all_count'] = $all_count;
        // 商品总价
        $result['all_subtotal'] = sprintf('%.2f',$all_subtotal);
        // 已售馨商品多少种
        $result['sold_count'] = $sold_count;

        /* 根据商家id分组信息 */
        if ($group == TRUE) {
        	$data = array();
        	$seller_subtotal = $all_subtotal = $sku_count = $all_count = 0;
        	foreach ($result['list'] as $k => $v) {
        		$data[$v['_sku']['seller_id']]['sku_list'][] = $v;
        		$data[$v['_sku']['seller_id']]['seller_subtotal'] += $v['subtotal'];
        		$all_subtotal += $v['subtotal'];
        		$all_count += $v['nums'];
        	}
        	$sku_count = count($result['list']);
        	$result['list'] = $data;
        	$result['sku_count'] = $sku_count;
        	$result['all_count'] = $all_count;
        	$result['all_subtotal'] = $all_subtotal;
        }
        return $result;
	}

	/* 获取购物车列表 */
	public function get_cart_lists($member_id = 0, $sku_ids = '', $isgroup = false) {
		$sku_arr = array_filter(explode(';', $sku_ids));
		if (empty($sku_arr)) {
			$this->error = "参数错误";
			return FALSE;
		}
		$sku_ids = $nums = $arr = array();
		foreach ($sku_arr as $k => $val) {
			$arr = explode(',', $val);
			$sku_ids[] = $arr[0];
			$nums[$arr[0]] = abs((int) $arr[1]);
		}
		if ($member_id > 0) {
            $sqlmap = array();
            $sqlmap['buyer_id'] = $member_id;
			$sqlmap['sku_id'] = array('IN',$sku_ids);
            $items = $this->table->where($sqlmap)->order("id DESC")->getField('sku_id,nums');
			foreach($items as $skuid => $num) {
				$num = ($nums[$skuid] == 0 || $nums[$skuid] > $num) ? $num : $nums[$skuid];
				$items[$skuid] = $skuid.','.$num;
			}
        } else {
            $items = json_decode(cookie('cart'), TRUE);
	        foreach ($items as $k => $v) {
	        	if (!in_array($k, $sku_ids)) unset($items[$k]);
	        }
        }
        if(empty($items)) {
        	$this->error = '没有任何商品';
        	return false;
        }
        $result = array();
        $all_prices = $numbers = $sold_count = 0;
        foreach ($items as $item) {
        	$val = array();
        	list($sku_id, $number) = explode(",", $item);
        	$sku_info = $this->service_goods_sku->goods_detail($sku_id);
        	unset($sku_info['content']);
        	if($sku_info === false) {
        		continue;
        	}
        	$number = min($sku_info['number'], $number);
        	$val['sku_id'] = $sku_id;
        	$val['number'] = $number;
        	$val['_sku_'] = $sku_info;
        	if($number == 0) {
        		$val['is_sold'] = true;
        	}
        	$sku_info['shop_price'] = $sku_info['prom_price'];
        	$val['prices'] = sprintf("%.2f",$sku_info['shop_price'] * $number);
        	$result['skus'][$sku_id] = $val;
        	$numbers += $number;
        	$all_prices += $val['prices'];
        }

        $result['all_prices'] = $all_prices;
        $result['sku_numbers'] = $numbers;
        $result['sku_counts'] = count($result['skus']);
        if($isgroup === true) {
        	$sku = array();
        	$sub_prices = $sub_counts = 0;
        	foreach ($result['skus'] as $sku_id => $v) {
        		$seller_id = (int) $v['_sku_']['seller_id'];
        		$sku[$seller_id]['sku_list'][$sku_id] = $v;
        		$sub_prices += $v['prices'];
        		$sub_numbers += $v['number'];
        		$sku[$seller_id]['sku_price'] = $sku[$seller_id]['sub_prices'] = $sub_prices;
        		$sku[$seller_id]['sub_numbers'] = $sub_numbers;
        	}
        	$result['skus'] = $sku;
        }
        return $result;
	}

	/* 根据sku_id 获取产品信息 */
	private function _get_sku($sku_id = 0) {
		$sku = array();
		$sku = $this->service_goods_sku->goods_detail($sku_id);
		$sku['seller_id'] = (int) $sku['seller_id'];
		if (!empty($sku['spec'])) {
			$_spec = '';
			foreach ($sku['spec'] as $spec) {
				$_spec .= $spec['name'].':'.$spec['value'].'&nbsp;&nbsp;';
			}
			$sku['_spec'] = $_spec;
		}
		if (!file_exists($sku['thumb'])) {
			$sku['thumb'] = 'statics/images/no_pic.png';
		}
		unset($sku['content']);
		return $sku;
	}


	/**
	 * 设置购物车商品数量
	 * @param int $sku_id 	商品sku_id
	 * @param int $nums 	数量
	 * @return [boolean]
	 */
	public function set_nums($sku_id ,$nums ,$buyer_id = 0) {
		$sku_id = (int) $sku_id;
		$nums = max(0, (int) $nums);
		$buyer_id = (int) $buyer_id;
		if ($sku_id < 1) {
			$this->error = '购买数量必须为正整数';
			return FALSE;
		}
		if ($buyer_id == 0) {	// 游客更新cookie
			$all_item = array();
			$all_item = json_decode(cookie('cart'),TRUE);
			if (empty($all_item[$sku_id])) {
				$this->error = '该购物车商品不存在';
				return FALSE;
			}
			if ($nums == 0) {	// 删除该记录
				unset($all_item[$sku_id]);
			} else {
				$set_info = explode(',', $all_item[$sku_id]);	// array('sku_id','nums')
				$set_info[1] = $nums;
				$all_item[$sku_id] = implode(',', array_values($set_info));
			}
			cookie('cart_nums', count($all_item));
        	cookie('cart', json_encode($all_item));
        	return TRUE;
		}
		$sqlmap = $data = array();
		$sqlmap['buyer_id'] = $buyer_id;
		$sqlmap['sku_id']   = $sku_id;
		$set_info = $this->table->where($sqlmap)->find();
		if (!$set_info) {
			$this->error = '该购物车商品不存在';
			return FALSE;
		}
		if ($nums == 0) {	// 删除该记录
			$result = $this->delpro($sku_id ,$buyer_id);
			if (!$result) return FALSE;
		} else {
			$data['nums']        = $nums;
			$data['system_time'] = time();
			$result = $this->table->where($sqlmap)->setField($data);
			if (!$result) {
				$this->error = $this->table->getError();
				return FALSE;
			}
		}
		return $result;
	}

	/**
	 * 删除购物车商品
	 * @param  int $sku_id 商品sku_id
	 * @return [boolean]
	 */
	public function delpro($sku_id ,$buyer_id = 0) {
		$sku_id = (int) trim($sku_id);
		$buyer_id = (int) $buyer_id;
		if (!$sku_id) {
			$this->error = '要删除的参数不能为空';
			return FALSE;
		}
		if ($buyer_id > 0) {
			$sqlmap = array();
			$sqlmap['buyer_id'] = $buyer_id;
			$sqlmap['sku_id']    = $sku_id;
			$result = $this->table->where($sqlmap)->delete();
			if ($result == FALSE) {
				$this->error = $this->table->getError();
				return FALSE;
			}
		} else {
			$all_item = json_decode(cookie('cart'), TRUE);
        	if (!$all_item) return FALSE;
            unset($all_item[$sku_id]);
            cookie('cart_nums', count($all_item));
            cookie('cart', json_encode($all_item));
		}
        return TRUE;
	}

	/**
	 * 清空购物车
	 * @return [boolean]
	 */
	public function clear($buyer_id = 0) {
		$buyer_id = (int) $buyer_id;
		if ($buyer_id == 0) {
			cookie('cart_nums', 0);
        	cookie('cart', NULL);
        	return TRUE;
		}
		$sqlmap = array();
		$sqlmap['buyer_id'] = $buyer_id;
		$_result = $this->table->where($sqlmap)->count();
		if ($_result == 0) {
			$this->error = '购物车已为空';
			return FALSE;
		}
		$result = $this->table->where($sqlmap)->delete();
		if (!$result) {
			$this->error = $this->table->getError();
			return FALSE;
		}
		return $result;
	}

	/**
	 * 处理订单促销
	 * @param  $join_order_total 参与订单促销的总额
	 * @param  [array] $promot   订单促销活动
	 * @return [$join_order_total]
	 */
	private function _prom_order($join_order_total ,$promot ) {
		if (!$promot) {
			return $join_order_total;
		}
		switch ($promot['type']) {
			case 1:	// 满额免邮
				$join_order_total = $join_order_total;
				break;
			case 2:	// 满额赠礼
				$join_order_total = $join_order_total;
				break;
			default:	// 满额立减
				$join_order_total = ($join_order_total <= $promot['discount']) ? 0 : $join_order_total-$promot['discount'];
				break;
		}
		return $join_order_total;
	}

	/* 更换购物车商品规格 */
	public function change_skuid($old_skuid = 0 ,$new_skuid = 0,$buyer_id = 0) {
		$old_skuid = (int) $old_skuid;
		$new_skuid = (int) $new_skuid;
		if (!$old_skuid || !$new_skuid) {
			$this->error = '参数错误';
			return FALSE;
		}
		$buyer_id = (int) $buyer_id;
		if ($buyer_id > 0) {
			$sqlmap = array();
			$sqlmap['buyer_id'] = $buyer_id;
			$sqlmap['sku_id'] = $old_skuid;
			$result = $this->table->where($sqlmap)->find();
			if (!$result) {
				$this->error = '该购物车商品不存在';
				return FALSE;
			}
			$data = array();
			$data['sku_id'] = $new_skuid;
			$data['nums'] = 1;
			$result = $this->table->where($sqlmap)->setField($data);
			if (!$result) {
				$this->error = $this->table->getError();
				return FALSE;
			}
			return $result;
		} else {
			$all_item = json_decode(cookie('cart'),TRUE);
			$sku_ids = array_keys($all_item);
			if (!in_array($old_skuid, $sku_ids)) {
				$this->error = '该购物车商品不存在';
				return FALSE;
			}
			unset($all_item[$old_skuid]);
			$all_item[$new_skuid] = $new_skuid.',1';
			cookie('cart_nums' , count($all_item));
			cookie('cart' , json_encode($all_item));
			return TRUE;
		}
	}

	/**
	 * 清除已售罄商品
	 * @return [boolean]
	 */
	public function clear_sold_out() {
		$result = $this->get_all(TRUE);
		if ($result['sold_count'] > 0) {
			foreach ($result as $key => $val) {
				foreach ($val as $ke => $va) {
					foreach ($va['sku_list'] as $k => $v) {
						if ($v['_sku']['number'] == 0) {
							$this->delpro($v['sku_id']);
						}
					}
				}
			}
		}
		return TRUE;
	}
	/**
	 * 登录成功后回调：把之前购物车的cookie存到cart表里
	 * @return [boolean]
	 */
	public function cart_sync($buyer_id = 0){
		$buyer_id = (int) $buyer_id;
		if ($buyer_id < 1) {
			$this->error = '请登录后再操作';
			return FALSE;
		}
		$all_item = json_decode(cookie('cart'), TRUE);
		if($all_item) {
			$info = array();
			foreach($all_item as $key => $item) {
				list($sku_id,$num) = explode(',',$item);
				$data = array();
				$data['buyer_id'] = $buyer_id;
				$data['sku_id'] = $sku_id;
				$result = model('cart')->where($data)->find();
				if($result) {
					$this->table->where($data)->setInc('nums', $num);
				} else {
					$data['nums'] = $num;
					$this->table->update($data);
				}
			}
		}
        cookie('cart', NULL);
		cookie('cart_nums', 0);
		return TRUE;
	}

	/**
	 * 减除相应购买数量
	 * @param  array $params  参数 ：array('sku_id1' => number1 [,'sku_id2' => number2])
	 * @param  int   $buyer_id 会员id(游客为0)
	 * @return [boolean]
	 */
	public function dec_nums($params = array() ,$buyer_id = 0) {
		$sku_ids = array();
		foreach ($params as $skuid => $num) {
			if ((int) $num < 1) unset($params[$skuid]);
			$sku_ids[] = $skuid;
		}
		if (empty($params) || empty($sku_ids)) {
			$this->error = '参数不能为空';
			return FALSE;
		}
		$sqlmap = array();
		$sqlmap['buyer_id'] = (int) $buyer_id;
		$sqlmap['sku_id'] = array('IN' ,$sku_ids);
		$carts = $this->table->where($sqlmap)->getField('sku_id,nums');
		foreach ($carts as $skuid => $cart_num) {
			$this->set_nums($skuid , ($cart_num - $params[$skuid]), $buyer_id);
		}
		return TRUE;
	}
}