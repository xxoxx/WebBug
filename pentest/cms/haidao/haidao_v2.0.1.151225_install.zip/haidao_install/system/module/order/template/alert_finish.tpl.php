<?php include $this->admin_tpl('header','admin'); ?>

	<form>
	<div class="form-box border-bottom-none order-eidt-popup clearfix">
		<?php if ($delivery_method == 2) : ?>
			<?php echo form::input('text','paid_amount','0','实付金额：','请填写实际付款金额（必填）'); ?>
		<?php endif; ?>
		<?php echo form::input('textarea','msg','','确认订单完成备注：','',array('placeholder' => '请填写订单操作日志（选填）')); ?>
	</div>
	<div class="padding text-right ui-dialog-footer">
		<input type="button" class="button bg-main" id="okbtn" value="确定" data-name="dosubmit" data-reset="false"/>
		<input type="button" class="button margin-left bg-gray" id="closebtn" value="取消"  data-reset="false"/>
	</div>
	</form>
</body>
</html>

<script>
	$(function(){
		try {
			var dialog = top.dialog.get(window);
		} catch (e) {
			return;
		}
		
		dialog.title('确认完成');
		dialog.reset();     // 重置对话框位置
		$('#okbtn').on('click', function () {
			dialog.data.msg = $('[name=msg]').val();
			var delivery_method = "<?php echo $delivery_method ?>";
			if (delivery_method == '2') {
				dialog.data.paid_amount = parseFloat($('[name=paid_amount]').val());
				if (isNaN(dialog.data.paid_amount)) {
					alert('请输入实付金额');
					return false;
				}
			}
			$.post(dialog.data.tpl_url, dialog.data , function(ret) {
				dialog.close();
				alert(ret.message);
				if (ret.status != 1) return false;
				window.top.main_frame.location.reload();
			},'json');
		});
		$('#closebtn').on('click', function () {
			dialog.remove();
			return false;
		});

	})
</script>