<?php
/**
 * 		订单发货单模版 服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_tpl_parcel_service extends service {

	public function __construct() {
		$this->model = model('order/order_tpl_parcel');
	}

	/**
	 * 修改
	 * @param  $content  	内容
	 * @return [boolean]
	 */
	public function update( $content = '') {
		$data = array();
		$data['id']      = 1;
		$data['name']    = '发货单模版';
		$data['content'] = (string) $content;
		$result = $this->model->update($data);
		if (!$result) {
			$this->error = $this->model->getError();
			return FALSE;
		}
		return $result;
	}

	/**
	 * 获取订单发货单模版详情
	 * @param  $id  	主键ID
	 * @return [result]
	 */
	public function get_tpl_parcel_by_id($id = 0) {
		$id = (int) trim($id);
		if ($id < 1) {
			$this->error = '发货单模版ID必须为正整数';
			return FALSE;
		}
		$result = $this->model->find($id);
		if (!$result) {
			$this->error = '未查询到相关数据';
			return FALSE;
		}
		return $result;
	}	
}