<?php
/**
 * 		发货单日志 模型
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_parcel_log_table extends table {
	
	protected $_validate = array(
        // 订单号
		array('order_sn', 'require', '主订单号必须存在',0),
        array('sub_sn', 'require', '子订单号必须存在',0),
    );

	
	/*添加日志*/
	public function add_log($params,$log){
		if(!$params){
			$this->error = '非法操作';
			return false;
		}
		$data = array();
		$data['parcel_id'] = $params['id'];
		$data['order_sn'] = $params['order_sn'];
		$data['sub_sn'] = $params['sub_sn'];
		$data['member_name'] = $params['member_name'];
		$data['msg'] = $log;
		$data['operator_id'] = (int)ADMIN_ID;
		$data['buyer_id'] = model('order_sub')->where(array('sub_sn'=>array('eq',$data['sub_sn'])))->getField('buyer_id');
		$data['operator_name'] = model('admin_user')->where(array('id'=>$data['operator_id']))->getField('username');
		$data['system_time'] = time();
		switch($params['parcel_status']){
			case 1:
				$action = '当前操作配送中';
				break;
			case -1:
				$action = '当前操作配送失败';
				break;
			case 2:
				$action = '当前操作配送成功';
				break;
			default:
				$action = '当前操作待配送';
		}
		$data['action'] = $action;
		$result = $this->update($data);
		if(!$result){
			$this->error = $this->getError();
			return false;
		}
		return true;
	}

}