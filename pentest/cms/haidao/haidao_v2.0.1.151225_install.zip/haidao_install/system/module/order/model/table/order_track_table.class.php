<?php
/**
 * 		订单跟踪模型
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_track_table extends table {

	protected $_validate = array(
        /* array(验证字段1,验证规则,错误提示,[验证条件,附加规则,验证时间]), */
        // 订单号
        array('order_sn', 'require', '{ORDER_SN_NOT_NULL}', self::MUST_VALIDATE, 'regex', self::MODEL_INSERT),
        // 内容
        array('msg', 'require', '{订单跟踪内容不能为空}', self::MUST_VALIDATE, 'regex', self::MODEL_INSERT),
    );

    //自动完成
    protected $_auto = array(
    	// array(完成字段1,完成规则,[完成条件,附加规则]),
        array('add_time','time',1,'function'),          //新增数据时插入系统时间
        array('clientip','get_client_ip',1,'function'), //更新数据时更新修改时间
    );
    //获取最新物流数据
     public function fetch_by_new_sub($value,$field){
        $data = array();
        $data['sub_sn'] = $value;
        $result = $this->where($data)->order('time desc')->find();
        if($field) return $result[$field];
        return $result;
    }
}