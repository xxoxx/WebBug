<?php include $this->admin_tpl('header','admin'); ?>
<script type="text/javascript" src="<?php echo __ROOT__ ?>statics/js/jquery.print.js"></script>

	<div class="fixed-nav layout">
		<ul>
			<li class="first">发货单模版<a id="addHome" title="添加到首页快捷菜单">[+]</a></li>
			<li class="spacer-gray"></li>
		</ul>
		<div class="hr-gray">
		</div>
	</div>
	
	<div class="content padding-big have-fixed-nav">
		<div class="margin-top">
			<?php echo $info['content']?>
		</div>
	</div>
</body>
<script>
	$(".operation").live('click',function(){
		 $(".margin-top").jqprint();
	})
	$(".back").live('click',function(){
		window.history.go(-1);
	})
	$(".delete").live('click',function(){
		var total_num = parseInt($(".total_num").text());
		var number = parseInt($(this).prev().prev().text());
		var total_price = parseFloat($(".total_price").text());
		var total_goods_price = parseFloat($(this).prev().text());
		var new_total_price = total_price - total_goods_price;
		$(".total_num").text(total_num - number);
		$(".total_price").text(new_total_price.toFixed(2));
		$(this).parents("#goodslist").hide();
	})
</script>