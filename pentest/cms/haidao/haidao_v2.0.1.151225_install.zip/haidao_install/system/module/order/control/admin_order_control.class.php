<?php
/**
 * 		后台订单 控制器
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class admin_order_control extends init_control {

	public function _initialize() {
		parent::_initialize();
		/* 数据层 */
		$this->table = model('order/order');
		$this->table_sub = model('order/order_sub');
		/* 服务层 */
		$this->service = model('order/order','service');
		$this->service_sub = model('order/order_sub','service');
		$this->service_order_log = model('order/order_log','service');
		$this->service_tpl_parcel = model('order/order_tpl_parcel','service');
		$this->service_parcel = model('order/order_parcel','service');
	}

	/* 订单列表管理 */
	public function index() {
		// 查询条件
		$sqlmap = array();
		$sqlmap = $this->service->build_sqlmap($_GET);
		$orders = $this->table->page($_GET['page'])->where($sqlmap)->limit(10)->order('id DESC')->select();
		$count  = $this->table->where($sqlmap)->count();
		$pages  = $this->admin_pages($count, 10);
		include $this->admin_tpl('index');
	}

	/* 订单详细页面 */
	public function detail() {
		$order = $this->table_sub->where(array('sub_sn' => $_GET['sub_sn']))->find();
		if (!$order) showmessage('该订单不存在');
		$order['_member'] = model('member/member')->find($order['buyer_id']);
		$order['_main'] = $this->table->where(array('sn' => $order['order_sn']))->find();
		// 日志
		$order_logs = $this->service_order_log->get_by_order_sn($order['sub_sn']);
		include $this->admin_tpl('detail');
	}

	/* 发货单模版 */
	public function tpl_parcel() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_tpl_parcel->update($_GET['content']);
			if (!$result) showmessage($this->service->error);
			showmessage('保存成功','',1,'json');
		} else {
			$info = $this->service_tpl_parcel->get_tpl_parcel_by_id(1);
			include $this->admin_tpl('tpl_parcel');
		}
	}

	/* 确认付款 */
	public function pay() {
		if (checksubmit('dosubmit')) {
			$params = array();
			$params['pay_status'] = trim(strtotime($_GET['pay_status']));
			$params['paid_amount']= sprintf("%0.2f", (float) $_GET['paid_amount']);
			$params['pay_method'] = trim($_GET['pay_method']);
			$params['pay_sn']     = trim($_GET['pay_sn']);
			$params['msg']        = trim($_GET['msg']);
			$result = $this->service_sub->set_order($_GET['sn'] ,$_GET['action'] ,$_GET['status'],$params);
			if (!$result) showmessage($this->service_sub->error);
			showmessage('确认付款成功','',1,'json');
		} else {
			// 获取所有已开启的支付方式
			$pays = model('pay/payment','service')->getpayments();
			foreach ($pays as $k => $pay) {
				$pays[$k] = $pay['pay_name'];
			}
			$pays['other'] = '其它付款方式';
			$order = $this->table->where(array('sn' => $_GET['order_sn']))->find();
			include $this->admin_tpl('alert_pay');
		}
	}

	/* 确认订单 */
	public function confirm() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status'],array('msg' => $_GET['msg']));
			if (!$result) showmessage($this->service_sub->error);
			showmessage(lang('确认订单成功'),'',1,'json');
		} else {
			include $this->admin_tpl('alert_confirm');
		}
	}

	/* 确认发货 */
	public function delivery() {
		if (checksubmit('dosubmit')) {
			$params = array();
			$params['is_choise']     = remove_xss($_GET['is_choise']);
			$params['delivery_id']   = remove_xss($_GET['delivery_id']);
			$params['delivery_sn']   = remove_xss($_GET['delivery_sn']);
			$params['msg']           = remove_xss($_GET['msg']);
			$params['o_sku_ids']	 = remove_xss($_GET['o_sku_ids']);
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status'],$params);
			if (!$result) {
				showmessage($this->service_sub->error);
			}
			showmessage(lang('确认发货成功'),'',1,'json');
		} else {
			// 获取已开启的物流
			$sqlmap = $deliverys = array();
			$sqlmap['enabled'] = 1;
			$deliverys = model('order/delivery')->where($sqlmap)->getField('id,name' ,TRUE);
			// 获取子订单下的skus
			$o_skus = $this->service_sub->sub_delivery_skus($_GET['sub_sn']);
			if (!$o_skus) {
				showmessage($this->service_sub->error);
			}
			include $this->admin_tpl('alert_delivery');
		}
	}

	/* 确认完成 */
	public function finish() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status'],array('msg'=>$_GET['msg'],'paid_amount' => $_GET['paid_amount']));
			if (!$result) {
				showmessage($this->service_sub->error);
			}
			showmessage(lang('确认完成成功'),'',1,'json');
		} else {
			$pay_type = (int) $_GET['pay_type'];
			include $this->admin_tpl('alert_finish');
		}
	}

	/* 取消订单 */
	public function cancel() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status'],array('msg'=>$_GET['msg'],'isrefund' => (int) $_GET['isrefund']));
			if (!$result) {
				showmessage($this->service_sub->error,'',0,'json');
			}
			showmessage(lang('取消订单成功'),'',1,'json');
		} else {
			$order = $this->table_sub->where(array('sub_sn' => $_GET['sub_sn']))->find();
			include $this->admin_tpl('alert_cancel');
		}
	}

	/* 作废 */
	public function recycle() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status'],array('msg'=>$_GET['msg']));
			if (!$result) {
				showmessage($this->service_sub->error);
			}
			showmessage(lang('订单作废操作成功'),'',1,'json');
		} else {
			include $this->admin_tpl('alert_recycle');
		}
	}

	/* 删除订单 */
	public function delete() {
		if (checksubmit('dosubmit')) {
			$result = $this->service_sub->set_order($_GET['sub_sn'] ,$_GET['action'] ,$_GET['status']);
			if (!$result) showmessage($this->service_sub->error);
			showmessage(lang('删除订单成功'),url('order/admin_order/index'),1,'json');
		} else {
			showmessage(lang('请勿非法请求'));
		}
	}

	/* 修改订单应付总额 */
	public function update_real_price() {
		if (checksubmit('dosubmit')) {
			$result = $this->service->update_real_price($_GET['sub_sn'] ,$_GET['real_price']);
			if (!$result) {
				showmessage($this->service->error);
			}
			showmessage(lang('修改订单应付总额成功'),'',1,'json');
		} else {
			$order = $this->table_sub->where(array('sub_sn' => $_GET['sub_sn']))->find();
			include $this->admin_tpl('alert_update_real_price');
		}
	}

	/* 发货单管理 */
	public function parcel() {
		$sqlmap = array();
		if (isset($_GET['status'])) {
			$sqlmap['status'] = $_GET['status'];
		}
		if (isset($_GET['keyword']) && !empty($_GET['keyword'])) {
			$sqlmap['order_sn|member_name|address_mobile'] = array('LIKE','%'.$_GET['keyword'].'%');
		}
		$parcels = model('order/order_parcel')->page($_GET['page'])->limit(10)->lists($sqlmap);
		$count  = model('order/order_parcel')->count();
		$pages  = $this->admin_pages($count, 10);
		include $this->admin_tpl('parcel');
	}

	/*确认配送*/
	public function complete_parcel() {
		if((int)$_GET['id'] < 1) showmessage('非法操作');
		if (checksubmit('dosubmit')) {
			$result = $this->service_parcel->complete_parcel($_GET);
			if(!$result){
				showmessage($this->service_parcel->error);
			}
			showmessage('操作成功',url('parcel'),1);
		}else{
			$parcelinfo = model('order/order_parcel')->fetch_by_id($_GET['id']);
			include $this->admin_tpl('alert_complete_parcel');
		}
	}

	/*删除发货单*/
	public function delete_parcel() {
		if((int) $_GET['id'] < 1) showmessage('非法操作');
		$result = $this->service_parcel->delete_parcel($_GET['id']);
		if(!$result){
			showmessage($this->service_parcel->error);
		}
		showmessage('操作成功',url('order/admin_order/parcel'),1);
	}

	/*打印发货单*/
	public function prints(){
		if((int)$_GET['id'] < 1) showmessage('非法操作');
		$info = $this->service_tpl_parcel->get_tpl_parcel_by_id(1);
		//订单信息
		$sub_sn = model('order/order_parcel')->fetch_by_id($_GET['id'],'sub_sn');
		//收货人信息
		$userinfo = model('order/order_parcel')->where(array('sn'=>$sub_sn))->find();
		//商品信息
		$goods = model('order/order_sku')->where(array('sub_sn'=>$sub_sn))->select();
		$info['content'] = str_replace('{order_sn}',$sub_sn,$info['content']);
		$info['content'] = str_replace('{address}',$userinfo['address_detail'],$info['content']);
		$info['content'] = str_replace('{print_time}',date('Y-m-d H:i:s',time()),$info['content']);
		$info['content'] = str_replace('{accept_name}',$userinfo['address_name'],$info['content']);
		$info['content'] = str_replace('{mobile}',$userinfo['address_mobile'],$info['content']);
		$info['content'] = str_replace('{delivery_txt}',$userinfo['delivery_name'],$info['content']);
		$field_start = substr($info['content'],strpos($info['content'],'<tr id="goodslist">'));
		$field_end = substr($info['content'],strpos($info['content'],'<tr id="goodslist">'),strpos($field_start, '<tr>'));
		$total_num = 0;
		$total_price = 0;
		foreach($goods as $k => $v){
			$str = str_replace('{sort_id}',$k+1,$field_end);
			$str = str_replace('{products_sn}',$v['sku_barcode'],$str);
			$str = str_replace('{goods_name}',$v['sku_name'],$str);
			$str = str_replace('{shop_price}',$v['sku_price'],$str);
			$str = str_replace('{number}',$v['buy_nums'],$str);
			$str = str_replace('{total_goods_price}',$v['real_price'],$str);
			$goods[$k] = $str;
			$total_num = $total_num + $v['buy_nums'];
			$total_price =  $total_price + $v['real_price'];
		}
		$goods=implode('', $goods);
		$info['content']=str_replace($field_end, $goods, $info['content']);
		$info['content']=str_replace('{total_num}', $total_num, $info['content']);
		$info['content']=str_replace('{total_price}', number_format($total_price,2), $info['content']);
		include $this->admin_tpl('prints_parcel');
	}
}