<?php include $this->admin_tpl('header','admin'); ?>

	<form>
	<div class="form-box border-bottom-none order-eidt-popup clearfix">
		<?php echo form::input('textarea','msg','','是否确定作废该订单：','',array('placeholder' => '请填写订单操作日志（选填）')); ?>
	</div>
	<div class="padding text-right ui-dialog-footer">
		<input type="button" class="button bg-main" id="okbtn" value="确定" name="dosubmit" data-reset="false"/>
		<input type="button" class="button margin-left bg-gray" id="closebtn" value="取消"  data-reset="false"/>
	</div>
	</form>
</body>
</html>

<script>
	$(function(){
		try {
			var dialog = top.dialog.get(window);
		} catch (e) {
			return;
		}
		
		dialog.title('订单作废');
		dialog.reset();     // 重置对话框位置
		$('#okbtn').on('click', function () {
			dialog.data.msg = $('[name=msg]').val();
			$.post(dialog.data.tpl_url, dialog.data , function(ret) {
				dialog.close();
				alert(ret.message);
				if (ret.status != 1) return false;
				window.top.main_frame.location.reload();
			},'json');
		});
		$('#closebtn').on('click', function () {
			dialog.remove();
			return false;
		});

	})
</script>
