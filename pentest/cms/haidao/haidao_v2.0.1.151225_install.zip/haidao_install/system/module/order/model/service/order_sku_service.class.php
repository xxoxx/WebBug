<?php
/**
 * 		订单商品服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class order_sku_service extends service {

	protected $sqlmap = array();

	public function __construct() {
		$this->table = model('order/order_sku');
		$this->table_order = model('order/order');
	}

	/**
	 * 创建订单商品
	 * @param  array	$params 订单商品相关参数
	 * @return [boolean]
	 */
	public function create_all($params) {
		if (count(array_filter($params)) < 1) {
			$this->error = '订单商品不能为空';
			return FALSE;
		}
		foreach ($params as $key => $val) {
			$result = $this->table->update($val);
			if (!$result) {
				$this->error = $this->table->getError();
				return FALSE;
			}
		}
		return TRUE;
	}

	/**
	 * 根据主订单号获取订单商品
	 * @param 	$sn : 主订单号
	 * @return 	[result]
	 */
	public function get_by_order_sn($sn = '') {
		$sn = (string) trim($sn);
		if ($sn == '') {
			$this->error = '订单号不能为空';
			return FALSE;
		}
		$sqlmap = $arr = array();
		$sqlmap['order_sn'] = $sn;
		$result = $this->table->where($sqlmap)->order('id ASC')->select();
		if (!$result) {
			$this->error = '该订单号的订单商品不存在';
			return FALSE;
		}
		foreach ($result as $k => $val) {
			if (!empty($val['sku_spec'])) {
				$val['sku_spec'] = json_decode($val['sku_spec'], TRUE);
			}
			if (!empty($val['sku_spec'])) {
				$_spec = '';
				foreach ($val['sku_spec'] as $key => $v) {
					$_spec .= $v['name'].'：'.$v['value'].'&nbsp;&nbsp;';
 				}
 				$val['_sku_spec'] = $_spec;
			}
			$arr[$val['id']] = $val;
		}
		return $arr;
	}

	/**
	 * 获取订单商品详情
	 * @param 	$id : 订单商品ID
	 * @return 	[result]
	 */
	public function detail($id = 0) {
		$result = $this->table->find($id);
		if (!$result) {
			$this->error = '记录不存在';
			return FALSE;
		}
		$result['sku_spec'] = json_decode($result['sku_spec'],TRUE);
		// 订单信息
		$result['_order'] = $this->table_order->detail($result['order_sn'])->output();
		return $result;
	}

	public function member_id($mid) {
		if((int) $mid > 0) {
			$this->sqlmap['member_id'] = $mid;
		}
		return $this;
	}

	/**
	 * 通用列表接口
	 * @param  array   $sqlmap 附加条件
	 * @param  integer $limit  [description]
	 * @param  integer $page   [description]
	 * @return [type]          [description]
	 */
	public function lists($sqlmap = array(), $limit = 20, $order = 'id DESC', $page = 1) {
		$this->sqlmap = array_merge($this->sqlmap, $sqlmap);
        $DB = $this->table->where($this->sqlmap);
        $lists = &$DB->page($page)->limit($limit)->order($order)->select();
        foreach ($lists as $key => $value) {
        	$value['sku_spec'] = json_decode($value['sku_spec'], true);
        	$lists[$key] = $value;
        }
        $count = $this->table->where($this->sqlmap)->count();
        return array('count' => $count, 'lists' => $lists);
	}

	/**
	 * 获取订单商品的成交记录
	 * @param int 	$sid 	商品sku_id||spu_id
	 * @param bool 	$isspu 	是否spu_id (当前为TRUE时，$all为TRUE)
	 * @param bool  $all 	是否查找所有sku的记录
	 * @return 	[result]
	 */
	public function records($sid = 0, $isspu = TRUE , $all = TRUE ,$options = array()) {
		$all = ($isspu == TRUE) ? TRUE : $all;
		$sqlmap = $result = array();
		if ($all == FALSE) {
			$sqlmap['sku_id'] = $sid;
		} else {
			$sku_ids = model('goods/goods_sku','service')->get_sku_ids($sid , $isspu);
			if (empty($sku_ids)) return $result;
			$sqlmap['sku_id'] = array('IN',$sku_ids);
		}
		$result['count'] = $this->table->where($sqlmap)->count();
		$result['lists'] = $this->table->where($sqlmap)->page($options['page'])->limit($options['limit'])->order('id DESC')->select();
		foreach ($result['lists'] as $key => $value) {
			$sku_str = '';
			$sku_spec = json_decode($value['sku_spec'],TRUE);
			foreach ($sku_spec as $k => $v) {
				$sku_str .= $v['name'].":".$v['value'].' ';
			}
			$name = model('member/member')->where(array('id'=>$value['buyer_id']))->getfield('username');
			$result['lists'][$key]['username'] = cut_str($name, 1, 0).'**'.cut_str($name, 1, -1);
			$result['lists'][$key]['dateline'] = date('Y-m-d H:i:s',$value['dateline']);
			$result['lists'][$key]['spec_str'] = $sku_str;
		}
		return $result;
	}
}