<?php include $this->admin_tpl('header','admin'); ?>

	<form>
	<div class="form-box border-bottom-none order-eidt-popup clearfix">
		<?php echo form::input('calendar','pay_status',date('Y-m-d H:i:s',time()),'付款时间：','',array('format' => 'YYYY-MM-DD hh:mm:ss')); ?>
		<?php echo form::input('text','paid_amount',$order['real_amount'],'付款金额：','请填写付款金额（必填）'); ?>
		<?php  $pay_keys = array_keys($pays);$first_key = current($pay_keys);?>
		<?php echo form::input('select','pay_method',$first_key,'付款方式：','',array('items' => $pays)); ?>
		<?php echo form::input('text','pay_sn','','支付交易号：','',array('placeholder' => '请输入第三方交易凭证号（其它时选填）')); ?>
		<?php echo form::input('textarea','msg','','确认付款备注：','',array('placeholder' => '线下付款或其它支付方式建议填写')); ?>
	</div>
	<div class="padding text-right ui-dialog-footer">
		<input type="button" class="button bg-main" id="okbtn" value="确定" name="dosubmit" data-reset="false"/>
		<input type="button" class="button margin-left bg-gray" id="closebtn" value="取消"  data-reset="false"/>
	</div>
	</form>
</body>
</html>

<script>
	$(function(){
		try {
			var dialog = top.dialog.get(window);
		} catch (e) {
			return;
		}

		// 当选择为 其它支付方式时禁止输入支付交易号
		$(".listbox-item").bind('click',function() {
			if ($(this).data('val') == 'other') {
				$("input[name=pay_sn]").val('').prop('disabled',true);
			} else {
				$("input[name=pay_sn]").prop('disabled',false);
			}
		})
		
		dialog.title('确认付款');
		dialog.reset();     // 重置对话框位置
		$('#okbtn').on('click', function () {
			if ($('[name=pay_status]').val() == '') {
				alert('付款时间不能为空');
				return false;
			}
			var paid_amount = Number($('[name=paid_amount]').val());
			if (isNaN(paid_amount) || paid_amount == 0) {
				alert('请填写付款金额');
				return false;
			}
			if ($('[name=pay_method]').val() != 'other' && !$('[name=pay_sn]').val()) {
				alert('请输入支付交易号');
				return false;
			}
			dialog.data.pay_status  = $('[name=pay_status]').val();
			dialog.data.paid_amount = paid_amount;
			dialog.data.pay_method  = $(".form-buttonedit-popup input[type=text]").val();
			dialog.data.pay_sn      = $('[name=pay_sn]').val();
			dialog.data.msg         = $('[name=msg]').val();
			$.post(dialog.data.tpl_url, dialog.data , function(ret) {
				dialog.close();
				alert(ret.message);
				if (ret.status != 1) return false;
				window.top.main_frame.location.reload();
			},'json');
		});
		$('#closebtn').on('click', function () {
			dialog.remove();
			return false;
		});
	})
</script>