<?php
class search_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->service = model('goods/goods_sku','service');
	}
	/**
	 * [search 商品搜索页]
	 * @return [type] [description]
	 */
	public function search(){
		$title = '搜索 '.$_GET['keyword'].' 的结果';
		$SEO = seo($title);
		$result = $this->service->search($_GET);
		include template('search_lists');
	}
}