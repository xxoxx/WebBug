<?php
/**
 *		商品咨询逻辑层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class goods_consult_logic extends logic {
	public function __construct() {
		$this->article_logic = model('misc/article','logic');
		$this->db = model('goods_consult');
	}
	/**
	 * [delete 删除咨询]
	 * @$params [array] [数组id]
	 * @return [bool]      [description]
	 */
	public function delete($params){
		if(!$this->article_logic->is_array_null($params)){
			$this->error = '参数错误';
			return FALSE;
		}
		$data = array();
		$data['id'] = array("IN",$params['id']);
		$result = $this->db->where($data)->delete();
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
	}
	/**
	 * [reply 回复咨询]
	 * @$params [array] [数组]
	 * @return [bool]      [description]
	 */
	 public function reply($params){
		 if((int)$params[id] < 1){
			 $this->error = '参数错误';
			 return FALSE;
		 }
		 $data = array();
		 $data['id'] = $params['id'];
		 $data['reply_content'] = $params['reply_content'];
		 $data['reply_time'] = time();
		 $data['status'] = 1;
		 $result = $this->db->update($data);
		 if(!$result){
			 $this->error = $this->db->getError();
			 return FALSE;
		 }
		 return TRUE;
 	 }
	 /**
	 * [add 添加]
	 * @$params [array] [数组]
	 * @return [bool]      [description]
	 */
	 public function add($params){
		if((int)$params['sku_id'] < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		 if(empty($params['question'])){
			 $this->error = '请输入咨询内容';
			 return FALSE;
		 }
		$data = array();
		$data['mid'] = $params['mid'] ? $params['mid'] : '';
		$data['username'] = $params['username'] ? $params['username'] : '';
		$data['sku_id'] = $params['sku_id'];
		$data['spu_id'] = $params['spu_id'];
		$data['question'] = htmlspecialchars(remove_xss($params['question']));
		$data['dateline'] = time();
		$data['clientip'] = $_SERVER['REMOTE_ADDR'];
		$result = $this->db->update($data);
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
 	 }	
	/**
	 * [add 添加]
	 * @$params [array] [数组]
	 * @return [bool]      [description]
	 */
	 public function see($params){
		if((int)$params['mid'] < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		$data = array();
		$data['id'] = $params['id'];
		$data['mid'] = $params['mid'];
		$data['status'] = 1;
		$save['see'] = 1;
		$result = $this->db->where($data)->save($save);
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
 	 }		 
}