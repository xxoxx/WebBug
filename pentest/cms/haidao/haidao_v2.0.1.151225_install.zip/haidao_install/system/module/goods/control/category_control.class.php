<?php
core::load_class('init', 'admin');
class category_control extends init_control {
	protected $service = '';
	public function _initialize() {
		parent::_initialize();
		$this->service = model('goods_category','service');
		$this->type_service =model('type','service');
	}
	/**
	 * [lists 分类列表]
	 */
	public function index(){
		$result = $this->service->category_lists();
		include $this->admin_tpl('category_list');
	}
	/**
	 * [ajax_category ajax获取分类]
	 * @return [type] [description]
	 */
	public function ajax_category(){
		$result = $this->service->ajax_category($_GET['id']);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,$result,'json');
		}
	}
	/**
	 * [get_list 获取分类的子分类]
	 */
	public function get_list(){
		$result = $this->service->category_lists($_GET['parent_id']);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,$result,'json');
		}
	}
	/**
	 * [add 添加分类]
	 */
	public function add(){
		if(checksubmit('dosubmit')) {
			$result = $this->service->add_category($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage(lang('_OPERATION_SUCCESS_'),url('index'));
			}
		}else{
			$parent_name = $this->service->create_cat_format($_GET['pid'],TRUE);
			$cat_format = $this->service->create_parent_format_id($_GET['pid']);
			include $this->admin_tpl('goods_category_edit');
		}
	}
	/**
	 * [edit 编辑分类]
	 */
	public function edit(){
		if(checksubmit('dosubmit')) {
			$result = $this->service->edit_category($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage(lang('_OPERATION_SUCCESS_'),url('index'));
			}
		}else{
			$cate = $this->service->get_category_by_id($_GET['id']);
			include $this->admin_tpl('goods_category_edit');
		}
	}
	/**
	 * [ajax_status 分类列表内更改规格状态]
	 */
	public function ajax_status(){
		$result = $this->service->change_status($_GET['id']);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,$result,'json');
		}
	}
	/**
	 * [ajax_del 删除分类]
	 */
	public function ajax_del(){
		$result = $this->service->delete_category($_GET['id']);
		if(!$result){
			showmessage($this->service->error);
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'));
		}
	}
	/**
	 * [ajax_name ajax更改名称]
	 * @return [type] [description]
	 */
	public function ajax_name(){
		$result = $this->service->change_name($_GET);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,'','json');
		}
	}
	/**
	 * [ajax_sort 改变排序]
	 */
	public function ajax_sort(){
		$result = $this->service->change_sort($_GET);
		if(!$result){
			showmessage($this->service->error);
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'));
		}
	}
	/**
	 * [category_popup 商品选择分类页]
	 * @return [type] [description]
	 */
	public function category_popup(){
		$category = $this->service->get_category_tree();
		include $this->admin_tpl('add_category_popup');
	}
	/**
	 * [category_main 分类选择父级分类页]
	 * @return [type] [description]
	 */
	public function category_main(){
		$category = $this->service->get_parent_tree();
		include $this->admin_tpl('add_category');
	}
	/**
	 * [category_relation 分类选择关联类型页]
	 * @return [type] [description]
	 */
	public function category_relation(){
		$type = $this->type_service->get_all_type();
		include $this->admin_tpl('category_relation_type');
	}
}