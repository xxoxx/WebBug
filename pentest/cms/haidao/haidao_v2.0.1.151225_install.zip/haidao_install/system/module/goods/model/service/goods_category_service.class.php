<?php
/**
 *		商品品牌数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class goods_category_service extends service {
	public function __construct() {
		$this->logic = model('goods/goods_category','logic');
	}
	/**
	 * [category_lists 获取分类列表]
	 * @param  [type] $parent_id [description]
	 * @return [type]            [description]
	 */
	public function category_lists(){
		$result = $this->logic->category_lists();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
     * [ajax_category ajax获取分类]
     * @param  [type] $parent_id [description]
     * @return [type]            [description]
     */
	public function ajax_category($parent_id){
		$result = $this->logic->ajax_category($parent_id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_spec 增加分类]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回添加结果]
	 */
	public function add_category($params){
		$result = $this->logic->add_category($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_spec 编辑分类]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function edit_category($params){
		$result = $this->logic->edit_category($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_status 改变分类状态]
	 * @param  [int] $id [品牌id]
	 * @return [boolean]        [返回改变结果]
	 */
	public function change_status($id){
		$result = $this->logic->change_status($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [delete_spec 删除分类]
	 * @param  [int] $params [分类id]
	 * @return [boolean]         [返回删除结果]
	 */
	public function delete_category($id){
		$result = $this->logic->delete_category($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_sort 改变排序]
	 * @param  [array] $params [品牌id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_sort($params){
		$result = $this->logic->change_sort($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
     * 格式化分类到选择框
     * @param type $data
     */
    public function format_cat($id) {
    	$result = $this->logic->format_cat($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
	/**
	 * [change_sort 改变名称]
	 * @param  [array] $params [品牌id和name]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_name($params){
		$result = $this->logic->change_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_format_category 获取商品分类树]
	 * @return [type] [description]
	 */
	public function get_category_tree(){
		$result = $this->logic->get_category_tree();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_parent 获取所有父级分类]
	 * @param  string  $cid   [需要获取的商品分类id]
	 * @param  integer $istop [是否是顶级分类，默认为1是顶级分类]
	 * @return [array]        [返回父级id数组]
	 */
	public function get_parent($id,$istop = 1){
		$result = $this->logic->get_parent($id,$istop);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	 /**
     * [has_child 判断分类是否有子分类]
     * @param  [type]  $id [分类id]
     * @return boolean     [description]
     */
    public function has_child($id){
    	$result = $this->logic->has_child($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_child 根据父分类获取所有子分类]
	 * @param  [type] $cid [父id]
	 * @return [type]      [所有子分类]
	 */
    public function get_child($cid){
    	$result = $this->logic->get_child($cid);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
	/**
	 * [create_cat_format 生成]
	 * @param  [type] $id [分类id]
	 * @return [type]     [description]
	 */
	public function create_cat_format($id,$extra = FALSE){
		$result = $this->logic->create_cat_format($id,$extra);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [create_format_id 格式父子级分类id]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function create_format_id($id){
		$result = $this->logic->create_format_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [create_parent_format_id 格式父子级分类id]
	 * @param  [type] $pid [description]
	 * @return [type]     [description]
	 */
	public function create_parent_format_id($parent_id){
		$result = $this->logic->create_parent_format_id($parent_id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_cate_grades 获取分类的价格分级]
	 * @param  [type] $id [分类id]
	 * @return [type] [description]
	 */
	public function get_cate_grades($id){
    	$result = $this->logic->get_cate_grades($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
    /**
     * [get_brand_info 获取分类及子分类下的所有品牌信息]
     * @param  [type] $id [description]
     * @return [type]     [description]
     */
    public function get_brand_info($id){
    	$result = $this->logic->get_brand_info($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
    /**
     * [get_category_by_id 根据id获取分类信息]
     * @param  [type] $id [description]
     * @return [type]     [description]
     */
    public function get_category_by_id($id){
    	$result = $this->logic->get_category_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
     }
     /**
      * [get_parent_tree 获取父级分类树]
      * @return [type] [description]
      */
     public function get_parent_tree(){
		$result = $this->logic->get_parent_tree();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
     * [create_category 组织列表页的分类层级显示]
     * @param  [type] $id [description]
     * @return [type]     [description]
     */
    public function create_category($id){
    	$result = $this->logic->create_category($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
}