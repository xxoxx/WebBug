<?php
/**
 *		商品品牌数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class brand_service extends service {
	public function __construct() {
		$this->logic = model('goods/brand','logic');
	}
	/**
	 * [get_lists 获取品牌列表]
	 * @return [type] [description]
	 */
	public function get_lists($page,$limit){
		$result = $this->logic->get_lists($page,$limit);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_spec 增加品牌]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回添加结果]
	 */
	public function add_brand($params){
		$result = $this->logic->add_brand($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_spec 编辑品牌]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function edit_brand($params){
		$result = $this->logic->edit_brand($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_status 改变品牌状态]
	 * @param  [int] $id [品牌id]
	 * @return [boolean]        [返回改变结果]
	 */
	public function change_recommend($id){
		$result = $this->logic->change_recommend($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [delete_spec 删除品牌，可批量删除]
	 * @param  [int || array] $params [品牌id或品牌id数组]
	 * @return [boolean]         [返回删除结果]
	 */
	public function delete_brand($params){
		$result = $this->logic->delete_brand($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_sort 改变排序]
	 * @param  [array] $params [品牌id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_sort($params){
		$result = $this->logic->change_sort($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_sort 改变名称]
	 * @param  [array] $params [品牌id和name]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_name($params){
		$result = $this->logic->change_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_brand_name 获取品牌名称]
	 * @param  [type] $id [品牌id]
	 * @return [type]     [description]
	 */
	public function get_brand_name($id){
		$result = $this->logic->get_brand_name($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [search_brand 关键字查找品牌]
	 * @param  [type] $keyword [description]
	 * @return [type]          [description]
	 */
	public function ajax_brand($keyword){
		$result = $this->logic->ajax_brand($keyword);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_brand_by_id 根据id获取品牌信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_brand_by_id($id){
		$result = $this->logic->get_brand_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
}