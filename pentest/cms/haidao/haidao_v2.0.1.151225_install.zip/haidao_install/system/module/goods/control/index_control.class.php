<?php
class index_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->service = model('goods/goods_sku','service');
		$this->goods_service = model('goods/goods_spu','service');
		$this->cate_db = model('goods/goods_category');
		$this->cate_service = model('goods/goods_category','service');
		$this->type_service = model('goods/type','service');
		$this->goods_category = cache('goods/goods_category');
		$this->brand_service = model('goods/brand','service');
		$this->favorite_service = model('member/member_favorite', 'service');
	}
	public function index(){
		$setting = cache('setting', '', 'common');
	    $site_rewrite = $setting['site_rewrite'];
	    $site_title = $setting['site_name'].' - '.$site_rewrite['site_rewrite_name'];
	    $site_keywords = $site_rewrite['site_rewrite_keyword'];
	    $site_description = $site_rewrite['site_rewrite_descript'];
	    $site_rewrite_other = $site_rewrite['site_rewrite_other'];
		$SEO = seo($site_title, $site_keywords, $site_description,$site_rewrite_other,true);
		include template('index');
	}
	/**
	 * [lists 前台商品列表]
	 * @param  [type] $id [分类id]
	 * @return [type]     [description]
	 */
	public function lists(){
		$category = $this->cate_service->create_category($_GET['id']);
		if(!$category){
			showmessage($this->cate_service->error,url('index'));
		}
		$cat_form = $this->cate_db->where(array('id'=>$category['parent_id']))->getfield('name');
		$title = is_null($cat_form) ? $category['name'] : $category['name'].' - '.$cat_form;
		$SEO = seo($title,$category['keywords'],$category['descript']);
		$brands = $this->cate_service->get_brand_info($_GET['id']);
		$grades = $this->cate_service->get_cate_grades($_GET['id']);
		$result = $this->service->create_sqlmap($_GET);
		include template('lists');
	}
	/**
	 * [detail 前台商品详情页]
	 * @param  [type] $id [商品id]
	 * @return [type] [description]
	 */
	public function detail(){
		$goods = $this->service->detail($_GET['sku_id'],FALSE);
		if(!$goods){
			showmessage($this->service->error,url('index'));
		}
		$sales =  model('goods/goods_index')->where(array('sku_id'=>$_GET['sku_id']))->getField('sales');
		$count = model('comment/comment','service')->get_count($goods['spu_id']);
		$title = $goods['sku_name'].' - '.$goods['cat_name'];
		$SEO = seo($title,$goods['keyword'],$goods['description']);
		$this->service->_history($_GET['sku_id']);
		$this->service->inc_hits($_GET['sku_id']);
		$favorite = $this->service->is_favorite($this->member['id'],$_GET['sku_id']);
		include template('detail');
	}
	/**
	 * [brand_list 品牌详情]
	 * @return [type] [description]
	 */
	public function brand_list(){
		$brand = $this->brand_service->get_brand_by_id($_GET['id']);
		if(!$brand){
			showmessage($this->brand_service->error);
		}
		$SEO = seo($brand['name'],'',$brand['descript']);
		$result = $this->service->create_sqlmap($_GET);
		include template('brand_list');
	}
	/**
	 * [ajax_like 猜你喜欢]
	 * @return [type] [description]
	 */
	public function ajax_like(){
		$sqlmap = array();
		if($_GET['order']){
			$sqlmap['order'] = $_GET['order'];
		}else{
			$sqlmap['order'] = 'rand()';
		}
		if($_GET['limit']){
			$options['limit'] = $_GET['limit'];
		}else{
			$options['limit'] = 5;
		}
		$result = $this->service->lists($sqlmap,$options);
		echo json_encode($result);
	}
	public function ajax_goods(){
		$sqlmap = array();
		$sqlmap['status_ext'] = $_GET['status_ext'];
		$sqlmap['order'] = 'sort asc,id desc';
		$options['limit'] = 5;
		$result = $this->service->lists($sqlmap,$options);
		echo json_encode($result);
	}
}