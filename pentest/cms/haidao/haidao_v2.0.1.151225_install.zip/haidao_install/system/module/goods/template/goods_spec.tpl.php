<?php include $this->admin_tpl('header','admin');?>
<script type="text/javascript" src="./statics/js/goods/jquery.md5.js" ></script>
<script type="text/javascript" src="./statics/js/template.js" ></script>
<script type="text/javascript" src="./statics/js/goods/goods_add.js" ></script>
<div class="fixed-nav layout">
			<ul>
				<li class="first">商品设置</li>
				<li class="spacer-gray"></li>
				<li>1.填写基本信息</li>
				<li>&nbsp;&nbsp;&nbsp;→&nbsp;&nbsp;&nbsp;</li>
				<li class="goods-step">2.设置商品规格</li>
				<li>&nbsp;&nbsp;&nbsp;→&nbsp;&nbsp;&nbsp;</li>
				<li>3.上传商品图册</li>
				<li>&nbsp;&nbsp;&nbsp;→&nbsp;&nbsp;&nbsp;</li>
				<li>4.编辑商品类型</li>
				<li>&nbsp;&nbsp;&nbsp;→&nbsp;&nbsp;&nbsp;</li>
				<li>5.完善商品详情</li>
			</ul>
			<div class="hr-gray"></div>
		</div>
		<div class="content padding-big have-fixed-nav goods-spec">
		<form action="<?php echo url('goods_add',array('step' => 1,'id' => $_GET['id']))?>" method="POST" name="goods_spec" data-validate='true' data-handkey="goods_spec">
			<div class="margin-tb">
				<a class="button bg-main" href="javascript:;" id="setSpec">编辑规格</a>
				<a class="button bg-main" href="javascript:;" id="modifySpec">批量修改</a>
				<a class="button bg-main" href="javascript:;" id="delAll">清空规格</a>
			</div>
			<div class="table resize-table border clearfix">
				<div class="tr border-none spec-name">
					<div class="th" data-width="10">
						<div class="td-con">商品标签</div>
					</div>
					<div class="th" data-width="20">
						<div class="td-con">商品货号</div>
					</div>
					<div class="th" data-width="15">
						<div class="td-con">商品条码</div>
					</div>
					<div class="th" data-width="15">
						<div class="td-con">商品规格</div>
					</div>
					<div class="th" data-width="10">
						<div class="td-con">销售价格</div>
					</div>
					<div class="th" data-width="10">
						<div class="td-con">市场价格</div>
					</div>
					<div class="th" data-width="10">
						<div class="td-con">库存</div>
					</div>
					<div class="th" data-width="10">
						<div class="td-con">操作</div>
					</div>
				</div>
				<input type="hidden" name="spu_sn" value="">
				<div id="goods_spec"></div>
				<script id="spec_template" type="text/html">
				<%var i = 0 %>
				<%for(var item in templateData){%>
                <%item = templateData[item]%>
				<div class="tr spec-list" data-id='<%=item['spec_md5']%>'>
					<div class="icon td">
						<a class="ico ico_promotion <%if(item['status_ext'] != 1){ %>cancel<% }%>" data-value="1" href="javascript:;" title="点击取消促销"></a>
						<a class="ico ico_special <%if(item['status_ext'] != 2){ %>cancel<% }%>" data-value="2" href="javascript:;" title="点击取消特卖"></a>
						<a class="ico ico_new <%if(item['status_ext'] != 3){ %>cancel<% }%>" data-value="3" href="javascript:;" title="点击取消新品"></a>
						<a class="ico ico_reco <%if(item['status_ext'] != 4){ %>cancel<% }%>" data-value="4" href="javascript:;" title="点击取消推荐"></a>
						<input type="hidden" name="status_ext[<%=item['spec_md5']%>]" value="<%=item['status_ext']%>">
					</div>
					<div class="td">
						<div class="td-con"><input class="input" name="sn[<%=item['spec_md5']%>]" type="text" value="<%=item['sn']%>" /></div>
					</div>
					<div class="td">
						<div class="td-con"><input class="input" type="text" name="barcode[<%=item['spec_md5']%>]" value="<%=item['barcode']%>" /></div>
					</div>
					<div class="td">
						<div class="td-con text-left"><span><%=item['spec_str']%></span></div>
						<input type="hidden" name="spec_str[<%=item['spec_md5']%>]" value="<%=item['spec_str']%>">
						<%for(var n in item['spec']){%>
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][id]" value="<%=item['spec'][n]['id']%>">
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][name]" value="<%=item['spec'][n]['name']%>">
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][value]" value="<%=item['spec'][n]['value']%>">
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][style]" value="<%=item['spec'][n]['style']%>">
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][color]" value="<%=item['spec'][n]['color']%>">
						<input type="hidden" name="spec[<%=item['spec_md5']%>][<%=n%>][img]" value="<%=item['spec'][n]['img']%>">
						<% }%>
					</div>
					<div class="td">
						<div class="td-con"><input class="input" type="text" nullmsg="销售价格必须为数字" datatype="price" name="shop_price[<%=item['spec_md5']%>]" value="<%=item['shop_price']?item['shop_price']:'0.00'%>" /></div>
					</div>
					<div class="td">
						<div class="td-con"><input class="input" type="text" nullmsg="市场价格必须为数字" datatype="price" name="market_price[<%=item['spec_md5']%>]" value="<%=item['market_price']?item['market_price']:'0.00'%>" /></div>
					</div>
					<div class="td">
						<div class="td-con"><input class="input" type="text" nullmsg="库存必须为数字" datatype="n" name="number[<%=item['spec_md5']%>]" value="<%=item['number']?item['number']:'0'%>" /></div>
					</div>
					<div class="td">
						<input class="hidden" data-id="<%=item['sku_id']%>" name="sku_id[<%=item['spec_md5']%>]" type="text" value="<%=item['sku_id']%>" />
						<a href="javascript:;" class="delSpec">删除</a>
					</div>
				</div>
				<%i++;%>
				<%}%>
			</script>
		</div>
			<div class="margin-tb">
				<input type="submit" class="button bg-main" name="dosubmit" id="goods_spec_sub" value="下一步" />
				<a class="button margin-left bg-gray" data-back="false" id="back">上一步</a>
			</div>
		</form>
		<script>
		$(function(){
			$(".table").resizableColumns();
			init_template();
			$(window).resize();
			$('input[name="sn[]"]').eq(0).val($('input[name=spu_sn]').val()+'-1');
			<?php if (isset($info['skus'])): ?>
				var info = <?php echo json_encode($info['skus']) ?> ;
				var goodsRowHtml = template('spec_template', {'templateData': info});
				$('#goods_spec').html(goodsRowHtml); 
			<?php endif ?>
		})
			var url = "<?php echo url('goods_add',array('id'=>$_GET['id'],'step'=>1))?>";
			var back = "<?php echo url('goods_add',array('id'=>$_GET['id']))?>";
			save_back(url,back);
			setInterval("auto_save(url)",30000);
			var goods_spec = $("[name=goods_spec]").Validform({
				ajaxPost:true,
				callback:function(result) {
					if(result.status == 1){
						var nexturl = "<?php echo url('goods_add',array('step' => 2,'id' => $_GET['id']))?>";
						window.location = nexturl;
					}else{
						alert(result.message);
					}
				}
			});
			var selectedItem = <?php echo $info['extra'] ? $info['extra'] : '[]';?> ;
			var defaultProductNo = "<?php echo 'NU'.time().rand(10,99)?>";
			var defaultNU = $('input[name="sn[]"]').eq(0).val();
			if(!defaultNU){
				$('input[name="sn[]"]').eq(0).val(defaultProductNo+'-1');
				$('input[name=spu_sn]').val(defaultProductNo);
			}else{
				productNo = $('input[name="sn[]"]').eq(0).val().split('-');
				$('input[name=spu_sn]').val(productNo[0]);
			}
			var n = 1;
			$('.table .tr:last-child').addClass("border-none");
			 $(".icon a.ico").live('click',function(){
		     	if(!$(this).hasClass("cancel")){
		     		$(this).addClass("cancel");
		     	}else{
		     		$(this).removeClass("cancel").siblings(".ico").addClass("cancel");
		     		$(this).parent().find('input').val($(this).attr('data-value'));
		     	}
		     });
			function init_template() {
				var goodsRowHtml = template('spec_template', {'templateData': [[]]});
				$('#goods_spec').html(goodsRowHtml); 
			}
			$('#setSpec').live('click',function(){
				var url = "<?php echo url('goods_spec_pop',array(id=>$_GET['id']))?>";
				var productNu = selectedItem ? defaultProductNo+'-1' :$('input[name="sn[]"]').eq(0).val();
				top.dialog({
					url: url,
					title: '加载中...',
					width: 681,
					data : selectedItem,
					onclose: function () {
						if(this.returnValue){
							var	addSpecObject = this.returnValue;
							//开始遍历规格
							var specValueData = {}
							var specData = {};
							var selectedNewItem = [];
							var selectType = 0;
							addSpecObject.each(function() {
								if ($(this).hasClass('new-prop') == true) {	// 如果是全选则排除添加属性这个<li>
									return true;
								}
								var data_id = $(this).attr('data-id');
								var data_name = $(this).attr('data-name');
								var data_value = $(this).attr('data-value');
								var data_style = $(this).attr('data-style');
								var data_color = $(this).attr('data-color');
								var data_img = $(this).attr('data-img');
								selectType = $(this).attr('data-type') ? $(this).attr('data-type') : 0;
								if (typeof(specValueData[data_id]) == 'undefined') {
									specValueData[data_id] = [];
								}
								specValueData[data_id].push({
									'value':data_value,
									'img':data_img,
									'color':data_color
								});
								specData[data_id] = {
									'id': data_id,
									'name': data_name,
									'style': data_style,
								};
								selectedNewItem.push({
									'id': data_id,
									'value': data_value,
									'color': data_color,
									'img':data_img,
									'style':data_style
								});
							});
							selectedItem = selectedNewItem;
							//生成货品的笛卡尔积
							var specMaxData = descartes(specValueData, specData);
							//从表单中获取默认商品数据
							var productJson = {};
							productJson['sn'] = productNu;
							productNo = productNu.split('-');
							$('input[name=spu_sn]').val(productNo[0]);
							//生成最终的货品数据
							var productList = [];
							for (var i = 0; i < specMaxData.length; i++) {
								var productItem = {};
								productItem['spec_array'] = specMaxData[i];
								for (var index in productJson) {
									//自动组建货品
									if (index == 'sn') {
										//值为空时设置默认货号
										if (productJson[index] == '') {
											productJson[index] = defaultProductNo;
										}
										if (productJson[index].match(/(?:\-\d*)$/) == null) {
											//正常货号生成
											productItem['sn'] = productJson[index] + '-' + (i + 1);
										}else{
											//货号已经存在则替换
											productItem['sn'] = productJson[index].replace(/(?:\-\d*)$/, '-' + (i + 1));
										}
									} else {
										productItem[index] = productJson[index];
									}
								}
								productList.push(productItem);
							}
							var selectArr = [];
							$.each(productList,function(i,item){
								var spec = spec_string  = specJson = '';
								for(var j = 0;j < (item.spec_array.length);j++){
									spec_string += item.spec_array[j].name + ':' +item.spec_array[j].value +' ';
									spec_md5 = $.md5(spec_string);
								}
								productList[i]['spec'] = item.spec_array;
								productList[i]['spec_str'] = spec_string;
								productList[i]['spec_md5'] = spec_md5;
								selectArr.push(spec_md5);
							});
							if(selectType == 1){
								if(productList.length != 0){
									init_template();
								}
								var goodsRowHtml = template('spec_template', {'templateData': productList});
								$('#goods_spec').html(goodsRowHtml); 
							}else{
								var specArr = [];
								$('.spec-list').each(function(){
									specArr.push($(this).attr('data-id'));
								})
								var select_diff = chaji_array(selectArr,specArr);
								var spec_diff = chaji_array(specArr,selectArr);
								//新增
								if(spec_diff.length == 0 && select_diff.length == 0){
									var goodsRowHtml = template('spec_template', {'templateData': productList});
									$('#goods_spec').html(goodsRowHtml); 
								}
								if(select_diff.length > 0){
									var speclist = [];
									$.each(productList,function(i,item){
										var spec = specJson = '';
										for(var j = 0;j < (item.spec_array.length);j++){
											spec += item.spec_array[j].name + ':' +item.spec_array[j].value +' ';
											spec_md5 = $.md5(spec);
										}
										if($.inArray(spec_md5, select_diff) > -1){
											speclist.push(productList[i])
										}
									});
								}
								var goodsRowHtml = template('spec_template', {'templateData': speclist});
								$('#goods_spec').append(goodsRowHtml); 
								//删减
								if(spec_diff.length > 0){
									$.each(spec_diff,function(i,item){
										var del_id = $("div[data-id='"+ item +"']").find('input[name="_sku_ids[]"]').val();
										$('.table').append('<input type="hidden" name="del_sku_ids[]" value="'+del_id+'">');
										$("div[data-id='"+ item +"']").remove();
									})
								}

							}
							$(window).resize();
 						}
					}
				})
				.showModal();
			});
			
			$("#modifySpec").live('click',function(){
				top.dialog({
					url: "<?php echo url('goods_spec_modify')?>",
					title: '加载中...',
					width: 360,
					data : selectedItem,
					onclose: function(){
						if(this.returnValue){
							_shop_price_change 		= this.returnValue[0];
		    				_market_price_change 	= this.returnValue[1];
		    				_goods_number_change 	= this.returnValue[2];
		    				var num_reg = /^[-\+]?\d*$/;
		    				var price_reg = /^[-\+]?\d+(\.\d{2})?$/;
		    				if(!(num_reg.test(_goods_number_change)) || !(price_reg.test(_shop_price_change)) || !(price_reg.test(_market_price_change))){
		    					alert('请输入正确的数字!');
		    					return false;
		    				}
		    				//销售价
		    				$('[name^="shop_price"]').each(function(index,data){
		    					num = Number($(this).val()) + Number(_shop_price_change);
		    					num = num < 0 ? 0 : num;
		    					$(this).val(num.toFixed(2));
		    				})
		    				//市场价
		    				$('[name^="market_price"]').each(function(index,data){
		    					num = Number($(this).val()) + Number(_market_price_change);
		    					num = num < 0 ? 0 : num;
		    					$(this).val(num.toFixed(2));
		    				})
		    				//库存
		    				$('[name^="number"]').each(function(index,data){
		    					num = parseInt($(this).val()) + parseInt(_goods_number_change);
		    					num = num < 0 ? 0 : num;
		    					$(this).val(num);
		    				})
						}
					}
				}).showModal();
			});
			
			function chaji_array(arr1,arr2){
				var arr3 = [];
				for (var i = 0; i < arr1.length; i++) {
			        var flag = true;
			        for (var j = 0; j < arr2.length; j++) {
			            if (arr2[j] == arr1[i]) {
			                flag = false;
			            }
			        }
			    	if (flag) {
			            arr3.push(arr1[i]);
			        }
			    }
				return arr3;
			}
			//笛卡儿积组合
			function descartes(list, specData) {
				//parent上一级索引;count指针计数
				var point = {};
				var result = [];
				var pIndex = null;
				var tempCount = 0;
				var temp = [];
				//根据参数列生成指针对象
				for (var index in list) {
					if (typeof list[index] == 'object') {
						point[index] = {
							'parent': pIndex,
							'count': 0
						}
						pIndex = index;
					}
				}
				//单维度数据结构直接返回
				if (pIndex == null) {
					return list;
				}
				//动态生成笛卡尔积
				while (true) {
					for (var index in list) {
						tempCount = point[index]['count'];
						temp.push({
							"id": specData[index].id,
							"name": specData[index].name,
							"style":specData[index].style,
							"color":list[index][tempCount].color,
							"img":list[index][tempCount].img,
							"value": list[index][tempCount].value
						});
					}
					//压入结果数组
					result.push(temp);
					temp = [];
					//检查指针最大值问题
					while (true) {
						if (point[index]['count'] + 1 >= list[index].length) {
							point[index]['count'] = 0;
							pIndex = point[index]['parent'];
							if (pIndex == null) {
								return result;
							}

							//赋值parent进行再次检查
							index = pIndex;
						} else {
							point[index]['count'] ++;
							break;
						}
					}
				}
			}
			$('.delSpec').live('click',function(){
				$(this).parent().parent('.tr').remove();
			})
			function delAll(){
				init_template();
				$('input[name="sn[]"]').eq(0).val($('input[name=spu_sn]').val()+'-1');
				selectedItem = [];
				$(window).resize();
			}
			$('#delAll').live('click',function(){
				$('.table').children('.spec-list').remove();
				delAll();
			})
		</script>
	</body>
</html>
