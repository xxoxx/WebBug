<?php
/**
 *		规格模型数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class spec_service extends service {
	public function __construct() {
		$this->logic = model('goods/spec','logic');
	}
	/**
	 * [spec_list 规格列表]
	 * @return [array] [规格列表信息]
	 */
	public function spec_list($page,$limit){
		$result = $this->logic->spec_list($page,$limit);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_spec 增加规格]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回添加结果]
	 */
	public function add_spec($params){
		$result = $this->logic->add_spec($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [edit_spec 编辑规格]
	 * @param  [array] $params [规格信息]
	 * @return [boolean]         [返回编辑结果]
	 */
	public function edit_spec($params){
		$result = $this->logic->edit_spec($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_status 改变规格状态]
	 * @param  [int] $id [规格id]
	 * @return [boolean]        [返回改变结果]
	 */
	public function change_status($id){
		$result = $this->logic->change_status($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [delete_spec 删除规格，可批量删除]
	 * @param  [int || array] $params [规格id或规格id数组]
	 * @return [boolean]         [返回删除结果]
	 */
	public function delete_spec($params){
		$result = $this->logic->delete_spec($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_sort 改变排序]
	 * @param  [array] $params [规格id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_sort($params){
		$result = $this->logic->change_sort($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_name 改变名称]
	 * @param  [array] $params [品牌id和name]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_name($params){
		$result = $this->logic->change_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_type_by_id 根据id获取规格信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_spec_by_id($id){
		$result = $this->logic->get_spec_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_add_spec ajax增加规格]
	 * @param  [type] $name [description]
	 * @return [type]       [description]
	 */
	public function ajax_add_spec($name){
		$result = $this->logic->ajax_add_spec($name);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_add_pop ajax增加规格属性]
	 * @param  [type] $name [description]
	 * @return [type]       [description]
	 */
	public function ajax_add_pop($params){
		$result = $this->logic->ajax_add_pop($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_spec_name 获取规格名称]
	 * @param  [type] $name [description]
	 * @return [type]       [description]
	 */
	public function get_spec_name(){
		$result = $this->logic->get_spec_name();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
}