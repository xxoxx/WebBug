<?php
/* 更新商品分类缓存 */
$this->db = model('goods/goods_category');
$result = $this->db->getField(implode(',', array_keys($this->db->get_fields())), TRUE);
cache('goods/goods_category', $result);