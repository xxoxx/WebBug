<?php
core::load_class('init', 'admin');
class sku_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->service = model('goods/goods_sku','service');
		$this->cate_service = model('goods_category','service');
		$this->cate_db = model('goods_category');
		$this->brand_service = model('brand','service');
		$this->brand_db = model('brand');
	}
	/**
	 * [search 商品搜索页]
	 * @return [type] [description]
	 */
	public function select(){
		$_GET['limit'] = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? $_GET['limit'] : 5;
		$skus = $this->service->get_lists($_GET);
		$pages = $this->admin_pages($skus['count'], $_GET['limit']);
		if($_GET['catid']){
			$cate = $this->cate_db->detail($_GET['catid'],'id,name')->output();
		}
		if($_GET['brand_id']){
			$brand = $this->brand_db->detail($_GET['brand_id'],'id,name')->output();
		}
		$category = $this->cate_service->get_category_tree();
		$brands = $this->brand_service->get_lists();
		include $this->admin_tpl('ajax_sku_list_dialog');
	}
	public function ajax_lists(){
		$_GET['limit'] = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? $_GET['limit'] : 5;
		$lists = $this->service->get_lists($_GET);
		$lists['pages'] = $this->admin_pages($lists['count'], $_GET['limit']);
		echo json_encode($lists);
	}
}