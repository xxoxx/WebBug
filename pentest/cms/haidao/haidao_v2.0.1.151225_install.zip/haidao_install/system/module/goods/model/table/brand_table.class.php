<?php
/**
 *		商品品牌数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class brand_table extends table {
	protected $result;
	protected $_validate = array(
        array('name', 'require', '品牌名称不能为空',table::MUST_VALIDATE),
        array('sort','number','排序只能为数字',table::EXISTS_VALIDATE,'regex'),
        array('isrecommend','number','商品推荐参数必须为数字',table::EXISTS_VALIDATE,'regex'),
    );
    protected $_auto = array(
    );
     public function detail($id,$field){
        $this->result['brand'] = $this->field($field)->find($id);
        return $this;
    }
    public function output(){
        return $this->result['brand'];
    }
}