<?php
/**
 *		商品咨询数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class goods_consult_service extends service {
	public function __construct() {
		$this->logic = model('goods/goods_consult','logic');
	}
	/**
	 * [delete 删除咨询]
	 * @$params [array] [数组id]
	 * @return [type]      [description]
	 */
	public function delete($params){
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [reply 删除咨询]
	 * @$params [array] [数组]
	 * @return [type]      [description]
	 */
	public function reply($params){
		$result = $this->logic->reply($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add 添加]
	 * @$params [array] [数组]
	 * @return [type]      [description]
	 */
	public function add($params){
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [user_consult 会员咨询列表 ]
	 * @$params [array] [数组]
	 * @return [type]      [description]
	 */
	public function user_consult($mid,$page){
		$userinfo = model('goods_consult')->where(array('mid' => array('eq',$mid)))->page($page)->limit(10)->order('id DESC')->select();
		foreach($userinfo as $k => $v){
			 $userinfo[$k]['goods_detail'] =  model('goods/goods_sku')->detail($v['sku_id'])->create_spec()->output();
		}
		return $userinfo;
	}
	/**
	 * [see 添加]
	 * @$params [array] [数组]
	 * @return [type]      [description]
	 */
	public function see($params){
		$result = $this->logic->see($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_user_consult 添加]
	 * @$params [array] [数组]
	 * @return [type]      [description]
	 */
	public function get_user_consult($mid){
		$mid = (int)$mid;
		if($mid < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		$data = array();
		$data['mid'] = $mid;
		$data['status'] = 1;
		$data['see'] = 0;
		$count = model('goods/goods_consult')->where($data)->count();
		if($count < 1){
			return FALSE;
		}
		return $count;
	}
	public function handle(){
		$data = array();
		$data['status'] = 0;
		$counts = model('goods/goods_consult')->where($data)->count();
		return (int)$counts;
	}
	
}