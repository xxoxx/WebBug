<?php
/**
 *		子商品逻辑层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class goods_sku_logic extends logic {
	public function __construct() {
		$this->sku_db = model('goods/goods_sku');
		$this->spu_db = model('goods/goods_spu');
		$this->index_db = model('goods/goods_index');
		$this->cate_db = model('goods/goods_category');
		$this->goodsattr_db = model('goods/goods_attribute');
		$this->cate_service = model('goods/goods_category','service');
		$this->brand_service = model('goods/brand','service');
		$this->attr_db = model('goods/attribute');
		$this->favorite_service = model('member/member_favorite', 'service');
		$this->prom_time_db = model('promotion/promotion_time');
		$this->prom_group_db = model('promotion/promotion_group');
	}
	/**
	 * [create_sku 处理子商品]
	 * @param  [type] $params [子商品信息]
	 * @return [type]         [boolean]
	 */
	public function create_sku($params){
		if(!empty($params['del'])){
			$map = array();
			$map['sku_id'] = array("IN", $params['del']);
			$this->sku_db->where($map)->delete();
		}
		$unit = new unit();
		//sku新增数据处理
		if(isset($params['new'])){
			foreach ($params['new'] as $key => $new_data) {
				$new_data['thumb'] =  $new_data['imgs'][0] ? $new_data['imgs'][0] : '';
				$new_data['imgs'] = $new_data['imgs'] ? json_encode($new_data['imgs']) : '';
				$new_data['spec'] = !empty($new_data['spec']) ? $unit->array2json($new_data['spec']) : '';
				$params['new'][$key]['sku_id'] = $this->sku_db->update($new_data);
			}
		}
		//sku编辑数据处理
		if(isset($params['edit'])){
			foreach ($params['edit'] AS $edit_data) {
				$edit_data['thumb'] = $edit_data['imgs'][0] ? $edit_data['imgs'][0] : '';
				$edit_data['imgs'] = $edit_data['imgs'] ? json_encode($edit_data['imgs']) : '';
				$edit_data['spec'] = !empty($edit_data['spec']) ? $unit->array2json($edit_data['spec']) : '';
				$this->sku_db->update($edit_data);
			}
		}
		return $params;
	}
	/**
	 * [sku_edit 编辑sku]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function sku_edit($params){
		if($params['sku_id'] < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		if(empty($params['sku_name'])){
			$this->error = '商品名称不能为空';
			return FALSE;
		}
		$params['imgs'] = $params['images'] ? json_encode($params['images']) : '';
		$params['thumb'] = $params['images'][0] ? $params['images'][0] : '';
		$result = $this->sku_db->update($params);
		$this->index_db->where(array('sku_id' => $params['sku_id']))->save(array('show_in_lists' => $params['show_in_lists']));
		if($result === FALSE){
			$this->error = $this->sku_db->getError();
			return FALSE;
		}else{
			return TRUE;
		}
	}
	/**
	 * [get_sku_names 生成子商品名称]
	 * @param  [type] $params [商品参数]
	 * @return [array]         [子商品名称数组]
	 */
	public function create_sku_name($spec_array){
		$name = '';
		foreach ($spec_array as $k => $v) {
			$name .= $v['value'].' ';
		}
		return $name;
	}
	/**
	 * [get_lists 获取商品sku列表]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function get_lists($params){
		$spu = config("DB_PREFIX").'goods_spu';
		$sqlmap = array();
		if(!empty($params['catid'])){
			if($this->cate_service->has_child($params['catid'])){
				$catid = $this->cate_service->get_child($params['catid']);
			}else{
				$catid= array(0 => $params['catid']);
			}
			$sqlmap['catid'] = array('IN',$catid);
		}
		if(!empty($params['brand_id'])){
			$sqlmap['brand_id'] = $params['brand_id'];
		}
		$sqlmap[config("DB_PREFIX").'goods_sku.status'] = 1;
		if(!empty($params['keyword'])){
			 $sqlmap['sku_name|'.config("DB_PREFIX").'goods_sku.sn|barcode'] = array("LIKE", '%'.$params["keyword"].'%');
		}
		$sku_ids = $this->sku_db->join($spu.' on '.'id = spu_id')->where($sqlmap)->page($params['page'])->limit($params['limit'])->getField('sku_id',TRUE);
		$result['count'] =$this->sku_db->field('sku_id,'.config("DB_PREFIX").'goods_spu.sn AS osn')->join(config("DB_PREFIX").'goods_spu on '.'id = spu_id')->where($sqlmap)->count();
		foreach ($sku_ids AS $sku_id) {
			$result['lists'][] = $this->detail($sku_id,TRUE);
		}
		return $result;
	}
	/**
	 * 指定商品减少库存
	 * @param [int] $id 子商品ID
	 * @param [int] $number变更数量
	 * @return bool
	 */
	public function set_dec_number($id, $number) {
		$sku_id = (int) $id;
		$number = (int) $number;
		if($id < 1 || $number < 1) {
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$sqlmap = $map = array();
		$map['sku_id'] = $id;
		$sqlmap['id'] = $this->sku_db->where(array('sku_id'=>$id))->getField('spu_id');
		$result = $this->sku_db->where($map)->setDec('number', $number);
		$_result = $this->spu_db->where($sqlmap)->setDec('sku_total',$number);
		if(!$result){
			$this->error = $this->sku_db->getError();
			return FALSE;
		}else{
			return TRUE;
		}
	}
	/**
	 * 指定商品增加库存
	 * @param [int] $sku_id 子商品ID
	 * @param [int] $goods_num变更数量
	 * @return bool
	 */
	public function set_inc_number($id, $number) {
		$id = (int) $id;
		$number = (int) $number;
		if($id < 1 || $number < 1) {
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$sqlmap = $map = array();
		$map['sku_id'] = $id;
		$sqlmap['id'] = $this->sku_db->where(array('sku_id'=>$id))->getField('spu_id');
		$result = $this->sku_db->where($map)->setInc('number', $number);
		$_result = $this->spu_db->where($sqlmap)->setInc('sku_total',$number);
		if(!$result){
			$this->error = $this->sku_db->getError();
			return FALSE;
		}else{
			return TRUE;
		}
	}	
	/**
	 * [is_favorite 判断商品是否已收藏]
	 * @param  [type]  $id [description]
	 * @return boolean     [description]
	 */
	public function is_favorite($mid,$id){
		if((int)$id < 1) return FALSE;
		$favorite = FALSE;
		if($mid > 0){
			$favorite = $this->favorite_service->set_mid($mid)->is_exists($id);
		}
		return $favorite;
	}
	/**
	 * [detail 查询子商品详情]
	 * @param  [type]  $id    [子商品id]
	 * @return [type]         [description]
	 */
	public function detail($id,$flag = FALSE){
		if ((int) $id < 1) {
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$goods_info = array();
		$goods_info = $this->sku_db->detail($id,TRUE,'goods')->output();
		if (!$goods_info['sku_id']) {
			$this->error = '商品不存在';
			return FALSE;
		}
		if($flag == FALSE){
			if((int)$goods_info['status'] != 1){
				$this->error = '商品已删除或未上架';
				return FALSE;
			}
		}else{
			$goods_info['catname'] = $this->cate_service->create_cat_format($goods_info['catid']);
		}
		$sku_list = $this->sku_db->where(array('spu_id'=>$goods_info['spu_id']))->select();
		if($sku_list){
			$sku = array();
			foreach ($sku_list AS $v) {
				$v['spec_array'] = json_decode($v['spec'],TRUE);
				$sku[$v['sku_id']] = $v;
			}
		}
		if($sku){
			foreach ($sku as $k => $v) {
				$spec_arr = $v['spec_array'];
				$spec_md5 = '';
				$spec_md = array();
				foreach ($spec_arr AS $value) {
					$spec_md[] = md5($value['id'].':'.$value['value']);
					$spec_md5 .= $value['id'].':'.$value['value'].';';
				}
				$sku[$k]['spec_md5'] = $spec_md5;
				$sku[$k]['spec_md'] = implode(";", $spec_md);
				$sku_arr[$spec_md5] = $sku[$k];

			}
			$goods_info['sku_arr'] = $sku_arr;
		}
		$spec_str = '';
		foreach (json_decode($goods_info['spec'],TRUE) AS $spec) {
			$spec_str .= $spec['id'].':'.$spec['value'].';';
			$spec_show .= $spec['name'].':'.$spec['value'].'&nbsp;&nbsp;';
		}
		$goods_info['spec_str'] = $spec_str;
		$goods_info['spec_show'] = $spec_show;
		$goods_info['specs'] = json_decode($goods_info['specs'],TRUE);
		$goods_info['attrs'] = $this->attrs_detail($id);
		return $goods_info;
	}
	
	/**
	 * [fetch_by_id 获取一条子商品信息]
	 * @param  [type]  $id    [description]
	 * @param  boolean $field [description]
	 * @return [type]         [description]
	 */
	public function fetch_by_id($id,$field = TRUE){
		$sku = $this->sku_db->detail($id,$field,'goods')->output();
		$sku['spec'] = json_decode($sku['spec'],TRUE);
		return $sku;
	}
	/**
	 * [get_sku 根据主商品获取子商品]
	 * @param  [type] $id [主商品id]
	 * @return [type]     [description]
	 */
	public function get_sku($id){
		$skus = $this->sku_db->where(array('spu_id' => $id,'status' => array('NEQ',-1)))->order('sku_id ASC')->select();
		$result = array();
		foreach ($skus as $key => $sku) {
			$sku['spec'] = json_decode($sku['spec'],TRUE);
			$sku['imgs'] = json_decode($sku['imgs'],TRUE);
			$result[$key] = $sku;
			$spec_str = '';
			foreach ($sku['spec'] AS $_spec_array) {
				$spec_str .= $_spec_array['name'].':'.$_spec_array['value'].' ';
				$spec_md5 = md5($spec_str);
			}
			$result[$key]['spec_md5'] = $spec_md5;
			$result[$key]['spec_str'] = $spec_str;
		}
		if(!$result){
			$this->error = $this->sku_db->getError();
		}
		return $result;
	}
	/**
	 * [get_sku_ids 默认根据主商品获取子商品id，$flag为TRUE时查询子商品的同父级子商品]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_sku_ids($id,$isspu = TRUE){
		$spu_id = $id;
		if($isspu == 'false'){
			$spu_id = $this->sku_db->where(array('sku_id' => $id))->getField('spu_id');
		}
		$sku_ids = $this->sku_db->where(array('spu_id'=>$spu_id))->getfield('sku_id',TRUE);
		if(!$sku_ids){
			$this->error = $this->sku_db->getError();
		}
		return $sku_ids;
	}
	/**
	 * [get_selected 获取选中的规格]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_selected($id){
		$sku_ids = $this->sku_db->where(array('spu_id'=>$id))->getfield('sku_id',TRUE);
		$specs = $selectedItem = array();
		foreach ($sku_ids AS $ids) {
			$specs = $this->get_sku_spec($ids);
			foreach ($specs AS $spec) {
				$item = array();
				$item['id'] = $spec['id'];
				$item['name'] = $spec['name'];
				$item['value'] = $spec['value'];
				$item['style'] = $spec['style'];
				$item['color'] = $spec['color'];
				$item['img'] = $spec['img'];
				$selectedItem[] = $item;
			}
		}
		$selectedItem = more_array_unique($selectedItem);
		if(!empty($selectedItem)){
			$selectedItem = json_encode($selectedItem);
		}
		return $selectedItem;
	}
	/**
	 * [_history 商品历史浏览记录]
	 * @param  integer $goods_id [description]
	 * @return [type]            [description]
	 */
	public function _history($id) {
		$id = (int) $id;
		if($id < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		} 
		$_history = cookie('_history');
		$_history = explode(',',$_history);
		if(empty($_history) || !in_array($id, $_history)) {
			array_unshift($_history, $id);
		}
		// 去除前20个为有效值
		$_history = array_slice($_history, 0, 20);
		cookie('_history', implode(',',$_history));
		return TRUE;
	}
	/**
	 * [get_sku_spec 根据子商品id获取]
	 * @param  [type] $catid [description]
	 * @return [type]        [description]
	 */
	public function get_sku_spec($id){
		if((int)$id < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		} 
		$_spec_array = $this->sku_db->where(array('sku_id'=>$id))->getfield('spec');
		$spec_array = json_decode($_spec_array,TRUE);
		return $spec_array;
	}
	/**
	 * [get_sku_grades 根据分类和子商品价格生成子商品的商品价格范围]
	 * @param  [type] $id [description]
	 * @param  [type] $sku_price [子商品价格]
	 * @return [type]     [description]
	 */
	public function get_sku_grades($catid,$sku_price){
		if((int)$catid < 0){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		if((int)$sku_price < 0){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$grades = $_grade_arr = $grade_arr = $_price_grade = $price_grade = array();
		$grades = $this->cate_db->where(array('id'=>$catid))->getField('grade');
		$_grade_arr = explode(',',$grades);
		foreach ($_grade_arr as $value) {
			$grade_arr[] = explode('-',$value);
		}
		foreach ($grade_arr as $k => $v) {
			if($sku_price >= $v[0] && $sku_price <= $v[1]){
				$_price_grade = $v;
			}
		}
		$price_grade=implode('-', $_price_grade);
		return $price_grade;
	}
	/**
	 * [inc_hits 更新浏览记录]
	 * @param  [type] $id [商品Id]
	 * @return [type]     [description]
	 */
	public function inc_hits($id){
		if((int)$id < 0){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$result = $this->index_db->where(array('sku_id' => $id))->setInc('hits');
		if(!$result){
			$this->error = $this->sku_db->getError();
		}
		return $result;
	}
	/**
	 * [attrs_detail 获取商品属性信息]
	 * @param  [type] $id [商品id]
	 * @return [type]     [description]
	 */
	public function attrs_detail($id){
		if((int)$id < 0){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$goods_attrs = $_goods_attrs = $attrs = array();
		$goods_attrs = $this->goodsattr_db->where(array('sku_id'=>$id,'type'=>1))->select();
		foreach ($goods_attrs as $key => $value) {
			$attrinfo[$key] = $this->attr_db->where(array('id'=>$value['attribute_id']))->field('name')->find();
			if($value['attribute_value']){
				$attrs[$key]['name'] = $attrinfo[$key]['name'];
				$attrs[$key]['value'] = $value['attribute_value'];
			}
		}
		$temp = array();
		foreach($attrs as $item) {
		    list($n, $p) = array_values($item);
		    $temp[$n] =  array_key_exists($n, $temp) ? $temp[$n].','.$p : $p;
		}
		$arr = array();
		foreach($temp as $p => $n){
		    $arr[] = $p.'：'.$n;
		}
		return $arr;
	}
	/**
	 * [ajax_statusext ajax更改状态标签状态]
	 * @return [type] [description]
	 */
	public function ajax_statusext($params){
		$data = array();
		$statusext = $this->sku_db->where(array('sku_id'=>$params['sku_id']))->getField('status_ext');
		if($params['status_ext'] == $statusext){
			$data['status_ext'] = 0;
		}else{
			$data['status_ext'] = $params['status_ext'];
		}
		if(!is_null($data['status_ext'])){
			$result = $this->sku_db->where(array('sku_id'=>$params['sku_id']))->save($data);
			$this->index_db->where(array('sku_id'=>$params['sku_id']))->save($data);
		}
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [goods_detail 外部调用商品详情接口]
	 * @param  [type] $ids   [description]
	 * @param  [type] $field [description]
	 * @return [type]        [description]
	 */
	public function goods_detail($ids,$field){
		if(empty($ids)){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$result = $goods = array();
		if(is_array($ids)){
				foreach ($ids AS $id) {
	    		$result = $this->sku_db->detail($id,$field,'goods')->create_spec()->output();
	    		if(!empty($result)){
	    			$goods[] = $result;
	    		}
	    	}
	    }else{
	    	$goods = $this->sku_db->detail($ids,$field,'goods')->create_spec()->output();
	    }
    	if(empty($goods)){
    		$this->error = '商品不存在';
    		return FALSE;
    	}
    	return $goods;
    }
    /**
	 * [create_user_price 计算会员折扣价]
	 * @param  [type] $price [description]
	 * @return [type]        [description]
	 */
	public function create_user_price($price){
		return $price;
	}
    /**
	 * [goods_attr_screen 根据商品属性筛选]
	 * @param  [type] $attrs [选择的商品属性值]
	 * @return [arr]        [description]
	 */
	public function goods_attr_screen($attrs){
		$_sqlmap = $_join = $_goods_ids = array();
		$_count = 0;
		foreach ($attrs as $k => $attr) {
			list($_type, $_id) = explode("_", $k);
			$_id = (int) $_id;
			if($_id < 1 || empty($attr)) continue;
			$_count++;
			$type = ($_type == 'att') ? 1 : 2;
			$_join[] = "(`attribute_id` = '".$_id."' AND `attribute_value` = '".$attr."' AND `type` = '".$type."')";
		}
		if(!empty($_join)) $_sqlmap['_string'] = JOIN(" OR ", $_join);
		$_goods_ids = $this->goodsattr_db->where($_sqlmap)->group('sku_id')->having('count(sku_id) >= '.$_count)->getField('sku_id', TRUE);
		$_goods_ids = ($_goods_ids) ? implode(',',$_goods_ids) : -1;
		return $_goods_ids;
	}
	/**
	 * [lists 查询商品列表]
	 * @return [type] [description]
	 */
	public function lists($sqlmap = array(),$options = array()){
		$sqlmap = $this->build_goods_map($sqlmap);
		$map = array();
		if(!empty($sqlmap['status_ext'])){
			$map['status_ext'] = $sqlmap['status_ext'];
			unset($sqlmap['status_ext']);
		}
		$goods_ids = $this->build_goods_ids($sqlmap);
		if(isset($sqlmap['price'])){
			$map = $this->build_sku_map($sqlmap);
		}
		$map['sku_id'] = array('IN',$goods_ids);
		$map['status'] = array('EQ',1);
		$count = $this->index_db->where($map)->count();
		$sku_ids = $this->index_db->where($map)->page($options['page'])->order($sqlmap['order'])->limit($options['limit'])->getfield('sku_id',TRUE);
		foreach ($sku_ids AS $sku_id) {
			$result[] = $this->sku_db->detail($sku_id,TRUE,'goods')->output();
		}
		return array('count' => $count,'lists' => $result);
	}
	/**
	 * [page 调用商品前台分页]
	 * @param  array  $sqlmap  [description]
	 * @param  array  $options [description]
	 * @return [type]          [description]
	 */
	public function page($sqlmap = array(),$options = array()){
		$sqlmap = $this->build_goods_map($sqlmap);
		$map = array();
		if(!empty($sqlmap['status_ext'])){
			$map['status_ext'] = $sqlmap['status_ext'];
			unset($sqlmap['status_ext']);
		}
		$goods_ids = $this->build_goods_ids($sqlmap);
		if(isset($sqlmap['price'])){
			$map = $this->build_sku_map($sqlmap);
		}
		$map['sku_id'] = array('IN',$goods_ids);
		$map['status'] = array('EQ',1);
		$lists['count'] = $this->index_db->where($map)->count();
		$totalPage = ceil($lists['count']/$options['limit']);
        $string = '';
		if($_GET['page'] > 1){
			$string .= '<a class="prev" href="'.page_url(array('page' => $_GET['page'] - 1)).'">上一页</a>';
		}else{
			$string .= '<a class="prev disabled">上一页</a>';
		}
        if($_GET['page'] < $totalPage){
			$string .= '<a class="next" href="'.page_url(array('page' => $_GET['page'] + 1)).'">下一页</a>';
		}else{
			$string .= '<a class="next disabled">下一页</a>';
		}
		$lists['page'] = $string;
		return $lists;
	}
	/**
	 * [build_goods_ids 获取子商品id]
	 * @param  [type] $sqlmap [description]
	 * @return [type]         [description]
	 */
	private function build_goods_ids($sqlmap){
		$sqlmap['show_in_lists'] = 1;
		$_goods_ids = $this->index_db->where($sqlmap)->getfield('sku_id',TRUE);
		if(!is_null($sqlmap['goods_ids'])) {
			$goods_ids = explode(',',$sqlmap['goods_ids']);
			$goods_ids = array_intersect($_goods_ids, $goods_ids);
			$goods_ids = ($goods_ids) ? $goods_ids : -1;
		} else {
			$goods_ids = $_goods_ids;
		}
		return $goods_ids;
	}
	/**
	 * [build_goods_map 构造商品查询语句]
	 * @param  [type] $data [description]
	 * @return [type]       [description]
	 */
	private function build_goods_map($data){
		$map = $data;
		if(isset($data['statusext']) && is_numeric($data['statusext']) && $data['statusext'] > 0){
			$map['status_ext'] = $data['statusext'];
		}
		unset($map['brand_id']);
		if (isset($data['brand_id']) && is_numeric($data['brand_id']) && $data['brand_id'] > 0) {
			$map['brand_id'] = $data['brand_id'];
		}
		unset($map['catid']);
		if (isset($data['catid']) && is_numeric($data['catid'])) {
			$cat_ids = array();
			if($this->cate_service->has_child($data['catid'])){
				$cat_ids = $this->cate_service->get_child($data['catid']);
			}else{
				$cat_ids = array(0 => $data['catid']);
			}
			$map['catid'] = array('IN',$cat_ids);
		}
		if(empty($data['order'])){
           $map['order'] = 'sort asc,sku_id desc';
        }
		return $map;
	}	
	/**
	 * [build_sku_map 构造子商品查询语句]
	 * @param  [type] $data [description]
	 * @return [type]       [description]
	 */
	private function build_sku_map($data){
		$map = array();
		$price = $data['price'];
		list($p_min, $p_max) = explode(',',$price);
		if($p_min > 0) {
			$map['shop_price'][] = array("EGT", $p_min);
		}
		if($p_max > 0) {
			$map['shop_price'][] = array("ELT", $p_max);
		}
		return $map;
	}
	/**
     * [create_sqlmap 组织筛选条件]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function create_sqlmap($params){
    	$result = $params;
    	$result['order'] = 'sort asc, id desc';
    	list($_sort, $_by) = explode(',',$params['sort']);
			switch ($_sort) {
				case 'sale':
					$result['order'] = "`sales` desc";
					break;
				case 'hits':
					$result['order'] = "`hits` desc";
					break;
				case 'shop_price':
					$_by = ($_by == 'asc') ? 'desc' : 'asc';
					$result['order'] = "`shop_price` ".(($_by == 'asc') ? 'desc' : 'asc');
					break;
				default: 
				$result['order'] = "`sales` desc,`favorites` desc,`hits` desc";
					break;
			} 
			$result['_by'] = $_by ? $_by : 'desc';
			$result['sort'] = $_sort ? $_sort : 'comper';
		if($params['attr']){
			$result['_goods_ids'] = $this->goods_attr_screen($params['attr']);
		}
    	return $result;
    }
    /**
     * [search 关键字查找商品]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function search($params){
		$keyword = remove_xss($params['keyword']);
		if(strlen($keyword) < 1 ) {
			showmessage('参数错误');
		}
		$map = $sku_ids = array();
		$map['_string'] = "`name` LIKE '%{$keyword}%' OR `keyword` LIKE '%{$keyword}%' OR `description` LIKE '%{$keyword}%'";
		$spu_ids = $this->spu_db->where($map)->getfield('id',TRUE);
		foreach ($spu_ids AS $spu_id) {
			$sku_ids = array_merge($sku_ids,$this->sku_db->where(array('spu_id'=>$spu_id))->getField('sku_id',TRUE));
		}
		$result['_goods_ids'] = implode(',',$sku_ids);
		list($_sort, $_by) = explode(',',$params['sort']);
			switch ($_sort) {
				case 'sale':
					$result['order'] = "`sales` desc";
					break;
				case 'hits':
					$result['order'] = "`hits` desc";
					break;
				case 'shop_price':
					$_by = ($_by == 'asc') ? 'desc' : 'asc';
					$result['order'] = "`shop_price` ".(($_by == 'asc') ? 'desc' : 'asc');
					break;
				default: 
				$result['order'] = "`sales` desc,`favorites` desc,`hits` desc";
					break;
			} 
			$result['_by'] = $_by ? $_by : 'desc';
			$result['sort'] = $_sort ? $_sort : 'comper';
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [sku_detail sku详情]
	 * @param  [type] $sku_ids [支持数组]
	 * @return [type]          [description]
	 */
	public function sku_detail($sku_ids){
		if(empty($sku_ids)){
			$this->error = '参数错误';
			return FALSE;
		}
		if(is_array($sku_ids)){
			foreach ($sku_ids AS $sku_id) {
				$sku = $this->sku_db->detail($sku_id)->create_spec()->output();
				$spec_str = '';
				foreach ($sku['spec'] AS $spec) {
					$spec_str .= $spec['name'].':'.$spec['value'].' ';
				}
				$sku['spec'] = $spec_str;
				$result[] = $sku;
			}
		}else{
			$result = $this->sku_db->detail($sku_ids)->output();
		}
		return $result;
	}
	/**
	 * [ajax_del_sku 删除子商品]
	 * @param  [type] $params [description]
	 * @return [type]      [description]
	 */
	public function ajax_del_sku($params){
		$id = $params['sku_id'];
		$label = $params['label'];
		$data = $sqlmap = $map = array();
		if($id){
			if($label == 4){
				$result =$this->delete_goods($id);
				return $result;
			}else{
				$sqlmap['sku_id'] = array('IN',$id);
				$data['status'] = -1;
				$result = $this->sku_db->where($sqlmap)->save($data);
				$this->index_db->where($sqlmap)->save($data);
				$spu_ids = $this->sku_db->where($sqlmap)->getField('spu_id',TRUE);
				$spu_ids = array_unique($spu_ids);
				foreach ($spu_ids AS $spu_id) {
					$sku_status = $this->sku_db->where(array('spu_id'=>$spu_id))->getField('sku_id,status',TRUE);
					$sku_status_num = 0;
					foreach ($sku_status AS $status) {
						if($status == -1){
							$sku_status_num++;
						}
					}
					if($sku_status_num == count($sku_status)){
						$this->spu_db->where(array('id'=>$spu_id))->save(array('status'=>-1));
					}
				}
				if($result === FALSE){
					$this->error = lang('_OPERATION_FAIL_');
					return FALSE;
				}
				return TRUE;
			}
		}else{
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
	}
	/**
	 * [delete_goods 删除商品,只有在回收站里进行此操作]
	 * @param  [array] $id [商品id]
	 * @return [type]     [description]
	 */
	private function delete_goods($id){
		$id = (array)$id;
		if(empty($id)) {
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$spu_ids = $this->sku_db->where(array('sku_id' => array('IN', $id)))->getField('spu_id',TRUE);
		$result = $this->sku_db->where(array('sku_id' => array('IN', $id)))->delete();
		$this->index_db->where(array('sku_id' => array('IN', $id)))->delete();
		foreach ($spu_ids AS $spu_id) {
			$sku_ids_num = $this->sku_db->where(array('spu_id'=>$spu_id))->count();
			if($sku_ids_num == 0){
				$this->spu_db->where(array('id'=>$spu_id))->delete();
			}
		}
		return $result;
	}
	/**
	 * [ajax_sku_name ajax修改sku名称]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function ajax_sku_name($params){
		if((int)$params['id'] < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$data = array();
		$data['sku_name'] = $params['name'];
		$result = $this->sku_db->where(array('sku_id'=>$params['id']))->save($data);
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [ajax_show ajax]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function ajax_show($id){
		if((int)$id < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$data = array();
		$data['show_in_lists']= array('exp',' 1-show_in_lists ');
		$result = $this->sku_db->where(array('sku_id'=>$id))->save($data);
		$this->index_db->where(array('sku_id'=>$id))->save($data);
		if($result === FALSE){
    		$this->error = lang('_OPERATION_FAIL_');
    		return FALSE;
    	}else{
    		return TRUE;
    	}
    }
}