<?php
/**
 *		子商品数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class goods_sku_service extends service {
	public function __construct() {
		$this->logic = model('goods/goods_sku','logic');
	}
	/**
	 * [create_sku 添加/编辑商品时处理子商品信息]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function create_sku($params){
		$result = $this->logic->create_sku($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_lists 获取商品sku列表]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function get_lists($params){
		$result = $this->logic->get_lists($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [sku_edit 编辑sku]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function sku_edit($params){
		$result = $this->logic->sku_edit($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * 指定商品减少库存
	 * @param [int] $sku_id 子商品ID
	 * @param [int] $goods_num变更数量
	 * @return bool
	 */
	public function set_dec_number($sku_id, $number) {
		$result = $this->logic->set_dec_number($sku_id, $number);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [lists 查询商品列表]
	 * @return [type] [description]
	 */
	public function lists($sqlmap = array(),$options = array()){
		$result = $this->logic->lists($sqlmap,$options);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [page description]
	 * @param  array  $sqlmap  [description]
	 * @param  array  $options [description]
	 * @return [type]          [description]
	 */
	public function page($sqlmap = array(),$options = array()){
		$result = $this->logic->page($sqlmap,$options);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_sku_names 生成子商品名称]
	 * @param  [type] $params [商品参数]
	 * @return [array]         [子商品名称数组]
	 */
	public function create_sku_name($spec_array){
		$result = $this->logic->create_sku_name($spec_array);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * 指定商品增加库存
	 * @param [int] $sku_id 子商品ID
	 * @param [int] $goods_num变更数量
	 * @return bool
	 */
	public function set_inc_number($sku_id, $number) {
		$result = $this->logic->set_inc_number($sku_id, $number);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [is_favorite 判断商品是否已收藏]
	 * @param  [type]  $id [description]
	 * @return boolean     [description]
	 */
	public function is_favorite($mid,$id){
		$result = $this->logic->is_favorite($mid,$id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [detail 查询子商品详情]
	 * @param  [type]  $id    [子商品id]
	 * @return [type]         [description]
	 */
	public function detail($id,$flag = FALSE){
		$result = $this->logic->detail($id,$flag);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_sku 根据主商品获取子商品id]
	 * @param  [type] $id [主商品id]
	 * @return [type]     [description]
	 */
	public function get_sku($id){
		$result = $this->logic->get_sku($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_sku_ids 默认根据主商品获取子商品id，$flag为TRUE时查询子商品的同父级子商品]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_sku_ids($id,$isspu = TRUE){
		$result = $this->logic->get_sku_ids($id,$isspu);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_sku_spec 根据子商品id获取规格]
	 * @param  [type] $catid [description]
	 * @return [type]        [description]
	 */
	public function get_sku_spec($id){
		$result = $this->logic->get_sku_spec($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_sku_grades 根据分类和子商品价格生成子商品的商品价格范围]
	 * @param  [type] $id [description]
	 * @param  [type] $sku_price [子商品价格]
	 * @return [type]     [description]
	 */
	public function get_sku_grades($catid,$sku_price){
		$result = $this->logic->get_sku_grades($catid,$sku_price);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [_history 商品历史浏览记录]
	 * @param  integer $goods_id [description]
	 * @return [type]            [description]
	 */
	public function _history($id = 0) {
		$result = $this->logic->_history($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [clear_history 清空历史记录]
	 * @return [type] [description]
	 */
	public function clear_history(){
		cookie('_history',null);
		return TRUE;
	}
	/**
	 * [get_selected 获取选中的规格]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_selected($id){
		$result = $this->logic->get_selected($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_statusext ajax更改状态标签状态]
	 * @return [type] [description]
	 */
	public function ajax_statusext($params){
		$result = $this->logic->ajax_statusext($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [inc_hits 更新浏览记录]
	 * @param  [type] $id [商品Id]
	 * @return [type]     [description]
	 */
	public function inc_hits($id){
		$result = $this->logic->inc_hits($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [attrs_detail 获取商品属性信息]
	 * @param  [type] $id [商品id]
	 * @return [type]     [description]
	 */
	public function attrs_detail($id){
		$result = $this->logic->attrs_detail($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [fetch_by_id 获取一条子商品信息]
	 * @param  [type]  $id    [description]
	 * @param  boolean $field [description]
	 * @return [type]         [description]
	 */
	public function fetch_by_id($id,$field = TRUE){
		$result = $this->logic->fetch_by_id($id,$field);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [create_user_price 计算会员折扣价]
	 * @param  [type] $price [description]
	 * @return [type]        [description]
	 */
	public function create_user_price($price){
		$result = $this->logic->create_user_price($price);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [goods_detail ]
	 * @param  [type] $ids   [description]
	 * @param  [type] $field [description]
	 * @return [type]        [description]
	 */
	public function goods_detail($ids,$field = TRUE){
		$result = $this->logic->goods_detail($ids,$field);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
    /**
	 * [goods_attr_screen 根据商品属性筛选]
	 * @param  [type] $attrs [选择的商品属性值]
	 * @return [type]        [description]
	 */
	public function goods_attr_screen($attrs){
		$result = $this->logic->goods_attr_screen($attrs);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
    /**
     * [create_sqlmap 组织筛选条件]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function create_sqlmap($params){
    	$result = $this->logic->create_sqlmap($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
    /**
     * [search 关键字查找商品]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function search($params){
		$result = $this->logic->search($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [sku_detail sku详情]
	 * @param  [type] $sku_ids [description]
	 * @return [type]          [description]
	 */
	public function sku_detail($sku_ids){
		$result = $this->logic->sku_detail($sku_ids);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_del_sku 删除子商品]
	 * @param  [type] $params [description]
	 * @return [type]      [description]
	 */
	public function ajax_del_sku($params){
		$result = $this->logic->ajax_del_sku($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_sku_name ajax修改sku名称]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function ajax_sku_name($params){
		$result = $this->logic->ajax_sku_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_show ajax]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function ajax_show($id){
		$result = $this->logic->ajax_show($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
    }
}