<?php
core::load_class('init', 'admin');
class brand_control extends init_control {
	protected $service = '';
	public function _initialize() {
		parent::_initialize();
		$this->db = model('brand');
		$this->service = model('brand','service');
		$this->attachment_service = model('attachment/attachment', 'service');
		helper('attachment');
	}
	/**
	 * [lists 品牌列表]
 	 */
	public function index(){
		$sqlmap = array();
		$limit = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? $_GET['limit'] : 20;
		$brand = $this->service->get_lists($_GET['page'],$limit);
		$count = $this->db->where($sqlmap)->count();
		$pages = $this->admin_pages($count, $limit);
		include $this->admin_tpl('brand_list');
	}
	/**
	 * [add 添加品牌]
	 */
	public function add(){
		if(checksubmit('dosubmit')) {
			if(!empty($_FILES['logo']['name'])) {
				$code = attachment_init(array('path' => 'goods','mid' => 1,'allow_exts' => array('gif','jpg','jpeg','bmp','png')));
				$_GET['logo'] = $this->attachment_service->setConfig($code)->upload('logo');
				$this->attachment_service->attachment($_GET['logo'],'');
				if(!$_GET['logo']){
					showmessage($this->attachment_service->error);
				}
			}
			$result = $this->service->add_brand($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage(lang('_OPERATION_SUCCESS_'),url('index'));
			}
		}else{
			include $this->admin_tpl('brand_edit');
		}
	}
	/**
	 * [edit 编辑品牌]
	 */
	public function edit(){
		$info = $this->service->get_brand_by_id($_GET['id']);
		if(checksubmit('dosubmit')) {
			if(!empty($_FILES['logo']['name'])) {
				$code = attachment_init(array('path' => 'goods','mid' => 1,'allow_exts' => array('gif','jpg','jpeg','bmp','png')));
				$_GET['logo'] = $this->attachment_service->setConfig($code)->upload('logo');
				if(!$_GET['logo']){
					showmessage($this->attachment_service->error);
				}
				$this->attachment_service->attachment($_GET['logo'], $info['logo']);
			}
			$result = $this->service->edit_brand($_GET);
			if(!$result){
				showmessage($this->service->error);
			}else{
				showmessage(lang('_OPERATION_SUCCESS_'),url('index'));
			}
		}else{
			include $this->admin_tpl('brand_edit');
		}
	}
	/**
	 * [ajax_status 品牌列表内更改规格状态]
	 */
	public function ajax_recommend(){
		$result = $this->service->change_recommend($_GET['id']);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,'','json');
		}
	}
	/**
	 * [ajax_del 删除品牌，可批量删除]
	 */
	public function ajax_del(){
		$result = $this->service->delete_brand($_GET['id']);
		if(!$result){
			showmessage($this->service->error);
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1);
		}
	}
	/**
	 * [ajax_sort 改变排序]
	 */
	public function ajax_sort(){
		$result = $this->service->change_sort($_GET);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,'','json');
		}
	}
	/**
	 * [ajax_sort 改变名称]
	 */
	public function ajax_name(){
		$result = $this->service->change_name($_GET);
		if(!$result){
			showmessage($this->service->error,'',0,'','json');
		}else{
			showmessage(lang('_OPERATION_SUCCESS_'),'',1,'','json');
		}
	}
}