<?php
/**
 *		商品类型服务层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class type_service extends service {
	public function __construct() {
		$this->logic = model('goods/type','logic');
	}
	/**
	 * [get_lists 获取商品类型列表]
	 * @return [type] [description]
	 */
	public function get_lists($page,$limit){
		$result = $this->logic->get_lists($page,$limit);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_type 添加类型]
	 * @param [type] $params [description]
	 */
	public function add_type($params){
		$result = $this->logic->add_type($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_status 改变状态]
	 * @param  [int] $id [id]
	 * @return [boolean]        [返回改变结果]
	 */
	public function change_status($id){
		$result = $this->logic->change_status($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [delete_type 删除，可批量删除]
	 * @param  [int || array] $params [规格id或规格id数组]
	 * @return [boolean]         [返回删除结果]
	 */
	public function delete_type($params){
		$result = $this->logic->delete_type($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_sort 改变排序]
	 * @param  [array] $params [id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_sort($params){
		$result = $this->logic->change_sort($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [change_name 改变名称]
	 * @param  [array] $params [品牌id和name]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_name($params){
		$result = $this->logic->change_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_attrs 根据分类id获取商品属性]
	 * @param  [type] $catid [分类id]
	 * @return [type]        [description]
	 */
	public function get_attrs($catid){
		$result = $this->logic->get_attrs($catid);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_attrs 根据分类id获取商品类型id]
	 * @param  [type] $catid [分类id]
	 * @return [type]        [array]
	 */
	public function get_type_id($catid){
		$result = $this->logic->get_type_id($catid);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_attrs 根据id获取商品类型名]
	 * @param  [type] $catid [分类id]
	 * @return [type]        [array]
	 */
	public function get_type_name($catid){
		$result = $this->logic->get_type_name($catid);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_attr_info 根据id获取商品属性信息]
	 * @param  [type] $catid [分类id]
	 * @return [type]        [array]
	 */
	public function get_attr_info($id){
		$result = $this->logic->get_attr_info($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_name_by_id 根据id获取商品类型名]
	 * @param  [type] $catid [分类id]
	 * @return [type]        [array]
	 */
	public function get_name_by_id($id){
		$result = $this->logic->get_name_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_type_by_id 根据id获取商品类型信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_type_by_id($id){
		$result = $this->logic->get_type_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_spec_by_id 根据id获取规格信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_spec_by_id($id){
		$result = $this->logic->get_spec_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_pop_by_id 根据id获取商品属性信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_pop_by_id($id){
		$result = $this->logic->get_pop_by_id($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_all_type 获取类型id和名称]
	 * @return [type] [description]
	 */
	public function get_all_type(){
		$result = $this->logic->get_all_type();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_type_by_goods_id 根据商品id获取类型数据]
	 * @param  [type] $goods_id [description]
	 * @return [type]           [description]
	 */
	public function get_type_by_goods_id($goods_id){
		$result = $this->logic->get_type_by_goods_id($goods_id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
}
	