<?php
/**
 *		商品品牌数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class goods_attribute_table extends table {
	protected $_validate = array(
        array('product_id','number','商品id必须为数字',0,'regex',table::EXISTS_VALIDATE),
        array('attribute_id','number','属性id必须为数字',0,'regex',table::EXISTS_VALIDATE),
        array('type','number','属性类型必须为数字',0,'regex',table::EXISTS_VALIDATE),
        array('status','number','状态必须为数字',0,'regex',table::EXISTS_VALIDATE),
        array('sort','number','排序必须为数字',0,'regex',table::EXISTS_VALIDATE),
    );
    protected $_auto = array(
    );
}