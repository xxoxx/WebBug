<?php
/**
 *		规格模型逻辑层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class spec_logic extends logic {
	public function __construct() {
		$this->db = model('goods/spec');
	}
	/**
	 * [spec_list 规格列表]
	 * @return [array] [保存规格信息的数组]
	 */
	public function spec_list($page,$limit){
		$result = $this->db->page($page)->limit($limit)->order('sort asc')->getField('id,name,value,status,sort');
		if(!$result){
    		$this->error = $this->db->getError();
    	}
    	return $result;
    }
	/**
	 * [add_spec 增加规格]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回ture or false]
	 */
	public function add_spec($params){
		if(empty($params['value'])){
			$this->error = '请填写要添加的规格属性值';
			return FALSE;
		}
		foreach ($params['value'] as $k => $value) {
			if($value == ''){
				unset($params['value'][$k]);
			}
		}
		$params['value'] = implode(',',$params['value']);
		$result = $this->db->update($params);
    	if($result === FALSE){
    		$this->error = $this->db->getError();
    	}	
    	return $result;
	}
	/**
	 * [edit_spec 编辑规格]
	 * @param [array] $params [规格信息]
	 * @return [boolean]         [返回ture or false]
	 */
	public function edit_spec($params){
		if((int)$params['id'] < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		if(empty($params['value'])){
			$this->error = '请填写要添加的规格属性值';
			return FALSE;
		}
		foreach ($params['value'] as $k => $value) {
			if($value == ''){
				unset($params['value'][$k]);
			}
		}
		$params['value'] = implode(',',$params['value']);
		$result = $this->db->update($params);
    	if($result === FALSE){
    		$this->error = $this->db->getError();
    	}	
    	return $result;
	}
	/**
	 * [change_status 改变状态]
	 * @param  [int] $id [规格id]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_status($id){
		if((int)$id < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$data = array();
		$data['status']=array('exp',' 1-status ');
		$result = $this->db->where(array('id'=>array('eq',$id)))->save($data);
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [delete_spec 删除规格，可批量删除]
	 * @param  [int||array] $params [规格id或规格id数组]
	 * @return [boolean]         [返回删除结果]
	 */
	public function delete_spec($params){
		$params = (array) $params;
		if(empty($params)){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		if(in_array(1,$params)){
			$this->error = '默认规格不能删除';
			return FALSE;
		}
		$sqlmap = array();
		$sqlmap['id'] = array('IN',$params);
		$result = $this->db->where($sqlmap)->delete();
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [change_sort 改变排序]
	 * @param  [array] $params [规格id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_sort($params){
		if((int)$params['id'] < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$data = array();
		$data['sort'] = $params['sort'];
		$result = $this->db->where(array('id'=>array('eq',$params['id'])))->save($data);
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [change_sort 改变名称]
	 * @param  [array] $params [品牌id和name]
	 * @return [boolean]     [返回更改结果]
	 */
	public function change_name($params){
		if((int)$params['id'] < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$data = array();
		$data['name'] = $params['name'];
		$result = $this->db->where(array('id'=>array('eq',$params['id'])))->save($data);
		if(!$result){
    		$this->error = lang('_OPERATION_FAIL_');
    	}
    	return $result;
	}
	/**
	 * [get_type_by_id 根据id获取商品类型信息]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function get_spec_by_id($id){
		if((int)$id < 1){
			$this->error = lang('_PARAM_ERROR_');
			return FALSE;
		}
		$result = $this->db->find($id);
		$result['spec_array'] = explode(',',$result['value']);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_add_spec ajax增加规格]
	 * @param  [type] $name [description]
	 * @return [type]       [description]
	 */
	public function ajax_add_spec($name){
		if (empty($name)) {
			$this->error = '请填写要添加的规格名称';
			return FALSE;
		}
		$result = $this->db->add(array('name'=>$name));
		if (!$result) {
			$this->error = '新规格添加失败';
		}
		return $result;
	}
	/**
	 * [ajax_add_pop ajax增加规格属性]
	 * @param  [type] $params [description]
	 * @return [type]       [description]
	 */
	public function ajax_add_pop($params){
		$data       = array();
		$data['id'] = (int)$params['spec_id'];
		$new_value  = str_replace('，',',',trim($params['new_value']));
		if (empty($new_value)){
			$this->error = '请填写要添加的规格属性值';
			return FALSE;
		} 
		if ($data['id'] < 1){
			$this->error = '选择规格有误';
		} 
		$old_info = $this->db->find($data['id']);
		if (empty($old_info['value'])) {
			$data['value'] = $new_value;
		} else {
			$data['value'] = $old_info['value'].','.$new_value;
		}
		$result = $this->db->save($data);
		if ($result === FALSE){
			$this->error = '新增属性失败';
		} 
		return $result;
	}
	/**
	 * [get_spec_name 获取规格名称]
	 * @param  [type] $name [description]
	 * @return [type]       [description]
	 */
	public function get_spec_name(){
		$result = $this->db->order('sort ASC')->getField('id,name,value');
		foreach ($result as $key => $value) {
			if($value['value'] == ''){
				unset($value['value']);
			}else{
				$result[$key]['value'] = explode(',',$value['value']);
			}
		}
		if(!$result){
			$this->error = lang('_OPERATION_FAIL_');
		}
		return $result;
	}
}