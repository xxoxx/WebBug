<?php
class taglib_consult
{	
	public function __construct() {
		$this->model = model('goods/goods_consult');
	}
	public function count($sqlmap = array(), $options = array()){
		$count = $this->model->where($sqlmap)->count();
		return $count;
	}
	public function lists($sqlmap = array(), $options = array()) {
		$count = $this->model->where($sqlmap)->count();
		$this->model->where($sqlmap);
		if(isset($options['limit'])){
			$this->model->limit($options['limit']);
		}
		if($options['page']) {
			$this->model->page($options['page']);
			$pagefunc = $options['pagefunc'] ? $options['pagefunc'] : 'pages';
			$this->pages = $pagefunc($count,$options['limit']);
		}
		$lists = $this->model->order('id DESC')->select();
		foreach($lists as $key => $value){
			$lists[$key]['username'] = cut_str($value['username'], 1, 0).'**'.cut_str($value['username'], 1, -1);
		}
		return $lists;
	}
}