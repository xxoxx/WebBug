<?php
class init_control extends control
{
	public function _initialize() {
		parent::_initialize();
		$this->member = model('member/member', 'service')->init();
		if ($this->member['id']) {
			$this->counts = model('order/order')->buyer_id($this->member['id'])->out_counts();
		}
		define('SKIN_PATH', __ROOT__.(str_replace(DOC_ROOT, '', TPL_PATH)).config('TPL_THEME').'/');
		$cloud =  unserialize(authcode(config('__cloud__','cloud'),'DECODE'));
		define('SITE_AUTHORIZE', (int)$cloud['authorize']);
		define('COPYRIGHT', pack('H*','506f77657265642062792048616964616f20').HD_VERSION.' '.HD_RELEASE.pack('H*','3c6272202f3e26636f70793b20323031332d3230313520446d69626f7820496e632e'));
	}
}