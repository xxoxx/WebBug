<?php
class taglib_search
{	
	public function __construct() {
		$this->model = model('setting');
	}
	public function lists($sqlmap = array(), $options = array()) {
		$data = array();
		$data['key'] = 'hot_seach';
		$seach = $this->model->where($data)->getField('value');
		return explode("\r\n",trim($seach));
	}
}