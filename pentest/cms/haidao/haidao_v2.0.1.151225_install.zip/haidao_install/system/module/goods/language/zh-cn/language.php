<?php
/**
 *      模块语言报
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
/**
 * 商品模块 简体中文语言包
 */
return array(
	'STATUS_TYPE_ERROR' => '状态只能为数字',
	'SORT_TYPE_ERROR' => '排序只能为数字',
    'GOODS_SPEC_ID_ERROR' => '选择规格有误',
    'GOODS_SPEC_NAME_REQUIRE' => '请填写要添加的规格名称',
    'GOODS_SPEC_NAME_UNIQUE' => '规格名称必须唯一',
    'GOODS_SPEC_VALUE_EMPTY' => '请填写要添加的规格属性值',
    'GOODS_BRAND_NAME_REQUIRE' => '品牌名称不能为空',
    'GOODS_BRAND_RECOMMEND' => '商品推荐参数必须为数字',
    'GOODS_HAS_CHILD_CATEGORY' => '请先删除子分类',
    'GOODS_CATEGORY_NAME_REQUIRE' => '分类名称必须填写',
    'GOODS_CATEGORY_NOT_EXIST' => '分类不存在',
    'GOODS_CATEGORY_HAS_PARENTS' => '该分类没有父级分类',
    'GOODS_TYPE_NAME_REQUIRE' => '类型名称不能为空',
    'GOODS_GOODS_RECOVER_FAIL' => '恢复失败',
    'GOODS_GOODS_NOT_EXIST' => '商品不存在',
    'GOODS_GOODS_NAME_EMPTY' => '商品名称不能为空',
    'GOODS_CATEGORY_ID_EMPTY' => '商品分类必须选择',
    'GOODS_SPEC_DEFAULT_DELETE' => '默认规格不能删除',
    'GOODS_SPEC_ADD_FAIL' => '新规格添加失败',
    'GOODS_POP_ADD_FAIL' => '新增属性失败',
);
