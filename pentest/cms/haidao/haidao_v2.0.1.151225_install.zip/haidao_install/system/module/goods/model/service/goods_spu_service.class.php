<?php
/**
 *		商品模型数据层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class goods_spu_service extends service {
	public function __construct() {
		$this->logic = model('goods/goods_spu','logic');
	}
	/**
	 * [get_lists 获取商品列表]
	 * @return [array] [返回商品列表信息]
	 */
	public function get_lists($params){
		$result = $this->logic->get_lists($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	public function goods_add($params){
		$result = $this->logic->goods_add($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [create_info 将数据库信息保存到缓存]
	 * @return [type] [description]
	 */
	public function create_info($id){
		$result = $this->logic->create_info($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [goods_desc 处理商品详情相关]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function goods_desc($params){
		$result = $this->logic->goods_desc($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_goods_cache 获取商品缓存]
	 * @return [type] [description]
	 */
	public function get_goods_cache(){
		$result = $this->logic->get_goods_cache();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_goods_spec_cache 获取商品规格处理页的缓存]
	 * @return [type] [description]
	 */
	public function get_goods_spec_cache(){
		$result = $this->logic->get_goods_spec_cache();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	
	/**
	 * [clear_cache 逻辑判断编辑与添加的关系继而清除缓存]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function clear_cache($id){
		$result = $this->logic->clear_cache($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [add_goods 添加商品]
	 * @param  [array] $params [商品信息]
	 * @return [boolean]         [返回结果]
	 */
	public function add_goods($content){
		$result = $this->logic->add_goods($content);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_selected_result 逻辑判断获取选中的规格]
	 * @param  [type] $selectedItem [description]
	 * @param  [type] $selected     [description]
	 * @return [type]               [description]
	 */
	public function get_selected_result($selectedItem,$selected){
		$result = $this->logic->get_selected_result($selectedItem,$selected);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [detail 获取主商品信息]
	 * @param  [type]  $id    [主商品id]
	 * @param  fixed $field [需要获取的字段，默认全部获取]
	 * @return [type]         [description]
	 */
	public function detail($id){
		$result = $this->logic->detail($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [lists 商品列表]
	 * @param  [type] $id [分类id]
	 * @return [type]     [description]
	 */
	public function lists($id){
		$result = $this->logic->lists($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_specs 获取并处理规格缓存,上传图册页面调用]
	 * @return [type] [description]
	 */
	public function get_specs(){
		$result = $this->logic->get_specs();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [fetch_detail 根据商品id查询某个字段]
	 * @param  [type] $id    [description]
	 * @param  [type] $field [description]
	 * @return [type]        [description]
	 */
	public function fetch_detail($id,$field = FALSE){
		$result = $this->logic->fetch_detail($id,$field);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_del 删除商品，在商品列表里删除只改变状态，在回收站里删除直接删除]
	 * @param  [type] $params [description]
	 * @return [type]         [description]
	 */
	public function ajax_del($params){
		$result = $this->logic->ajax_del($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_goods_spec 获取商品规格]
	 * @param  [type] $id [商品id]
	 * @return [type]     [description]
	 */
	public function get_goods_spec($id){
		$result = $this->logic->get_goods_spec($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_recover 批量恢复商品]
	 * @param  [array] $id [要恢复的商品id]
	 * @return [type]     [description]
	 */
	public function ajax_recover($id){
		$result = $this->logic->ajax_recover($id);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_name 更改商品名称]
	 * @param  [array] $params [品牌id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_name($params){
		$result = $this->logic->ajax_name($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_status 更改商品上下架状态]
	 * @param  [array] $params [品牌id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_status($id,$type = 'spu'){
		$result = $this->logic->ajax_status($id,$type);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [ajax_sort 更改排序]
	 * @param  [array] $params [品牌id和排序数组]
	 * @return [boolean]     [返回更改结果]
	 */
	public function ajax_sort($params){
		$result = $this->logic->ajax_sort($params);
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
	/**
	 * [get_type_info 获取商品类型和属性]
	 * @return [type] [description]
	 */
	public function get_type_info(){
		$result = $this->logic->get_type_info();
		if(!$result){
			$this->error = $this->logic->error;
		}
		return $result;
	}
}