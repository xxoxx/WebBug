<?php
class consult_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->consult_service = model('goods/goods_consult','service');
	}
	/**
	 * [add 添加咨询]
	 */
	public function add(){
		$_GET['sku_id'] = (int) $_GET['sku_id'];
		if($_GET['sku_id'] < 1){
			showmessage('参数错误');
		}
		$goods_detail = model('goods_sku')->detail($_GET['sku_id'],true,'goods')->create_spec()->output();
		if($goods_detail === FALSE){
			showmessage('商品不存在');
		}
		extract($goods_detail);
		if(IS_POST){	
			if($this->member['id']){
				$_GET['mid'] = $this->member['id'];
				$_GET['username'] = $this->member['username'];
			}
			$result = $this->consult_service->add($_GET);
			if(!$result){
				showmessage($this->consult_service->error);
			}else{
				showmessage('操作成功','',1,'','json');
			}
		}
		$SEO = seo('商品咨询');
		include template('consult');
	}
	/**
	 * [see 查看咨询]
	 */
	public function see(){
		if(!$this->member['id']){
			showmessage('参数错误');
			return FALSE;
		}
		$_GET['mid'] = (int) $this->member['id'];
		$result = $this->consult_service->see($_GET);
		if(!$result){
			showmessage($this->consult_service->error,'',1,'','json');
		}else{
			showmessage('操作成功','',1,'','json');
		}
	}
}