<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class upgrade_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->service = model('admin/cloud','service');
		$this->cloud =  unserialize(authcode(config('__cloud__','cloud'),'DECODE'));
		if(!isset($this->cloud))showmessage('请先绑定站点',url('admin/cloud/index'));
		if(!$this->service->getcloudstatus())showmessage('云平台通讯失败,请稍候再试！',url('admin/cloud/index'));
		$this->update_path = CACHE_PATH.'uppack/';
		$this->update_back_path = CACHE_PATH.'upback/';
	}

	public function index() {
		
		include $this->admin_tpl('upgrade_index');
	}

	public function lists() {
		$r = $this->service->api_product_version();
		include $this->admin_tpl('upgrade_lists');
	}

	public function upgrade() {
		//检查是否有正在执行的任务
		$lock = "{$this->update_path}backup.lock";
		if(is_file($lock)){
			showmessage( $lock.'检测到有一个升级任务正在执行，请稍后再试！');
			exit();
		} else {
			//创建锁文件
			file_put_contents($lock, time());
		}
		$version = '';
		extract($_GET,EXTR_IF_EXISTS);
		//取要升级的版本
		$upversion = array();
		foreach(cache('version_detail') as $k=>$v){
			if(version_compare($version, $v['version'])>=0){
				$upversion[$v['version']] = $v;
			}
		}
		cache('varsion_uppack',$upversion);
		include $this->admin_tpl('upgrade_uppack');
		foreach($upversion as $k=>$v){
			showinfo('正准备升级'.$k);
			$this->downpack($k);
			if($k == $version)break;
		}
		showinfo('已升级至'.$k,1);
		dir::del($this->update_path);
		
	}
	
	//获取最新版本
	public function ajax_checkupgrade(){
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		$r = $this->service->api_product_version();
		if($r['result']!=false)$r['url']=url('admin/upgrade/lists');
		cache('version_detail',$r['result']);
		echo json_encode($r);
	}
	//下载文件
	public function downpack($version){
		
		if (!is_dir($this->update_path)) dir::create($this->update_path, 0777, true);
		$file = $this -> update_path.random(8).'.zip';
		
		$down = $this->service->api_product_downpack($version);
		$ch = curl_init();
		//Initialize a cURL session.
		$fp = fopen($file, 'wb');
		curl_setopt($ch, CURLOPT_URL, $down['url']);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_NOPROGRESS, 0);
		curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, 'progress');
		curl_setopt($ch, CURLOPT_FILE, $fp);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_BUFFERSIZE, 64000);
		curl_setopt($ch, CURLOPT_POST, FALSE); // post传输数据
		curl_setopt($ch, CURLOPT_POSTFIELDS,$down['params']);// post传输数据
		$res = curl_exec($ch);
		if (curl_errno($ch)){
			die(curl_error($ch));
		}else{
			curl_close($ch);
		}
		fclose($fp);
		
		$this -> expfile($file, $version);
	}
	//执行升级
	public function expfile($file, $version) {
		$this -> showinfo('正在解压文件');
		$archive = new PclZip($file);
		//读取XML指定文件内容
		$xmlres = $archive->extract(PCLZIP_OPT_BY_NAME,'upgrade.xml',PCLZIP_OPT_EXTRACT_AS_STRING);
		//读取成功
		if($xmlres[0]['status'] == 'ok'){
			$xml_info = xml2array($xmlres[0]['content']);
		}

		$back_file = array_merge_recursive(
			(array)$xml_info['hd_files']['create'],
			(array)$xml_info['hd_files']['update'],
			(array)$xml_info['hd_files']['delete']
		);
		$back_file = array_unique($back_file);
		
		$back_dir = $this->update_back_path.$version.'/';
		if (!is_dir($back_dir)) dir::create($back_dir, 0777, true);
		//备份文件
		foreach ($back_file as $k => $v) {
			$file = $v;
			$_dir = $back_dir.dirname($file).'/';
			if (!is_dir($_dir)) dir::create($_dir, 0777, true);
			@copy($file,$_dir.basename($file));
		}
		//删除文件
		foreach ($xml_info['hd_files']['delete'] as $k => $v) {
			@unlink($v);
		}

		if ($archive -> extract(PCLZIP_OPT_PATH, './', PCLZIP_OPT_REPLACE_NEWER) == 0) {
			exit(showinfo('文件不存在,升级失败',0));
		} else {
			$sqlfile = APP_ROOT . 'update.sql';
			$sql = file_get_contents($sqlfile);
			if ($sql) {
				$sql = str_replace("hd_", config('DB_PREFIX'), $sql);
				error_reporting(0);
				foreach (split(";[\r\n]+", $sql) as $v) {
					@mysql_query($v);
				}
			}
			@unlink($sqlfile);
			//删除文件
			$updatefile = $this -> DOC_ROOT . 'update.php';
			if (file_exists($updatefile)){
				require($updatefile);
			}
			@unlink($updatefile);
			$info['status'] = 1;
			$info['info'] = $version."升级完成!";
			$this->update_config($version);
			$this->clcache();
			model('admin/cloud','service')->update_site_userinfo();
		}
		showinfo($info['info']);
	}
	//写入配置文件
	public function update_config($version){
		$_version = cache('varsion_uppack');
		$versiondata =  <<<EOF
<?php
if(!defined('HD_VERSION')) {
	define('HD_VERSION', '{$version}');
	define('HD_RELEASE', '{$_version[$version][release]}');
	define('HD_BRANCH', '{$_version[$version][branch]}');
	define('HD_FIXBUG', '{$_version[$version][fixbug]}');
}
EOF;
		file_put_contents(CONF_PATH.'version.php',$versiondata);
		
	}
	//更新缓存
	public function clcache(){
		$caches = array('setting', 'module', 'plugin', 'template', 'taglib', 'temp', 'extra');
		foreach($caches as $k=>$v){
			model('admin/cache', 'service')->$v();
		}
	}
}