<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class admin_service extends service {
    public function __construct() {
        $this->logic = model('admin/admin', 'logic');
    }

    public function init() {
    	$_admin = array(
    		'id' => 0,
    		'group_id' => 0,
    		'username'	=> '',
    		'avatar'	=> __ROOT__.'statics/images/head.jpg',
    		'rules'		=> '',
    		'formhash'	=> random(6)
		);        
        $authkey = session('authkey');
        if($authkey) {
            list($admin_id, $authkey) = explode("\t", authcode($authkey, 'DECODE'));			
            $_admin = model('admin/admin_user', 'table')->find($admin_id);
			if($_admin) {
				$_admin['avatar'] = $this->getthumb($_admin['id']);
			}
			$_admin['rules'] = model('admin/admin_group')->where(array('id' => $_admin['group_id']))->getField('rules');
			$_admin['formhash'] = $authkey;
        }
        return $_admin;
    }
	
	/* 权限验证 */
	public function auth($rules) {
		$rules = explode(",", $rules);		
		$_map = array();
		$_map['m'] = MODULE_NAME;
		$_map['c'] = CONTROL_NAME;
		$_map['a'] = METHOD_NAME;
		$rule_id = model('node', 'table')->where($_map)->getField('id');
		if($rule_id && !in_array($rule_id, $rules) && !defined('AUTH_IGNORE')) {
			return false;
		}
		return true;
	}

    /**
     * 登录
     * @param string $username
     * @param string $password
     */
    public function login($username, $password) {
        $result = $this->logic->login($username, $password);
        if($result === FALSE) {
            $this->error = $this->logic->error;
            return false;
        }
        return $result;
    }

    /**
     * 退出登录
     * @return boolean
     */
    public function logout() {
        session('authkey', NULL);
        return TRUE;
    }
	/**
     * 修改管理员资料
	 * @params array 用户资料
	 * @files array 头像
     * @return bool
     */
	public function update($params,$files){
		$result = $this->logic->update($params);
		if($result === FALSE){
			$this->error = $this->logic->error;
			return false;
		}
		if(!$this->avatar($files)) return false;
		return true;
	}
	/**
     * 修改头像
	 * @file array 图片信息
     * @return result
     */
	public function avatar($file){
		if(empty($file['portrait']['name'])) return true;
		$ext = strtolower(pathinfo($file['portrait']['name'], PATHINFO_EXTENSION));
		$portrait = './uploadfile/avatar/'.ADMIN_ID.'.'.$ext;
		rename($file['portrait']['tmp_name'],$portrait);
		if(is_file($portrait) && file_exists($portrait)){
			$ext = strtolower(pathinfo($portrait, PATHINFO_EXTENSION));
			$name = basename($portrait, '.'.$ext);
		    $dir = dirname($portrait);
			if(in_array($ext, array('gif','jpg','jpeg','bmp','png'))){
				$name = $name.'_admin_44_44.'.$ext;
				$file = $dir.'/'.$name;
				$image = new image($portrait);
	            $image->thumb(44,44);
				$image->save($file);
				if(file_exists($file)) {
					$thumb = getavatar(ADMIN_ID,FALSE);
					$thumb = dirname($thumb)."/".ADMIN_ID."_admin.".$ext;
					dir::create(dirname($thumb));
					@rename($file, $thumb);
					@unlink($portrait);
					return true;
		        } else { 
					$this->error = '头像数据保存失败';
					return false;
		        }
			} else {
				$this->error = '请勿上传非法图片';
				return false;
			}
		} else {
			$this->error = '头像数据异常';
			return false;
		}
	}
	/**
     * 获取头像
     * @return path
     */
	 public function getthumb($id){
		 $thumb = getavatar($id,FALSE);
		 $ext = strtolower(pathinfo($thumb, PATHINFO_EXTENSION));
		 $dir = dirname($thumb);
		 $file = $dir.'/'.$id.'_admin.'.$ext;
		 if(file_exists($file)){
			 return $file;
		 }
		 return false;
	 }
    /**
     * ajax验证密码
     * @param string $password
     */
    public function ajax_password($password) {
        $result = $this->logic->check_password($password);
        if($result === FALSE) {
            $this->error = $this->logic->error;
            return false;
        }
        return true;
    }
}