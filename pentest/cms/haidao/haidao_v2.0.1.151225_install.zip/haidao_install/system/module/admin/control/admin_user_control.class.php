<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class admin_user_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->model = model('admin_user');
		$this->service = model('admin_user','service');
		$this->group_model = model('admin_group');
		$this->group_service = model('admin_group','service');
	}

	/* 管理团队 */
	public function index() {
		$data = $this->service->getAll();
		include $this->admin_tpl('admin_user_index');
	}
	
	/* 删除 */
	public function del() {
		$id = (array)$_GET['id'];
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		if (in_array($id, 1))showmessage('删除团队成员失败', url('index'), 0);
		$this->model->where(array('id' => array('IN', $id)))->delete();
		showmessage('删除团队成员成功', url('index'), 1);
	}
	/* 添加 */
	public function add() {
		$group = $this->group_model->get_select_data();
		if(checksubmit('dosubmit')){
			$_POST=array_filter($_POST); 
			$_POST['encrypt'] = random(10);
			$_POST['password'] = create_password($_POST['password'], $_POST['encrypt']);
			$r = $this->service->save($_POST);
			if($r == false) {
				showmessage($this->model->getError(), url('index'), 1);
			}else{
				showmessage('设置角色成功', url('index'), 1);
			}
		}else{
			include $this->admin_tpl('admin_user_update');
		}
	}
	/* 编辑 */
	public function edit() {
		$group = $this->group_model->get_select_data();
		if (checksubmit('dosubmit')) {
			$_POST=array_filter($_POST); 
			//是否更改密码
			if (array_key_exists("password", $_POST)) {
				$_POST['encrypt'] = random(10);
				$_POST['password'] = create_password($_POST['password'], $_POST['encrypt']);
			}

			$r = $this->service->save($_POST,FALSE);

			showmessage('设置角色成功', url('index'), 1);
		} else {
			$id = $_GET['id'];
			$data = $this->model->fetch_by_id($id);
			extract($data);
			include $this->admin_tpl('admin_user_update');
		}
		
	}

}
