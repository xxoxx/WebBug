<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class setting_service extends service {
	public function __construct() {
		$this->logic = model('setting','logic');
	}
	/**
	 * [update 编辑]
	 * @param [array] $params [信息]
	 * @return [boolean]    [返回结果]
	 */
	public function update($params){
		$result = $this->logic->update($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
	 * [get_setting 获取数据]
	 * @param [array] $key [缓存名称]
	 * @return [array]    [返回结果]
	 */
	public function get_setting($key){
		$get_setting = cache('setting') ? cache('setting') : model('setting')->getField('key,value',TRUE);
		if(is_string($key)) return $get_setting[$key];
		foreach($get_setting as $key => $value){
			$get_setting[$key] = unserialize($value) ? unserialize($value) : $value;
		}
		return $get_setting;
	}
}