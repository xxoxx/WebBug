<?php
return array(
    'USERNAME_NOT_EXIST' => '用户名不能为空',
    'PASSWORD_NOT_EXIST' => '密码不能为空',
    'ADMIN_USER_NOT_EXIST' => '账号不存在',
    'PASSWORD_CHECKED_ERROR' => '登陆密码验证失败',
    'NO_LOGIN' => '尚未登录或已过期',
    //团队管理
    '_DEL_ADMIN_USER_SUCCESS_' => '删除团队成员成功',
    '_DEL_ADMIN_USER_ERROR_' => '删除团队成员失败',
    '_UPDATE_ADMIN_USER_SUCCESS_' => '设置团队成员成功',
    //删除日志
    '_DEL_LOG_SUCCESS_' => '删除日志成功',
    //角色管理
    '_DEL_ADMIN_GROUP_SUCCESS_' => '删除角色成功',
    '_UPDATE_ADMIN_GROUP_SUCCESS_' => '设置角色成功',
    '_STATUS_SUCCESS_' => '角色状态改变成功',
    '_STATUS_ERROR_' => '角色状态改变失败',
);
