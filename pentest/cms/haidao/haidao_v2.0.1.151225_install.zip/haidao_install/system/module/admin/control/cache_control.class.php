<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class cache_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->service = model('admin/cache', 'service');
	}

    /**
     * 更新缓存
     * 1、站点缓存
     * 2、模块缓存
     * 3、插件缓存
     * 4、模板缓存
     * 5、标签缓存
     * 6、临时文件
     * 7、自定义缓存
     */
	public function clear() {
		$caches = array(
			'setting' => '设置', 
			'module' => '模块', 
			'plugin' => '插件', 
			'template' => '模板', 
			'taglib' => '标签', 
			'temp' => '临时文件', 
			'extra' => '拓展'
		);
        $step = intval($_GET['step']);		
		$keys = array_keys($caches);		
		$cache = $keys[$step];
				
        if($step >= count($caches)) {
	        showmessage('缓存更新完毕', "null", 1);
        }
        if(!isset($caches[$cache])) {
	        showmessage('参数错误');
        }
        $this->service->$cache();
        showmessage($caches[$cache].'更新完成，请稍后...', url('clear', array('step' => $step + 1)), 1);
	}
}