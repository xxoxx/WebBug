<?php include $this->admin_tpl('header','admin');?>
		<div class="fixed-nav layout">
			<ul>
				<li class="first">优化设置<a id="addHome" title="添加到首页快捷菜单">[+]</a></li>
				<li class="spacer-gray"></li>
				<li class="fixed-nav-tab"><a class="current" href="javascript:;">URL伪静态</a></li>
				<li class="fixed-nav-tab"><a href="javascript:;">SEO设置</a></li>
			</ul>
			<div class="hr-gray"></div>
		</div>
		<form method="POST" action="">
		<div class="content content-tabs padding-big have-fixed-nav">
			<p class="margin-top margin-bottom padding-left text-normal text-sub">URL 静态化可以提高搜索引擎抓取，开启本功能需要对 Web 服务器增加相应的 Rewrite 支持，且会轻微增加服务器负担。同时您还可以调整每个页面的静态格式，但不得删除其中的标记，重置静态格式请留空。注意，修改静态格式后您需要修改服务器的 Rewrite 规则设置</p>
			<div class="table clearfix bg-none border-none">
				<div class="tr border-none bg-none">
					<div class="th bg-none w15">
						<span class="td-con text-left">页面</span>
					</div>
					<div class="th bg-none w25">
						<span class="td-con text-left">标记</span>
					</div>
					<div class="th bg-none w50">
						<span class="td-con text-left">格式</span>
					</div>
					<div class="th bg-none w10">
						<span class="td-con">可用</span>
					</div>
				</div>
				
			
					<?php $i=0;?>
				<?php foreach( $data['value']['rewrite'] as $key => $value){?>
				<?php $i++?>
				<div class="tr bg-none">
					<div class="td w15">
						<input type="hidden" name="site_rewrite[rewrite][<?php echo $i?>][page]" value="<?php echo $value['page']?>">
						<span class="td-con text-left"><?php echo $value['page']?></span>
					</div>
					<div class="td w25">
						<input type="hidden" name="site_rewrite[rewrite][<?php echo $i?>][name]" value="<?php echo $value['name']?>">
						<span class="td-con text-left"><?php echo $value['name']?></span>
					</div>
					<div class="td w50">
						<span class="td-con text-left">
							<div class="double-click">
								<a class="double-click-button margin-none padding-none" title="双击可编辑" href="javascript:;"></a>
								<input name="site_rewrite[rewrite][<?php echo $i?>][type]" class="input double-click-edit text-ellipsis" type="text" value="<?php echo $value['type']?>" data-reset="true" />
							</div>
						</span>
					</div>
					<div class="td w10">
						<input type="hidden" name="site_rewrite[rewrite][<?php echo $i?>][display]" value="<?php echo $value['display']?>">
						<?php if($value['display'] == 0){?>
						<a class="ico_up_rack cancel" href="javascript:;" title="点击启用"></a>
						<?php }else{?>
						<a class="ico_up_rack" href="javascript:;" title="点击启用"></a>
						<?php }?>
					</div>
				</div>
				<?php }?>
				
			</div>
		</div>
		<div class="content content-tabs hidden padding-big have-fixed-nav"><!--SEO设置页-->
			<div class="form-box clearfix">
				<?php echo form::input('text', 'site_rewrite[site_rewrite_name]', $data['value']['site_rewrite_name'], '标题附加字：', '网页标题通常是搜索引擎关注的重点，本附加字设置出现在标题中商城名称后，如有多个关键字，建议用分隔符分隔'); ?>
				<?php echo form::input('text', 'site_rewrite[site_rewrite_keyword]', $data['value']['site_rewrite_keyword'], '商城关键词：', 'Keywords项出现在页面头部的<Meta>标签中，用于记录本页面的关键字，多个关键字请用分隔符分隔'); ?>
				<?php echo form::input('text', 'site_rewrite[site_rewrite_descript]', $data['value']['site_rewrite_descript'], '关键词描述：', 'Description出现在页面头部的Meta标签中，用于记录本页面的摘要与描述，建议不超过80个字'); ?>
				<?php echo form::input('textarea', 'site_rewrite[site_rewrite_other]', $data['value']['site_rewrite_other'], '其他页头信息：','如需在<head></head>中添加其他的HTML代码，可以使用本设置，否则请留空'); ?>
			</div>
		</div>
		<div class="padding-large-left">
			<input type="submit" class="button bg-main" value="保存"  data-reset="true"/>
		</div>
		</form>
		<script>
			//$('.form-box').formPlug();
			//推荐
			$(".table .ico_up_rack").bind('click',function(){
				if(!$(this).hasClass("cancel")){
					$(this).addClass("cancel");
					$(this).attr("title","点击启用");
				}else{
					$(this).removeClass("cancel");
					$(this).attr("title","点击禁用");
				}
			});
			$(".ico_up_rack").click(function(){
				if($(this).attr('class') == 'ico_up_rack'){
					$(this).prev().attr('value','1');
				}else{
					$(this).prev().attr('value','0');
				}
			})
		</script>
	</body>
</html>
