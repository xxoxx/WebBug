<?php
/**
 *		站点管理逻辑层
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */

class setting_logic extends logic {
	public function __construct() {
		$this->db = model('setting');
	}
	/**
	 * [lists 列表]
	 * @return   [type] [description]
	 */
	 public function lists(){
		$setting =$this->db->getField('key, value', true);
		return cache('setting', $setting, 'common');
	 }
	/**
	 * [update 编辑]
	 * @param [array] $params [信息]
	 * @return [boolean]         [返回ture]
	 */
	public function update($params = array()) {
		foreach ($params as $key => $value) {
			$this->db->update(array("key" => $key, 'value' => $value));
		}
		model('admin/cache', 'service')->setting();
		return TRUE;
	}
}