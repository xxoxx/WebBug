<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class template_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->model = model('admin/template', 'service');
	}

	public function index() {
		$tpls = $this->model->fetch_all();
		include $this->admin_tpl('template');
	}

	public function setdefault() {
		$theme = trim($_GET['theme']);
		if(empty($theme)) {
			showmessage('主题标识不能为空');
		}
		$tpls = $this->model->fetch_all();
		if(!$tpls[$theme]) {
			showmessage('主题不存在');
		}
		$this->config = new config;
		$this->config->file('template')->note('模板配置配置文件')->space(32)->to_require_one(array('TPL_THEME' => $theme));
		model('admin/cache', 'service')->template();
		model('admin/cache', 'service')->taglib();
		showmessage('主题设置成功', url('index'), 1);
	}
}