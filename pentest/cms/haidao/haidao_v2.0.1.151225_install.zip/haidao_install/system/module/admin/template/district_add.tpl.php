<?php
include $this -> admin_tpl('header');
?>
<form action="<?php echo url('add') ?>" name="district_add" data-ajax="true">
	<div class="form-box border-none clearfix padding-tb">
		<input type="hidden" name="parent_id" value="<?php echo $parent_id; ?>"/>
		<?php if ($parent_pos): ?>
			<?php echo form::input("text", 'parent_id', implode($parent_pos, ' > '), '上级地区', '', array("disabled" => "disabled")) ?>
		<?php endif ?>
		<?php echo form::input('text', 'name', $r['name'], '地区名称', '', array(
			'datatype' => '*',
			'nullmsg' => '地址名称不能为空'
		)); ?>
		<?php echo form::input('text', 'pinyin', $r['pinyin'], '地区拼音'); ?>
		<?php echo form::input('text', 'zipcode', $r['zipcode'], '邮政编码', '', array(
			'ignore'   =>'ignore',
			'datatype' => 'zip',
			'errormsg' => '邮政编码格式错误'
		)); ?>
	</div>
	<div class="padding margin-big-top text-right ui-dialog-footer">
		<input type="submit" class="button bg-main" name="dosubmit" value="确定" />
		<input type="reset" class="button margin-left bg-gray" value="取消" />
	</div>
</form>
<script type="text/javascript">
$(function() {
	try {
		var dialog = top.dialog.get(window);
		dialog.title('添加地区');
		dialog.reset();
	} catch (e) {
		return;
	}

	var district_add = $("[name=district_add]").Validform({
		ajaxPost:true,
		callback:function(ret) {
			dialog.title(ret.message);
			if(ret.status == 1) {
				setTimeout(function(){
					dialog.close(ret.message);
					dialog.remove();
				}, 1000);
			} else {
				return false;
			}
		}
	});

	$('[type=reset]').on('click', function() {
		dialog.close();
		return false;
	});
})</script>
</body>
</html>