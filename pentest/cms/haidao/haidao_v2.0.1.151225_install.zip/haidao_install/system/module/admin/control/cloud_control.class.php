<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class cloud_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->service = model('admin/cloud','service');
		$this->cloud =  unserialize(authcode(config('__cloud__','cloud'),'DECODE'));
	}

	public function index() {
		$cloud = $this->cloud;
		$site_isclosed = (int)model('admin/setting','service')->get_setting('site_isclosed');
		
		include $this->admin_tpl('cloud_index');
	}
	public function bulid(){
		if(checksubmit('dosubmit')) {
			$_result = $this->service->getMemberLogin($_GET['account'], $_GET['password']);
			if($_result['code'] != 200) {
				showmessage($_result['msg']);
			} else {
				$_config = array(
					'__cloud__' => array(
						'username'   => $_result['result']['username'],
						'realname'   => $_result['result']['realname'],
						'sms'        => $_result['result']['sms'],
						'coin'       => $_result['result']['coin'],
						'token'      => $_result['result']['token'],
						'identifier' => $_result['result']['site']['identifier'],
						'authorize'  => (int) $_result['result']['site']['authorize_status'],
						'domain'     => $_result['result']['site']['domain'],
					)
				);
				$_config['__cloud__'] = authcode(serialize($_config['__cloud__']),'ENCODE');
				
				$config_file = CONF_PATH.'cloud.php';
				if($fp = @fopen($config_file, 'wb')) {
					fwrite($fp, "<?php \nreturn " . stripslashes(var_export($_config,TRUE) . ";"));
					fclose($fp);
					showmessage('绑定成功', url('index'), 1);
				} else {
					showmessage('配置文件不可写');
				}
			}
		}else{
			include $this->admin_tpl('cloud_bulid');
		}
	}
	public function update(){
		$r = $this->service->update_site_userinfo();
		if($r){
			showmessage('更新成功', url('index'), 1);
		}else{
			showmessage('更新失败', url('index'), 0);
		}
	}
	public function getcloudstatus(){
		if(!isset($this->cloud)){
			$r = 2;
		}else{
			$r = $this->cloud ? $this->service->getcloudstatus() : false ;
		}
		showmessage('', '', $r);
	}
}