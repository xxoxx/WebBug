<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class admin_setup_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->model = model('admin/admin_user','table');
		$this->service = model('admin/admin', 'service');
	}
	/* 管理员资料 */
	public function edit() {
		if (checksubmit('dosubmit')) {
			$result = $this->service->update($_GET,$_FILES);
			if(!$result) 
				showmessage($this->service->error);
			$this->service->logout();  
			showmessage('操作成功,请重新登录',url('admin/public/login'),1);	
		}else{
			include $this->admin_tpl('admin_setup_index');
		}
	}
	/*ajax验证密码*/
	public function ajax_password(){
		$result = $this->service->ajax_password($_GET['param']);
		if(!$result){
			showmessage($this->service->error);
		}
		showmessage('', '', 1);
	}
}
