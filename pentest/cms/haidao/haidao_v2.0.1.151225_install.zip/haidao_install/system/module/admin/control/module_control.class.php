<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class module_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->m_service = model('admin/module', 'service');
	}

	public function index() {
		$modules = $this->m_service->lists();
		$install = (int) $_GET['install'];
		$enabled = (int) $_GET['enabled'];
		foreach($modules as $k => $v ) {
			if($v['isinstall'] != $install || $v['isenabled'] != $enabled) unset($modules[$k]);
		}
		include $this->admin_tpl('module_index');
	}
}