<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class site_control extends init_control{
    public function _initialize() {
        parent::_initialize();
		$this->service = model('setting','service');
		helper('attachment');
    }
    /* 基本设置 */
    public function base() {
		$array = array('exp_rate','cart_jump');
        if(checksubmit('dosubmit')) {
			if(!empty($_FILES['site_logo']['name'])) {
				$code = attachment_init(array('mid'=>$this->admin['id'],'allow_exts'=>array('bmp','jpg','gif','jpeg','png')));
				$_GET['site_logo'] =  model('attachment/attachment', 'service')->setConfig($code)->upload('site_logo');
				if(!$_GET['site_logo']){
					showmessage(model('attachment/attachment', 'service')->error);
				}
			}
			$there = array('balance_deposit');
			foreach($there as $v){
				 if(!array_key_exists($v,$_GET)){
					 $_GET[$v] = '';
				 }
			}
			$_GET['invoice_content'] = explode("\r\n", $_GET['invoice_content']);
			foreach($_GET as $k => $v){
				if(is_array($_GET[$k])){
					$_GET[$k] = serialize($v);
				}
			}
			$result = $this->service->update($_GET);
			if(!$result){
				showmessage($this->service->error);
			}
			showmessage('操作成功','',1);
        } else {
			$setting = model('setting')->getField('key, value', TRUE);
			// 获取所有已开启的支付方式
			$payment = cache('payment_enable');
			foreach ($payment as $k => $pay) {
				$payment[$k] = $pay['pay_name'];
			}
            include $this->admin_tpl('site_base');
        }
    }
	/* 注册与访问 */
    public function reg() {
      if(checksubmit('dosubmit')){
      		$_GET['reg_user_censor'] = trim(preg_replace("/\s*(\r\n|\n\r|\n|\r)\s*/", "\r\n", $_GET['reg_user_censor']));
      		$_GET['reg_pass_complex'] = serialize((array)$_GET['reg_pass_complex']);
			$result = $this->service->update($_GET);
			if(!$result){
				showmessage($this->service->error);
			}
			showmessage('操作成功','',1);
		}else{
			$setting = model('setting')->getField('key, value', TRUE);
			include $this->admin_tpl('site_reg');
		}
    }
	/* 优化设置 */
    public function rewrite() {
      if(checksubmit('dosubmit')){
      		$site_rewrite['site_rewrite'] = serialize($_GET['site_rewrite']);
      		$result = $this->service->update($site_rewrite);
			if(!$result){
				showmessage($this->service->error);
			} else {
				showmessage('操作成功','',1);
			}
		} else {
			$data = array();
			$data['key'] = 'site_rewrite';
			$info = model('setting')->where($data)->find();
			$data['value'] = unserialize($info['value']);
			include $this->admin_tpl('site_rewrite');
		}
    }
}
