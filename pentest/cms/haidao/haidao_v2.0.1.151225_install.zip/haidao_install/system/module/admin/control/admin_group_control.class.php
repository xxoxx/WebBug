<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class admin_group_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->model = model('admin_group');
		$this->service = model('admin_group','service');
	}

	/* 团队角色 */
	public function index() {
		$data = $this->service->getAll();
		include $this->admin_tpl('admin_group_index');
	}
	
	/* 删除 */
	public function del() {
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		$id = (array)$_GET['id'];
		if(in_array(1, $id))showmessage('设置角色成功');
		$this->model->where(array('id' => array('IN', $id)))->delete();
		showmessage('删除角色成功', url('index'), 1);
	}
	/* 添加 */
	public function add() {
		if(checksubmit('dosubmit')){
			$_GET=array_filter($_GET); 
			if (array_key_exists("rules", $_GET)) $_GET['rules'] = implode($_GET['rules'],',');
			$r = $this->service->save($_GET);
			if(!$r)showmessage($this->model->getError(), url('index'), 1);
			showmessage('设置角色成功', url('index'), 1);
		}else{
			//节点
			$this->node = model('node', 'service');
			$nodes = $this->node->get_checkbox_data();
			$nodes = list_to_tree($nodes);
			include $this->admin_tpl('admin_group_update');
		}
	}
	/* 编辑 */
	public function edit() {
		if (checksubmit('dosubmit')) {
			$_GET=array_filter($_GET); 
			$_GET['id'] = (int) $_GET['id'];
			if (array_key_exists("rules", $_GET)) {
				$_GET['rules'] = implode($_GET['rules'],',');
			}
			if($_GET['id'] > 1) {
				$r = $this->service->save($_GET);
				if($r === false) {
					showmessage($this->model->getError(), url('index'));
				}
			}
			showmessage('设置角色成功', url('index'), 1);
		} else {
			//个人信息
			$data = current($this->service->getAll(array('id'=>$_GET['id'])));
			$data['rules'] = explode(',',$data['rules']);
			//节点
			$this->node = model('node', 'service');
			$nodes = $this->node->get_checkbox_data();
			$nodes = list_to_tree($nodes);
			include $this->admin_tpl('admin_group_update');
		}
	}


	public function ajax_status() {
		$id = $_GET['id'];
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		if((int)$id=1)showmessage('设置角色成功');
		if ($this->service->change_status($id)) {
			showmessage('角色状态改变成功', '', 1);
		} else {
			showmessage('角色状态改变失败', '', 0);
		}
	}

}
