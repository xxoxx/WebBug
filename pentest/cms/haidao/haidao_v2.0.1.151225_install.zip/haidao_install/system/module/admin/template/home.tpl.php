	<?php include $this->admin_tpl('header');?>
	<?php 
		$counts = model('order/order')->out_counts();
		$consult = model('goods/goods_consult','service')->handle();
		$userinfo = model('member/member')->where()->count();
		$field = "SUM(real_amount) sum,count(distinct member_id) as member_num,count(id) as order_num";
		$sqlmap['_string']='date_format(from_UNIXTIME(`create_time`),\'%Y-%m-%d\') = date_format(now(),\'%Y-%m-%d\')';
		$sqlmap['status']=1;
		$data = current(model('statistics/order', 'service')->_query($field,$sqlmap,$group));
		$params['status']=1;
		$pal = model('goods/goods_spu','service')->get_lists($params);
		$pay = $pal['count'];
		$params['status']=0;
		$pal = model('goods/goods_spu','service')->get_lists($params);
		$pay_out= $pal['count'];
		$params['label'] = 3;
		$pal = model('goods/goods_spu','service')->get_lists($params);
		$pay_file= $pal['count'];
	?>
		<div class="fixed-nav layout">
			<ul>
				<li class="first">后台首页</li>
				<li class="spacer-gray"></li>
			</ul>
			<div class="hr-gray"></div>
		</div>
		<div class="content padding-big have-fixed-nav">
			<div class="warn-info border bg-white margin-top padding-lr">
				<i class="warn-info-ico ico_warn margin-right"></i>重要消息提醒：主要用于新版本更新通知或重大漏洞修复提示。
				<a href="javascript:;" class="close text-large fr">×</a>
			</div>
			<div class="margin-top">
				<div class="fl w50 padding-small-right">
					<table cellpadding="0" cellspacing="0" class="border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">待办事项</th>
							</tr>
							<tr class="border">
								<td class="padding-big-left padding-big-right padding-bottom">
									<table cellpadding="0" cellspacing="0" class="layout">
										<tbody>
											<tr class="line-height-40">
												<th class="text-left" colspan="3">订单提醒</th>
											</tr>
											<tr class="text-lh-big">
												<td>待付款订单：<b class="text-main"><?php echo $counts['pay']?></b></td>
												<td>待确认订单：<b class="text-main"><?php echo $counts['confirm']?></b></td>
												<td>待发货订单：<b class="text-main"><?php echo $counts['delivery']?></b></td>
											</tr>
											<tr class="text-lh-big">
												<td>待评价商品：<b class="text-main"><?php echo $counts['load_comment']?></b></td>
												<td>待退货申请：<b class="text-main"><?php echo $counts['load_return']?></b></td>
												<td>待退款申请：<b class="text-main"><?php echo $counts['load_refund']?></b></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr class="border">
								<td class="padding-big-left padding-big-right padding-bottom">
									<table cellpadding="0" cellspacing="0" class="layout">
										<tbody>
											<tr class="line-height-40">
												<th class="text-left" colspan="3">商品管理</th>
											</tr>
											<tr class="text-lh-big">
												<td>出售中的商品：<b class="text-main"><?php echo $pay;?></b></td>
												<td>待上架的商品：<b class="text-main"><?php echo $pay_out;?></b></td>
												<td>库存警告商品：<b class="text-main"><?php echo $pay_file;?></b></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td class="padding-big-left padding-big-right padding-bottom">
									<table cellpadding="0" cellspacing="0" class="layout">
										<tbody>
											<tr class="line-height-40">
												<th class="text-left" colspan="3">信息管理</th>
											</tr>
											<tr class="text-lh-big">
												<td>待处理咨询：<b class="text-main">
													<?php echo $consult;?>
												</b></td>
												<td>&nbsp;</td>
												<td>&nbsp;</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table cellpadding="0" cellspacing="0" class="margin-top border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">商城信息</th>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">已完成订单总数</span>
									<span class="fr"><?php echo $counts['completion']?></span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">注册会员总数</span>
									<span class="fr"><?php echo $userinfo;?></span>
								</td>
							</tr>
						</tbody>
					</table>
                    <table cellpadding="0" cellspacing="0" class="margin-top border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">开发团队</th>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">总策划兼产品经理&emsp;</span>
									<span class="margin-large-left fl">董&emsp;浩</span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">产品设计与研发团队</span>
									<span class="margin-large-left fl">夏雪强&emsp;李春林&emsp;孔智翱&emsp;王小龙&emsp;饶家伟&emsp;秦秀荣&emsp;杜珍珍</span>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<div class="fl w50 padding-small-left">
					<table cellpadding="0" cellspacing="0" class="border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">资金管理</th>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big line-height-40">
									<span class="fl">今日销售额</span>
									<span class="margin-left text-big fl">￥<em class="h2 fr"><?php echo sprintf("%.2f",$data['sum'])?></em></span>
									<span class="text-main fr">人均客单价：￥
									<?php echo sprintf("%.2f",$data['sum']/((int)$data['order_num'] - (int)$data['pass_order_num']))?>
									</span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">本月销售额</span>
									<span class="margin-left fl">￥<?php echo sprintf("%.2f",$data['sum']) * 2 .".00"?></span>
									<span class="fr">以自然月统计</span>
								</td>
							</tr>
							<tr>
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">今年销售额</span>
									<span class="margin-left fl">￥<?php echo sprintf("%.2f",$data['sum']) * 3 .".00"?></span>
									<!--<span class="fr">以自然年统计</span>-->
								</td>
							</tr>
						</tbody>
					</table>
					<table cellpadding="0" cellspacing="0" class="margin-top border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">系统信息</th>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">系统版本</span>
									<span class="fr">海盗云商&nbsp;v<?php echo HD_VERSION ?>_<?php echo HD_RELEASE; ?></span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">服务器系统及PHP</span>
									<span class="fr"><?php echo  php_uname('s');?>/<?php echo  PHP_VERSION;?></span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">服务器软件</span>
									<span class="fr"><?php echo  php_uname('s');?></span>
								</td>
							</tr>
							<tr class="border-bottom">
								<td class="text-left today-sales padding-big padding-small-top padding-small-bottom line-height-40">
									<span class="fl">数据库信息</span>
									<span class="fr">MySQL&nbsp;<?php echo mysql_get_server_info();?>/数据库大小&nbsp;18.3M</span>
								</td>
							</tr>
						</tbody>
					</table>
                    <table cellpadding="0" cellspacing="0" class="margin-top border bg-white layout">
						<tbody>
							<tr class="bg-gray-white line-height-40 border-bottom">
								<th class="text-left padding-big-left">应用中心</th>
							</tr>
							<tr>
								<td>
									<div class="text-left today-sales layout border-top border-white fl" style="padding:0 20px;height:65px;line-height:64px;background-color:#fbfbfb;">
                                        <span class="fl">您有 <b class="text-main">3</b> 款应用可升级&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="text-main" href="">详情</a></span>
                                    </div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</body>
</html>
