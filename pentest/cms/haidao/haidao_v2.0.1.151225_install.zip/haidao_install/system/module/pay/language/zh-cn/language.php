<?php
return array(
    '_ENABLED_SUCCESS_' => '设置支付方式成功',
    '_ENABLED_ERROR_' => '设置支付方式失败',
    '_UNINSTALL_SUCCESS_' => '卸载支付方式成功',
    '_UNINSTALL_ERROR_' => '卸载支付方式失败',
);
