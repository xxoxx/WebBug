<?php include $this->admin_tpl('header','admin');?>
	<body>
		<div class="fixed-nav layout">
			<ul>
				<li class="first"><?php echo $payment['pay_name']?>设置</li>
				<li class="spacer-gray"></li>
			</ul>
			<div class="hr-gray"></div>
		</div>
		<div class="content padding-big have-fixed-nav">
			<form name="form" action="<?php echo url('config') ?>" method="POST">
			<div class="form-box clearfix">
				<?php foreach ($payment['setup'] as $key => $var): ?>
					<?php echo form::input($var['type'], 'config['.$key.']', $payment['config'][$key], $var['name'], $var['tips'],array('datatype' => "*")); ?>
				<?php endforeach ?>
				<?php unset($payment['setup']);unset($payment['config']);?>
				<?php foreach ($payment as $key => $var): ?>
					<?php echo form::input('hidden', $key, $var); ?>
				<?php endforeach ;?>
			</div>
			<div class="padding">
				<input type="submit" name="dosubmit" class="button bg-main" value="保存" />
				<a href="<?php echo(url('config'))?>" class="button margin-left bg-gray">返回</a>
			</div>
			</form>
		</div>
		<script type="text/javascript">
			$(function(){		
				$("[name=form]").Validform();
			})
		</script>
	</body>
</html>
