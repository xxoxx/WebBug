<?php
class index_control extends control {
	public function _initialize() {
		parent::_initialize();
		$this->service = model('pay/payment', 'service');
	}

	public function dnotify() {
		if(!defined('_PAYMENT_')) {
			showmessage('请勿非法访问');
		}
		$method = _PAYMENT_;
		$ret = $this->service->_notify(_PAYMENT_);
		if($ret !== false) {
			runhook('pay_success', $ret);
		}
	}

	public function dreturn() {
		if(!defined('_PAYMENT_')) {
			showmessage('请勿非法访问');
		}
		$method = _PAYMENT_;
		$ret = $this->service->_notify(_PAYMENT_);
		if($ret !== false) {
			runhook('pay_success', $ret);
		}
	}
}