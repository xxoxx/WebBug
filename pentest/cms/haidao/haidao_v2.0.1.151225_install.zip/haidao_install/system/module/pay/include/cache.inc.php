<?php
/* 更新用户组缓存 */
// model('pay/payment','service')->build_cache();