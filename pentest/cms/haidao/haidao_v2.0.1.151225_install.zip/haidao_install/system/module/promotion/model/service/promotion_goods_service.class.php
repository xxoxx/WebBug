<?php
class promotion_goods_service extends service {

	public function __construct() {
		$this->table = model('promotion/promotion_goods', 'table');
	}


	public function lists($sqlmap = array(), $limit = 10, $page = 1, $order = "sort ASC, id DESC") {
		$result['count'] = $this->table->where($sqlmap)->count();
		$result['lists'] = $this->table->where($sqlmap)->limit($limit)->page($page)->order($order)->select();
		foreach ($result['lists'] as $key => $value) {
			if($value['start_time'] && $value['start_time'] > TIMESTAMP) {
				$value['status'] = 1;
			} elseif($value['end_time'] && $value['end_time'] < TIMESTAMP) {
				$value['status'] = 2;
			} else {
				$value['status'] = 0;
			}
			$result['lists'][$key] = $value;
		}
		return $result;
	}

	public function fetch_by_id($id, $field = null) {
		$r = $this->table->find($id);
		return (empty($field)) ? $r : $r[$field];
	}

	/**
	 * 更新活动
	 * @param array $params 数组
	 * @return bool
	 */
	public function update($params = array()) {
		$params = $this->_format($params);
		if($params === false) {
			return FALSE;
		}
		$after = explode(",", $params['sku_ids']);
		$result = $this->table->update($params);
		if($result === false) {
			$this->error = $this->table->getError();
			return false;
		}

		if(isset($params['id']) && $params['id'] > 0) {
			$id = $params['id'];
			$operation = 'edit';
		} else {
			$id = $result;
			$operation = 'add';
		}
		$this->excute_by_skuid($after, $id, $operation);
		return $result;
	}

	public function delete($id) {
		$ids = (array) $id;
		if(empty($ids)) {
			$this->error = '参数错误';
			return false;
		}
		foreach($ids as $id ) {
			$sku_ids = $this->fetch_by_id($id, 'sku_ids');
			$_map = array();
			$_map['sku_id'] = array("IN", $sku_ids);
			model('goods_sku', 'table')->where($_map)->save(array("prom_id" => 0, "prom_type" => ''));
			$this->table->delete($id);
		}
		return true;
	}


	private function _format($params = array()) {
		if(empty($params)) {
			$this->error = '参数错误';
			return false;
		}
		if(empty($params['name'])) {
			$this->error = '促销名称不能为空';
			return false;
		}
		if(empty($params['sku_ids'])) {
			$this->error = '请指定参与活动的商品';
			return false;
		}
		$params['sku_ids'] = implode(",", $params['sku_ids']);
		if(empty($params['rules'])) {
			$this->error = '请设置本活动的规则';
			return false;
		}
		$params['rules'] = json_encode($params['rules']);
		$params['share_order'] = (int) $params['share_order'];

		if(isset($params['start_time']) && !empty($params['start_time'])) {
			$params['start_time'] = strtotime($params['start_time']);
		}
		if(isset($params['end_time']) && !empty($params['end_time'])) {
			$params['end_time'] = strtotime($params['end_time']);
		}
		$params['dateline'] = TIMESTAMP;
		$params['sort'] = 100;
		return $params;
	}

	/**
	 * 执行商品ID活动变更
	 * @param $after array 当前操作商品
	 * @param $before array 待操作商品
	 */
	private function excute_by_skuid($after = array(), $id = 0, $operation = 'add') {
		$before = array();
		// 需要计算出本次操作后新增、删除的差集
		$adds = array_diff((array) $after, (array) $before);
		if($adds) {
			$_map = array();
			$_map['sku_id'] = array("IN", $adds);
			$_map['prom_id'] = 0;
			model('goods_sku', 'table')->where($_map)->save(array("prom_id" => $id, "prom_type" => 'goods'));
		}
		if($operation == 'edit') {
			$before = $this->fetch_by_id($id, 'sku_ids');
			$dels = array_diff((array) $before, (array) $after);
			if($dels) {
				$_map = array();
				$_map['sku_id'] = array("IN", $dels);
				model('goods_sku', 'table')->where($_map)->save(array("prom_id" => 0, "prom_type" => ''));
			}
		}
		return true;
	}
}