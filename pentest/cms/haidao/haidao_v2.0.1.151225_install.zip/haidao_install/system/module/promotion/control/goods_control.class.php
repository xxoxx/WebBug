<?php
/**
 *		商品促销
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class goods_control extends init_control {
	public function _initialize() {
		parent::_initialize();
		$this->model = model('promotion/promotion_goods', 'service');
		$this->table = model('promotion/promotion_goods', 'table');
	}

	public function index() {
		$limit = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? $_GET['limit'] : 20;
		$result = $this->model->lists($sqlmap, $limit, $_GET['page']);
		$result['pages'] = $this->admin_pages($result['count'], $limit);
		include $this->admin_tpl('goods_index');
	}

	public function add() {
		if(checksubmit('dosubmit')) {
			$result = $this->model->update($_GET);
			if($result === false) {
				showmessage($this->model->error);
			} else {
				showmessage('成功添加订单促销活动', url('index'), 1);
			}
		} else {
			include $this->admin_tpl('goods_add');
		}
	}

	public function edit() {
		$id = (int) $_GET['id'];
		$info = $this->model->fetch_by_id($_GET['id']);
		if(!$info) {
			showmessage('参数错误');
		}
		if(checksubmit('dosubmit')) {
			$result = $this->model->update($_GET);
			if($result === false) {
				showmessage($this->model->error);
			} else {
				showmessage('成功编辑订单促销活动', url('index'), 1);
			}
		} else {
			$info['sku_lists'] = model('goods/goods_sku', 'service')->sku_detail($info['sku_ids']);
			include $this->admin_tpl('goods_edit');
		}
	}

	public function delete() {
		$ids = (array) $_GET['id'];
		if(empty($ids)) {
			showmessage('参数错误');
		}
		$result = $this->model->delete($ids);
		if($result === false) {
			showmessage($this->model->error);
		} else {
			showmessage('促销活动删除成功', url('index'), 1);
		}
	}

	public function ajax_name() {
		$id = (int) $_GET['id'];
		$name = $_GET['name'];
		if($id < 1 || empty($name)) {
			showmessage('参数错误');
		}
		$result = $this->table->where(array('id' => $id))->setField('name', $name);
		if($result === false) {
			showmessage($this->table->getError());
		} else {
			showmessage('修改成功', url('index'), 1);
		}
	}
}
