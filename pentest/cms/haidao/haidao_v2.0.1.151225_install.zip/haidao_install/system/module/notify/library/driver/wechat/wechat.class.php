<?php
class wechat {
	public function __construct($_config) {
		$this->config = $_config;
	}
	
	public function send($params){
		$wechat = new we($this->config);
		$r = $wechat->sendTemplateMessage($params);
		return ($r['errcode'] == 0 && $r['errmsg'] == 'ok');
	}
}
