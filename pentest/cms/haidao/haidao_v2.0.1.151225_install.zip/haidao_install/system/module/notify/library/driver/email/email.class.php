<?php
class email {
	public function __construct($_config) {
		$this->config = $_config;
	}
	
	public function send($params){
		$smtp = new smtp(
			$this->config['mail_smtpserver'], 
			$this->config['mail_smtpport'], 
			true, 
			$this->config['mail_mailuser'], 
			$this->config['mail_mailpass'], 
			$this->config['mail_formmail']
		);
//		$smtp->debug    = TRUE;
		$params['sender'] = empty($params['sender']) ? $this->config['mail_formmail'] : $params['sender'];
		$send = $smtp->sendmail($params['to'],$params['sender'],$params['subject'],$params['body'],$params['mailtype']);
		return $send;
	}
}
