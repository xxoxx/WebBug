<?php
class sms {
	public function __construct($_config) {
		$this->config = $_config;
		$this->cloud = model('admin/cloud','service');
	}
	
	public function send($params){
		$params['sms_sign'] = $this->config['sms_sign'];
		$r = $this->cloud->send_sms($params);
		return ($r['code'] == 200 && $r['result'] == TRUE) ? TRUE : FALSE;
	}
}
