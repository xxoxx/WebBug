<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class admin_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		$this->service = model('notify/notify', 'service');
		$this->temlage_service = model('notify/notify_template', 'service');
	}

	public function index() {
		$notifys = $this->service->fetch_all();
		include $this->admin_tpl('notify_index');
	}

	/* 配置参数 */
	public function config() {
		$notify = $this->service->fetch_by_code($_GET['code']);
		if($notify === FALSE) {
			showmessage($this->service->error);
		}
		if(checksubmit('dosubmit')) {
			$r = $this->service->config($_GET['vars'], $_GET['code']);
			if($r === false) {
				showmessage($this->service->error);
			}
			showmessage('操作成功', url('index'), 1);
		} else {
			$_setting = $this->service->get_fech_all();
			$_config = $_setting[$_GET['code']]['configs'];
			include $this->admin_tpl('notify_config');
		}
	}

	/* 配置模板 */
	public function template() {
		$notify = $this->service->fetch_by_code($_GET['code']);
		$hooks = array(
			'n_reg_success'=>'注册成功',
			'n_reg_validate'=>'注册验证',
			'n_mobile_validate'=>'手机验证',
			'n_email_validate'=>'邮箱验证',
			'n_back_pwd'=>'找回密码',
			'n_money_change'=>'余额变动',
			'n_recharge_success'=>'充值成功',
			'n_order_delivery'=>'订单发货',
			'n_confirm_order'=>'确认订单',
			'n_pay_success'=>'付款成功',
			'n_order_success'=>'下单成功',
			'n_goods_arrival'=>'商品到货',
		);
		$ignore = explode(',', $notify['ignore']);
		foreach ($ignore as $k => $v) {
			unset($hooks[$v]);
		}
		if(checksubmit('dosubmit')) {
			$template = array();
			$enabled = array();
			foreach ($hooks as $k => $v) {
				$template[$k] = $_GET[$k];
			}
			$enabled = $_GET['enabled'];
			$unit = new unit();
			$_GET['template'] = $unit->array2json($template);
			$_GET['enabled'] = json_encode($enabled);
			$_GET['name'] = $notify['name'];
			$result = model('notify_template')->update($_GET);
			showmessage('更新通知模板完成',url('index'));
		}else{
			$template = $this->temlage_service->fetch_by_code($_GET['code']);
			//单独处理短信
			if($_GET['code'] == 'sms'){
				$cloud = model('admin/cloud','service');
				$data = $cloud->getsmstpl();
				foreach ($data['result'] as $k => $v) {
					$template[$v['tpl_type']][]= $v;
				}
			}
			include $this->admin_tpl('notify_template');
		}
		
		
	}

	/* 开启或关闭 */

    public function ajax_enabled() {
    	if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
        $code = $_POST['code'];
        if ($this->service->change_enabled($code)) {
            showmessage('设置成功', '', 1);
        } else {
            showmessage('设置失败', '', 0);
        }
    }
	
	/**
     * 卸载支付方式
     */
    public function uninstall() {
    	if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
        $code = $_GET['code'];
        
        model('notify')->where(array('code'=>$code))->delete();
        model('notify_template')->where(array('id'=>$code))->delete();
        
        showmessage('卸载成功', url('index'), 1);
    }
}