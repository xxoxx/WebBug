<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class notify_template_service extends service
{
	public function _initialize() {
		$this->table = model('notify_template');
	}

	/* 根据标识 */
	public function fetch_by_code($code) {
		$data = $this->table->where(array('id'=>$code))->find();
		if(is_null($data))return FALSE;
		$data['enabled'] = json_decode($data['enabled'], TRUE);
		$data['template'] = json_decode($data['template'], TRUE);
        return $data;
	}
	
	/* 根据标识 */
	public function fetch_by_hook($hook) {
		$data = $this->table->where(array('_string'=>'enabled regexp \''.$hook.'\''))->select();
		if(is_null($data))return FALSE;
		foreach($data as $k=>$v){
			$data[$k]['enabled'] = json_decode($v['enabled'], TRUE);
			$data[$k]['template'] = json_decode($v['template'], TRUE);
			$data[$k]['template'] = $data[$k]['template'][$hook];
		}
        return $data;
	}

}