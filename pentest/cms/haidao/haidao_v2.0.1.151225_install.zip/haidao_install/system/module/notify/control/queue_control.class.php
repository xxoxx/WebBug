<?php
set_time_limit(0);  
ignore_user_abort(true); 
class queue_control extends control {
	public function _initialize() {
		parent::_initialize();
		$this->queue = model('notify/queue', 'service');
		$this->table = model('notify/queue', 'table');
		$this->cloud = model('admin/cloud','service');
	}

	public function index(){
		//获取发送列表
		$list = $this->table->where(array('status'=>0))->order(array('sort'=>'ASC'))->select();
		foreach ($list as $k => $v) {
			$data = json_decode($v['params'],TRUE);
			switch($v['type']){
				//$to, $sender, $subject, $body, $mailtype
				case 'email':
					if($this->queue->config('email')->send($data)){
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>1));
					}else{
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>2));
					}
					break;
				//	$mid, $title, $message, $dateline;	
				case 'message':
					if($this->queue->config('message')->send($data)){
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>1));
					}else{
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>2));
					}
					break;
				//$mobile, $tpl_id, $sms_sign, tpl_vars(array)
				case 'sms':
					if($this->queue->config('sms')->send($data)){
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>1));
					}else{
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>2));
					}
					break;
				//根据微信模板
				case 'wechat':
					if($this->queue->config('wechat')->send($data)){
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>1));
					}else{
						$this->table->where(array('id'=>$v['id']))->save(array('dateline'=>time(),'status'=>2));
					}
					break;
			}
		}
	}

	public function test(){
		$replays = array(
			//站内信
			'mid'=>20,
			//邮件参数
			'to'=>'vip@zskey.com',
			'mailtype' => 'HTML',//HTML TXT
			//手机参数
			'mobile'=>'13708867890',
			//微信参数
			'touser'=>'otjSBw6-SFm31f4zuJKpxvtx9HYc',
			'url'=>'http://www.haidao.la',
			'data'=>array(
				'first'=>'尊敬的用户，您已注册成功！',
				'keyword1'=>'首单5折',
				'keyword2'=>date('Y-m-d H:i:s',time()),
				'remark'=>'感谢您的使用'
			),
			
			
			//通用变量
			'{用户名}'=>'小白白',
			'{商城名称}'=>'三七二十一'.random(4),
		);
		//model('notify/notify','service')->execute('n_reg_success',$replays,100);
		model('notify/notify','service')->execute('n_money_change',$replays,100);
		
	}

}
