<?php include $this->admin_tpl('header', 'admin'); ?>
		<div class="fixed-nav layout">
			<ul>
				<li class="first">通知系统设置 - <?php echo $notify['name']?></li>
				<!--<li class="spacer-gray"></li>
				<li><a class="current" href="javascript:;">邮件设置</a></li>
				<li><a href="email_test.html">发送测试</a></li>-->
			</ul>
			<div class="hr-gray"></div>
		</div>
		<div class="content padding-big have-fixed-nav">
			<form method="post">
			<p class="padding-small-top padding-small-bottom">请设置您的通知模板，选择左侧通知类型并进行编辑</p>
			<div class="notify-model">
				<div class="left border border-sub">
					<?php foreach($hooks as $k=>$v):?>
						<a href="javascript:;" data-type="<?php echo $k?>">
							<?php echo $v?>
							<?php if(in_array($k, $template['enabled']) && is_array($template)):?>
								<!--关闭-->
								<label class="switch"><span class="control"><input type="checkbox" name="enabled[]" value="<?php echo $k?>"  checked="checked"/></span></label>
							<?php else:?>	
								<!--开启-->
								<label class="switch"><span class="control checked"><input type="checkbox"  name="enabled[]" value="<?php echo $k?>"/></span></label>
							<?php endif;?>
						</a>
					<?php endforeach;?>
				</div>
				<div class="right">
					<div class="wrap border border-sub bg-white clearfix">
						<?php include(MODULE_PATH.'library/driver/'.$_GET['code'].'/template.inc.php')?>
					</div>
				</div>
			</div>
			<div class="margin-big-top">
				<input type="submit" class="button bg-main" value="保存" />
				<input type="button" class="button margin-left bg-gray" value="返回" />
			</div>
			<input type="hidden" name="id" value="<?php echo $_GET['code']?>" />
			<input type="hidden" name="select_wrap" value="" />
			</form>
		</div>
		<script>
			$(function(){
				$(".notify-model .left a").eq(0).trigger('click');
				$("#editor").css({minHeight:"436px"});
				$(".form-group").css({"z-index":"99999"});
				$(".notify-model .left a").live('click',function(){
					$(this).addClass("current").siblings().removeClass("current");
					$("#content-label").html($(this).text());
					$("div[id^='edit_']").hide();
					$("#edit_"+$(this).attr('data-type')).show();
					$("input[name=select_wrap]").val($(this).attr('data-type'));
				});
				$(".notify-model .left a").eq(0).trigger("click");
				$(".switch").live('click',function(e){
					if($(this).find("input").is(":checked")){
						$(this).find(".control").addClass("checked");
						$(this).find("input").attr("checked", false);
					}else{
						$(this).find(".control").removeClass("checked");
						$(this).find("input").attr("checked", true);
					}
					e.stopPropagation();
				});
			})
			
		</script>
	</body>
</html>
