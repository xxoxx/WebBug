<?php
class message {
	public function __construct($_config) {
		$this->config = $_config;
		$this->message = model('member/member_message','service');
	}
	
	public function send($params){
		return $this->message->add($params);
	}
}
