<?php
class favorite_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
		$this->service = model('member/member_favorite', 'service');
	}

	public function index() {
		$result = $this->service->set_mid($this->member['id'])->lists(array(), 20, $_GET['page']);
		extract($result);
		$pages = pages($count, 20);
		$SEO = seo('我的收藏夹 - 会员中心');
		include template('favorite');
	}

	/* 添加收藏 */
	public function add() {
		$sku_id = (int) $_GET['sku_id'];
		if($sku_id < 1) {
			showmessage('参数错误');
		}
		$result = $this->service->set_mid($this->member['id'])->add($sku_id);
		if($result === false) {
			showmessage($this->service->error);
		} else {
			showmessage('加入收藏成功', '', 1);
		}
	}

	public function delete() {
		$sku_ids = (array) $_GET['sku_id'];
		$sku_ids = array_map('intval', $sku_ids);
		array_filter($sku_ids);
		if(empty($sku_ids)) {
			showmessage('参数错误');
		}
		$result = $this->service->set_mid($this->member['id'])->delete($sku_ids);
		if($result === false) {
			showmessage($this->service->error);
		} else {
			showmessage('删除收藏成功', url('index'), 1);
		}
	}

}