<?php
return array(
	'username'      => '用户名',
	'password'      => '密码',
	'email'         => '电子邮件',
	'mobile'        => '手机号',
	'register_time' => '注册时间',
	'register_ip'   => '注册IP',
	'login_time'    => '登录时间',
	'login_ip'      => '登录IP',
	'login_num'     => '登录次数',

	'member_group_name_require'		=> '等级名称为必填',
	'member_group_name_min_points'		=> '最小经验值必须为数字',
	'member_group_name_max_points'		=> '最大经验值必须为数字',
	'member_group_name_discount'		=> '折扣率必须为数字',
);