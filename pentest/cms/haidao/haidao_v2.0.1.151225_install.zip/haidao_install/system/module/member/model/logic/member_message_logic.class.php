<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class member_message_logic extends logic
{
	public function __construct(){
		$this->db = model('member/member_message', 'table');
	}
	/**
	 * [ajax_update 改变状态]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function ajax_update($params) {
		if(count($params) < 1){
			$this->error = '参数错误';
			return FALSE;
		}
		$data = array();
		$data['status'] = 1;
		foreach($params as $v){
			$data['id'] = (int)$v;
			$result = $this->db->update($data);
		}
		return $result;
	}
	/**
	 * [delete 批量删除]
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	public function delete($params) {
		$data = array();
		$data['id'] =  implode(',', $params);
		$result = $this->db->where(array('id'=>array('IN',$data['id'])))->delete();
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
	}
	/**
	 * [add 添加]
	 * @param  [array]  添加的数据
	 * @return [type]     [description]
	 */
	public function add($params) {
		$data = array();
		$data['mid'] =  $params['mid'];
		$data['title'] = $params['title'];
		$data['message'] = $params['message'];
		$data['dateline'] = time();
		$result = $this->db->update($data);
		if(!$result){
			$this->error = $this->db->getError();
			return FALSE;
		}
		return TRUE;
	}
}