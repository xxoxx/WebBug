<?php
core::load_class('init', 'goods');
class public_control extends init_control
{
	public function _initialize() {
		parent::_initialize();
		if($this->member['id'] > 0 && METHOD_NAME !== 'logout' && METHOD_NAME !== 'resetemail') {
			redirect(url('index/index'));
		}
		$this->service = model('member/member', 'service');
	}

	public function index() {
		error::system_error('_DATA_TYPE_INVALID_');
	}

	public function register() {
		$setting = cache('setting', '', 'common');
		if(!$setting['reg_allow']) {
			showmessage($setting['reg_closedreason']);
		}
		if(checksubmit('dosubmit')) {
			if(!$this->service->register($_GET)) {
				showmessage($this->service->error);
			}
			$url = $_GET['url_forward'] ? urldecode($_GET['url_forward']) : url('member/index/index');
			showmessage('注册成功', $url, 1);
		} else {
			$SEO = seo('会员注册');
			include template('register');
		}
	}

	public function login() {
		if(checksubmit('dosubmit')) {
			if(!$this->service->login($_GET['username'], $_GET['password'])) {
				showmessage($this->service->error);
			}
			$url = $_GET['url_forward'] ? urldecode($_GET['url_forward']) : url('member/index/index');
			showmessage('登录成功', $url, 1);
		} else {
			$SEO = seo('会员登录');
			include template('login');
		}
	}

	public function logout() {
		$this->service->logout();
		redirect(url('member/public/login'));
	}

	public function findpwd() {

	}

	public function ajax_register_check() {
		$result = $this->service->valid($_GET['name'],$_GET['param']);
		if($result === false){
			showmessage($this->service->error);
		}
		showmessage('', '', 1, array(), 'json');
	}
	/*邮箱验证*/
	public function resetemail(){
		$mid = $vcode = $email ='';
		extract($_GET,EXTR_IF_EXISTS);
		list($mid,$vcode,$email) = json_decode(authcode(base64_decode($vcode),'DECODE'),TRUE);

		$sqlmap = array();
		$sqlmap['mid'] = $mid;
		$sqlmap['action'] = 'resetemail';
		$sqlmap['vcode'] = $vcode;
		$sqlmap['dateline'] = array('EGT',time()-1800);
		$_vcode = model('vcode')->where($sqlmap)->getField('vcode');

		if ($_vcode !== $vcode) showmessage('验证码不正确!','',0);

		$data['id'] = $mid;
		$data['email'] = $email;

		$r = model('member/member')->update($data,FALSE);
		if($r){
			showmessage('修改邮箱成功',url('member/index/index'),1);
		}else{
			showmessage('修改邮箱失败',url('member/index/index'),0);
		}
	}
}