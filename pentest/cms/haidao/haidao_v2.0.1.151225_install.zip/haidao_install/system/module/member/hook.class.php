<?php
class member_hook
{
	public function pay_success($ret) {
		if($ret['result'] == 'success') {
			if($ret['out_trade_no'][0] == 'm') {
				$_map = array();
				$_map['order_sn'] = $ret['out_trade_no'];
				$_map['order_status'] = 0;
				$deposit = model('member_deposit')->where($_map)->find();
				if($deposit) {
					model('member/member','service')->change_account($deposit['mid'], 'money', '+'.$deposit['money'], $msg = '在线充值');
					$_deposit = array(
						'id' => $deposit['id'],
						'trade_sn' => $ret['trade_no'],
						'trade_time' => TIMESTAMP,
						'trade_status' => 1,
						'pay_code' => $ret['pay_code'],
						'order_status' => 1
					);
					model('member_deposit')->update($_deposit, false);
				}
				showmessage('支付成功', '../../index.php?m=member&c=money&a=log');
			}
		}
	}
}