<?php 
class member_message_service extends service
{
	public function __construct(){
		$this->logic = model('member/member_message','logic');
	}
	/**
     * 修改状态
	 *	$params [array] [数组]
     * @return [type] [description]
     */
	public function ajax_update($params) {
		$result = $this->logic->ajax_update($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return TRUE;
	}
	/**
     * 修改状态
	 *	$params [array] [数组]
     * @return [type] [description]
     */
	public function delete($params) {
		$result = $this->logic->delete($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return $result;
	}
	/**
     * 会员未读消息
	 *	$params [array] [数组]
     * @return [type] [description]
     */
	public function user_message($mid) {
		$data = array();
		$data['mid'] = (int)$mid;
		$data['status'] = 0;
		$rows = model('member_message')->where($data)->count();
		return (int)$rows;
	}
	/**
     * 添加消息
	 *	$params [array] [数组]
     * @return [type] [description]
     */
	 public function add($params){
		$result = $this->logic->add($params);
		if(!$result){
			$this->error = $this->logic->error;
			return FALSE;
		}
		return TRUE;
	 }
}