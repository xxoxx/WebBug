<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'admin');
class member_log_control extends init_control
{
    public function _initialize() {
        parent::_initialize();
        $this->service = model('member_log', 'service');
        $this->model = model('member_log', 'table');
    }

    public function index() {
        $limit = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? (int) $_GET['limit'] :20;
    	$sqlmap = array('type' => 'money');
    	$lists = $this->model->where($sqlmap)->page($_GET['page'])->limit($limit)->order('dateline desc')->select();
    	$count = $this->model->where($sqlmap)->count();
    	$pages = $this->admin_pages($count, $limit);
    	include $this->admin_tpl('member_log');
    }
}