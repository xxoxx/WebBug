<?php
class index_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
	}

	public function index(){
		$SEO = seo('会员中心');
		//收藏的商品
		$favorite = model('member/member_favorite', 'service')->set_mid($this->member['id'])->lists(array(), 10);
		//待评价商品
		$notcommentgoods = model('order/order_sku','table')->where(array('buyer_id' => $this->member['id'],'iscomment'=>0))->limit(10)->select();
		//进行中的订单
		// $counts = model('order/order','table')->member_id($this->member['id'])->out_counts();
		//咨询回复
		$counts['consult'] = (int)model('goods/goods_consult','service')->get_user_consult($this->member['id']);
		//站内信
		$counts['message'] = (int)model('member/member_message','service')->user_message($this->member['id']);
		//配置文件
		$_config = cache('setting');
		include template('index');
	}
	public function get_rec_data(){
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		$data = array();
		$data = model('goods/goods_sku','service')->lists(array('order'=>'rand()'),array('limit'=>10));
		$result = $data['lists'];
		foreach ($result as $key => $value) {
			$result[$key]['goods_url'] = url('goods/index/detail',array('sku_id'=>$value['sku_id']));
			$result[$key]['format_thumb'] = thumb($value['thumb'],105,105);
		}
		showmessage('success','',1,$result);
	}
	public function clear_history(){
		if(empty($_GET['formhash']) || $_GET['formhash'] != FORMHASH) showmessage('_TOKEN_ERROR_');
		$r = model('goods/goods_sku','service')->clear_history();
		showmessage('success','',1,$result);
	}
}