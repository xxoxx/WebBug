<?php
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
class account_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
		if($this->member['id'] < 1) {
			redirect(url('cp/index'));
		}
		$this->service = model('member/member_address', 'service');
		$this->vcode_table = model('vcode');
		helper('attachment');
	}

	public function index() {

	}

	public function safe() {
		$safe_level = 33;
		$safe_level_email = !empty($this->member['email']) ? 33 : 0 ;
		$safe_level_mobile = !empty($this->member['mobile']) ? 33 : 0 ;
		$safe_level = $safe_level + $safe_level_email + $safe_level_mobile;
		
		$member = $this->member;
		$SEO = seo('安全中心 - 会员中心');
		include template('account_safe');
	}
	
	//根据IP返回地区
	public function ajax_login_address(){
		$ip = $_GET['ip'];
		$_add = file_get_contents('http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json&id='.$ip);
		echo($_add);
	}
	
	//修改密码
	public function resetpassword(){
		$newpassword = $newpassword1 = $oldpassword ='';
		extract($_GET,EXTR_IF_EXISTS);
		if(md5(md5($oldpassword).$this->member['encrypt']) !== $this->member['password']){
			showmessage('旧密码不对!','',0);
		}
		
		if ($newpassword !== $newpassword1) {
			showmessage('两次密码不一致!','',0);
		}
		
		$data['password'] = md5(md5($newpassword).$this->member['encrypt']);
		$data['id'] = $this->member['id'];
		
		$r = model('member')->update($data,FALSE);
		if($r){
			showmessage('修改密码成功','',1);
		}else{
			showmessage('修改密码失败','',0);
		}
	}
	
	//修改密码
	public function resetmobile(){
		$mobile = $vcode ='';
		extract($_GET,EXTR_IF_EXISTS);
		$sqlmap = array();
		$sqlmap['mid'] = $this->member['id'];
		$sqlmap['action'] = 'resetmobile';
		$sqlmap['vcode'] = $vcode;
		$sqlmap['dateline'] = array('EGT',time()-1800);
		$_vcode = $this->vcode_table->where($sqlmap)->getField('vcode');
				
		if ($_vcode !== $vcode) showmessage('验证码不正确!','',0);
		
		$data['id'] = $this->member['id'];
		$data['mobile'] = $mobile;
		
		$r = model('member')->update($data,FALSE);
		if($r){
			showmessage('修改手机成功','',1);
		}else{
			showmessage('修改手机失败','',0);
		}
	}
	
	//发送验证码
	public function checkansend(){
		$notify_template = model('notify/notify_template','service');
		$template = $notify_template->fetch_by_code('sms');
		if(FALSE === $template || is_null($template['template']['n_mobile_validate'])) {
			showmessage('无法使用短信通知,请联系管理员');
		}
		
		$this->vcode_table->where(array('dateline'=>array('LT',strtotime(date('Y-m-d')))))->delete();
		$mobile = $_GET['mobile'];
		$setting = cache('setting', '', 'common');
		$vcode = random(5,1);
		$site_name = $setting['site_name'];
		
		if(!is_mobile($mobile)){
			showmessage('手机号不正确');
		}
		
		if($this->vcode_table->where(array('mid'=>$this->member['id'],'action'=>'resetmobile'))->count() >= 3) {
			showmessage('使用次数过多,请明天再试');
		}
			
		$replays = array(
			//站内信
			'mid'=>$this->member['id'],
			//手机参数
			'mobile'=>'13708867890',	
			//通用变量
			'{验证码}'=>$vcode,
			'{商城名称}'=>$site_name,
		);
		
		$this->vcode_table->add(array('mid'=>$this->member['id'],'vcode'=>$vcode,'action'=>'resetmobile','dateline'=>time()));
		model('notify/notify','service')->execute('n_mobile_validate',$replays,1);
		
		showmessage('消息已发送，请注意接收','',1);
	}

	public function checkansend_email(){
		$email ='';
		extract($_GET,EXTR_IF_EXISTS);
		$member_email = $this->member['email'];
		$vcode = random(5,1);
		$setting = cache('setting', '', 'common');
		$site_name = $setting['site_name'];
		$member_username = $this->member['username'];
		
		$notify_template = model('notify/notify_template','service');
		$template = $notify_template->fetch_by_code('email');
		if(FALSE === $template || is_null($template['template']['n_email_validate'] ||empty($member_email))) {
			showmessage('无法使用邮件通知,请联系管理员');
		}
		
		$replays = array(
			//站内信
			'mid'=>$this->member['id'],
			//邮件参数
			'to'=>'vip@zskey.com',
			'mailtype' => 'HTML',//HTML TXT
			//通用变量
			'{用户名}'=>$member_username,
			'{商城名称}'=>$site_name,
			'{邮件验证链接}'=>$_SERVER['HTTP_HOST'].url('member/public/resetemail',array('vcode'=>base64_encode(authcode(json_encode(array($this->member['id'],$vcode,$email)),'ENCODE')))),
		);

		
		$this->vcode_table->where(array('dateline'=>array('LT',strtotime(date('Y-m-d')))))->delete();
		$this->vcode_table->add(array('mid'=>$this->member['id'],'vcode'=>$vcode,'action'=>'resetemail','dateline'=>time()));
		model('notify/notify','service')->execute('n_email_validate',$replays,1);
		showmessage('邮件已发送，请注意接收','',1);
		
	}
	
	public function avatar() {
		if(checksubmit('dosubmit')) {
			if(empty($_GET['avatar'])) {
				showmessage('请上传头像','',0);
			}
			$avatar = $_GET['avatar'];
			$x = (int) $_GET['x'];
			$y = (int) $_GET['y'];
			$w = (int) $_GET['w'];
			$h = (int) $_GET['h'];
			if(is_file($avatar) && file_exists($avatar)) {
		        $ext = strtolower(pathinfo($avatar, PATHINFO_EXTENSION));
		        $name = basename($avatar, '.'.$ext);
		        $dir = dirname($avatar);
		        if(in_array($ext, array('gif','jpg','jpeg','bmp','png'))) {
		            $name = $name.'_crop_200_200.'.$ext;
		            $file = $dir.'/'.$name;
	                $image = new image($avatar);
	                $image->crop($w, $h, $x, $y, 200, 200);
	                $image->save($file);
		            if(file_exists($file)) {
		            	$avatar = getavatar($this->member['id'], false);
		            	dir::create(dirname($avatar));
		            	@rename($file, $avatar);
		            	showmessage('头像更换成功','',1);
		            } else {
		            	showmessage('头像数据裁剪失败','',0);
		            }
		        } else {
		        	showmessage('请勿上传非法图片','',0);
		        }
			} else {
				showmessage('头像数据异常','',0);
			}
		} else {
			$SEO = seo('修改头像 - 会员中心');
			$attachment_init = attachment_init(array('module' => 'member', 'mid' => $this->member['id']));
			include template('account_avatar');
		}
	}
}