<?php
class money_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
		$this->table = model('member/member_log','table');
		$this->service = model('pay/payment', 'service');
	}

	public function log($sqlmap=array()) {
		//配置文件
		$_config = cache('setting');
		$member = $this->member;
		$sqlmap['mid'] = $member['id'];
		$sqlmap['type'] = 'money';
		$count = $this->table->where($sqlmap)->count();
		$log = $this->table->where($sqlmap)->page($_GET['page'])->limit(15)->order("id DESC")->select();
		$pages = pages($count,15);
		$SEO = seo('账户余额 - 会员中心');
		include template('money_log');
	}

	/* 余额充值 */
	public function pay() {
		$current = model('admin/setting','service')->get_setting('balance_deposit');
		$payments = $this->service->getpayments('pc', $current);








		// $current_payments = model('admin/setting','service')->get_setting('balance_deposit');
		// //处理银行
		// if(in_array('bank', $current_payments) && isset($golb_payments['bank']) ){
		// 	$bank = array();
		// 	$_bank = unserialize($golb_payments['bank']['config']);
		// 	$bank = explode(',', $_bank['banks']);
		// }
		// $payments = array_intersect($current_payments, array_keys($golb_payments));




		if(checksubmit('dosubmit')) {
			$money = $pay_code = $pay_bank = '';
			extract($_GET,EXTR_IF_EXISTS);
			$pay_info = array();
			$pay_info['trade_sn'] = build_order_no('m');
			$pay_info['total_fee'] = $money;
			$pay_info['subject'] = '用户充值：'.$money;
			$pay_info['pay_bank'] = $pay_bank;
			//记录订单
			$data = array();
			$data['mid'] = $this->member['id'];
			$data['money'] = $money;
			$data['order_sn'] = $pay_info['trade_sn'];
			$data['order_time'] = time();
			model('member/member_deposit','service')->wlog($data);

			cookie('last_sn', $pay_info['trade_sn']);

			$pay_config = array();
			if($pay_code == 'wechat_qr'){
				$pay_config = unserialize($golb_payments[$pay_code]['config']);
				$pay_config = array_merge($pay_config,array('gateway_url'=>url('member/money/wechat_pay_return')));
				$code_url=$this->service->get_code_url($pay_code,$pay_info,$pay_config);
				$SEO = seo('收银台 - 会员中心');
				include template('wechat_qr_pay');
				exit();
			}
			$pay_url = $this->service->pay($pay_code,$pay_info,$pay_config);
			redirect($pay_url);
		}else{
			$SEO = seo('余额充值 - 会员中心');
			include template('member_pay');
		}
	}
	/* 检测是否支付成功 */
	public function payissuccess() {
		$status = model('member/member_deposit','service')->is_sucess(array('mid'=>$this->member['id'],'order_sn'=> cookie('last_sn')));
		exit(json_encode(array('status' => (int)$status)));
	}

}