<?php
class service_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
		if($this->member['id'] < 1) {
			redirect(url('cp/index'));
		}
		$this->service = model('order/order_server', 'service');
		$this->db = model('order/order_server');
		$this->order_sku_db = model('order/order_sku'); 
		$this->return_db = model('order/order_return');
		$this->return_service = model('order/order_server','service');
		$this->refund_db = model('order/order_refund');
		$this->track_service = model('order/order_track','service');
		$this->return_log = model('order/order_return_log');
		$this->refund_log = model('order/order_refund_log');
		helper('attachment');
		helper('order/function');
	}
	/**
	 * [index 售后列表]
	 * @return [type] [description]
	 */
	public function index(){
		$limit = (isset($_GET['limit']) && is_numeric($_GET['limit'])) ? $_GET['limit'] : 10;
		$page = ($_GET['page']) ? $_GET['page'] : 1;
		$lists = $this->service->get_servers(0,$this->member['id'],$limit,$page);
		$servers = $lists['lists'];
		$pages = pages($lists['count'], $limit);
		$SEO = seo('售后服务 - 会员中心');
		include template('sale_service');
	}
	/**
	 * [return_refund 售后详情]
	 * @return [type] [description]
	 */
	public function return_refund(){
		$SEO = seo('售后服务 - 会员中心');
		$server = $this->return_db->where(array('o_sku_id' => $_GET['id']))->field('delivery_name,delivery_sn,status')->find();
		$refund_id = $this->refund_db->where(array('o_sku_id' => $_GET['id']))->getfield('id');
		$server_id = $this->db->where(array('refund_id' => $refund_id))->getfield('return_id');
		$refund = $this->refund_db->where(array('o_sku_id' => $_GET['id']))->getfield('status');
		if($refund_id && !$server_id){
			$_GET['type'] = 'refund';
		}
		if($_GET['type'] == 'refund'){
			if(!is_null($refund)){
				include template('return_refund_next');
				return true;
			}
		}
		if(!$server){
			$attachment_init = attachment_init(array('module' => 'server', 'mid' => $this->member['id']));
			$price = $this->order_sku_db->where(array('id' => $_GET['id']))->getfield('real_price');
			include template('return_refund');
			return true;
		}else{
			if(!is_null($refund)){
				$_GET['type'] = 'delivery';
			}
			if($_GET['type'] == 'delivery'){
				$sqlmap = array();
				$sqlmap['enabled'] = 1;
				$deliverys = model('order/delivery')->lists($sqlmap);
				foreach ($deliverys as $key => $delivery) {
					$deliverys[$delivery['identif']] = $delivery['name'];
					unset($deliverys[$key]);
				}
				if(empty($server['delivery_sn'])){
					include template('return_refund_three');
					return true;
				}else{
					$track = $this->track_service->kuaidi100($server['delivery_name'],$server['delivery_sn']);
					include template('return_refund_four');
					return true;
				}
			}
			include template('return_refund_next');
			return true;
		}
		include template('return_refund');
	}
	/**
	 * [ajax_delivery 买家返货申请]
	 * @return [type] [description]
	 */
	public function ajax_delivery(){
		$return_id = $this->return_db->where(array('o_sku_id'=>$_GET['id']))->getfield('id');
		$result = $this->return_service->return_goods($return_id,$_GET['delivery_name'],$_GET['delivery_sn']);
		$refund = $this->refund_db->where(array('o_sku_id'=>$_GET['id']))->find();
		// 创建退款日志
		$operator = get_operator();	// 获取操作者信息
		$log['refund_id']     = $refund['id'];
		$log['order_sn']      = $refund['order_sn'];
		$log['sub_sn']        = $refund['sub_sn'];
		$log['o_sku_id']      = $refund['o_sku_id'];
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];
		$log['action']           = '用户发货完毕';
		$log['msg'] = $_GET['delivery_desc'];
		$this->refund_log->update($log);
		if(!$result){
			showmessage($this->service->error,'',0);
		}else{
			showmessage('提交成功！',url('index'),1);
		}
	}
	public function ajax_return_cancel(){
		$result = $this->return_db->where(array('o_sku_id'=>$_GET['id']))->save(array('status' => -1));
		$return = $this->return_db->where(array('o_sku_id'=>$_GET['id']))->find();
		// 写入退货日志
		$operator = get_operator();	// 获取操作者信息
		$log['return_id']     = $return['id'];
		$log['order_sn']      = $return['order_sn'];
		$log['sub_sn']        = $return['sub_sn'];
		$log['o_sku_id']      = $return['o_sku_id'];
		$log['action']        = '用户取消退货退款申请';
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];		
		$result = $this->return_log->update($log);
		if(!$result){
			showmessage($this->service->error,'',0);
		}else{
			showmessage('提交成功！',url('index'),1);
		}
	}
	public function ajax_refund_cancel(){
		$result = $this->refund_db->where(array('o_sku_id'=>$_GET['id']))->save(array('status' => -1));
		$refund = $this->refund_db->where(array('o_sku_id'=>$_GET['id']))->find();
		// 创建退款日志
		$operator = get_operator();	// 获取操作者信息
		$log['refund_id']     = $refund['id'];
		$log['order_sn']      = $refund['order_sn'];
		$log['sub_sn']        = $refund['sub_sn'];
		$log['o_sku_id']      = $refund['o_sku_id'];
		$log['operator_id']   = $operator['id'];
		$log['operator_name'] = $operator['username'];
		$log['operator_type'] = $operator['operator_type'];
		$log['action']           = '用户取消退款申请';
		$this->refund_log->update($log);
		if(!$result){
			showmessage($this->service->error,'',0);
		}else{
			showmessage('提交成功！',url('index'),1);
		}
	}
	/**
	 * [ajax_return 提交退货且退款申请]
	 * @return [type] [description]
	 */
	public function ajax_return(){
		$result = $this->service->create_return($_GET['id'] ,$_GET['amount'] ,$_GET['cause'] ,$_GET['desc'],$_GET['imgs']);
		if($result === FALSE){
			showmessage($this->service->error,'',0);
		}else{
			showmessage('提交成功！','',1);
		}
	}
	/**
	 * [ajax_refund 提交仅退款申请]
	 * @return [type] [description]
	 */
	public function ajax_refund(){
		$sn = $this->order_sku_db->where(array('id'=>$_GET['id']))->getfield('sub_sn');
		$result = $this->service->create_refund($_GET['type'] ,$sn ,$_GET['amount'] ,$_GET['desc'] ,$_GET['id'],$_GET['imgs']);
		if($result === FALSE){
			showmessage($this->service->error,'',0);
		}else{
			showmessage('提交成功！',url('index'),1);
		}
	}
}