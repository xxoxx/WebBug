<?php
class taglib_member_address
{
	public function __construct() {
		//$this->model = model('member');
	}

	public function lists($sqlmap = array(), $options = array()) {
		var_dump('address');
		return $result;
	}
}