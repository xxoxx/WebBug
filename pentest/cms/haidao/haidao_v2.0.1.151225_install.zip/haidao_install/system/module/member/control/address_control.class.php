<?php
/**
 * @version        $Id$
 * @author         master@xuewl.com
 * @copyright      Copyright (c) 2007 - 2013, Chongqing Zero Technology Co. Ltd.
 * @link           http://www.xuewl.com
**/
class address_control extends cp_control
{
	public function _initialize() {
		parent::_initialize();
		if($this->member['id'] < 1) {
			redirect(url('cp/index'));
		}
		$this->service = model('member/member_address', 'service');
	}

	public function index() {
		$sqlmap = array();
		$sqlmap['mid'] = $this->member['id'];
		$result = $this->service->lists($sqlmap);
		extract($result);
		$pages = pages($count, 10);
		$SEO = seo('收货地址 - 会员中心');
		include template('address');
	}

	public function add() {
		if(checksubmit('dosubmit')) {
			$_GET['mid'] = $this->member['id'];
			$result = $this->service->add($_GET);
			if($result === FALSE) {
				showmessage($this->service->error);
			}
			showmessage('收货地址添加成功', url('index'), 1);
		} else {
			$SEO = seo('添加收获地址 - 会员中心');
			include template("address_add");
		}
	}

	public function edit() {
		$_GET['id'] = (int) $_GET['id'];
		if($_GET['id'] < 1) {
			showmessage('参数错误');
		}
		$address = $this->service->mid($this->member['id'])->fetch_by_id($_GET['id']);
		if(!$address) {
			showmessage('没有权限');
		}
		if(checksubmit('dosubmit')) {
			$_GET['mid'] = $this->member['id'];
			$result = $this->service->edit($_GET);
			if($result === FALSE) {
				showmessage($this->service->error);
			}
			showmessage('收货地址编辑成功', url('index'), 1);
		} else {
			$SEO = seo('编辑收货地址 - 会员中心');
			include template("address_edit");
		}
	}

	public function delete() {
		$id = (int) $_GET['id'];
		if($id < 1) showmessage('参数错误');
		$result = $this->service->mid($this->member['id'])->delete($id);
		if($result === FALSE) {
			showmessage($this->service->error);
		}
		showmessage('收货地址删除成功', url('index'), 1);
	}

	/* 设置默认 */
	public function set_default() {
		$id = (int) $_GET['id'];
		if($id < 1) {
			showmessage('参数错误');
		}
		$r = $this->service->mid($this->member['id'])->fetch_by_id($id);
		if(!$r) showmessage('没有权限');
		$result = $this->service->set_default($id, $this->member['id']);
		if($result === FALSE) {
			showmessage($this->service->error);
		}
		showmessage('默认收货地址设置成功', url('index'), 1);
	}

	public function ajax_district(){
		$id = (int) $_GET['id'];
		$result = model('admin/district', 'service')->get_children($id);
		echo json_encode($result);
	}

}