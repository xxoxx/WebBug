<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
core::load_class('init', 'goods');
class order_control extends init_control {

    public function _initialize() {
        parent::_initialize();
        if($this->member['id'] < 1) {
			redirect(url('cp/index',array('url_forward'=>urlencode($_SERVER['REQUEST_URI']))));
		}
        $this->table = model('order/order');
        $this->table_sub = model('order/order_sub');
        $this->service = model('order/order','service');
        $this->service_sub = model('order/order_sub','service');
        $this->service_track = model('order/order_track','service');
        helper('order/function');
    }

    /* 我的订单 */
    public function index() {
    	// 查询条件
		$sqlmap = array();
		$sqlmap = $this->service->build_sqlmap($_GET);
		$sqlmap['buyer_id'] = $this->member['id'];
        if (isset($_GET['sn'])) $sqlmap['sn'] = array('LIKE','%'.$_GET['sn'].'%');
		if (!isset($_GET['type'])) $sqlmap['status'] = array('IN','1,2');
        $limit  = (isset($_GET['limit'])) ? $_GET['limit'] : 10;
        $orders = $this->table->where($sqlmap)->page($_GET['page'])->order('id DESC')->limit($limit)->select();
        $count  = $this->table->where($sqlmap)->count();
        $pages  = pages($count,$limit);
        $SEO = seo('我的订单 - 会员中心');
        include template('my_order');
    }

    /* 订单详情 */
    public function detail() {
        $o_d_id = remove_xss($_GET['o_d_id']);
        $detail = $this->service_sub->sub_detail($_GET['sub_sn'] ,$o_d_id);
        if (!$detail) showmessage('该订单不存在');
        //更新跟踪物流
        if($detail['delivery_status'] > 0 && $o_d_id > 0){
            $this->service_track->update_api100($detail['sub_sn'],$o_d_id);
            $detail = $this->service_sub->sub_detail($_GET['sub_sn'] ,$o_d_id);
        }
        $detail['_member'] = model('member/member')->find($detail['buyer_id']);
        $detail['_main'] = $this->table->where(array('sn' => $detail['order_sn']))->find();
        // 日志
        $detail_logs = model('order/order_log','service')->get_by_order_sn($detail['sub_sn']);
        $setting = model('admin/setting','service')->get_setting();
        $SEO = seo('订单详情 - 会员中心');
        include template('order_detail');
    }

    /* 取消订单 */
    public function cancel() {
        if (checksubmit('dosubmit')) {
            $sub_sn = remove_xss($_GET['sub_sn']);
            $order = $this->table_sub->field('buyer_id')->where(array('sub_sn' => $sub_sn))->find();
            if ($order['buyer_id'] != $this->member['id']) {
                showmessage('您无权操作该订单');
            }
            $result = $this->service_sub->set_order($sub_sn ,$action = 'order',$status = 2 ,array('msg'=>'用户取消订单','isrefund' => 1));
            if (!$result) showmessage($this->service_sub->error);
            showmessage('取消订单成功','',1,'json');
        } else {
            showmessage('请勿非法访问');
        }
    }

    /* 放入回收站 */
    public function recycle() {
        if (checksubmit('dosubmit')) {
            $sn = remove_xss($_GET['sn']);
            $order = $this->table->field('member_id')->where(array('sn' => $sn))->find();
            if ($order['member_id'] != $this->member['id']) showmessage('您无权操作该订单');
            $result = $this->service->set_order($sn ,$action = 'order',$status = 3 ,array('msg'=>'订单放入回收站'));
            if (!$result) showmessage($this->service->error);
            showmessage(lang('已放入回收站'),'',1,'json');
        } else {
            showmessage('请勿非法访问');
        }
    }

    /* 删除订单 */
    public function delete_sn() {
        if (checksubmit('dosubmit')) {
            $sn = remove_xss($_GET['sn']);
            $order = $this->table->field('member_id')->where(array('sn' => $sn))->find();
            if ($order['member_id'] != $this->member['id']) showmessage('您无权操作该订单');
            $result = $this->service->set_order($sn ,'order', 4 ,array('msg'=>'用户删除订单'));
            if (!$result) showmessage($this->service->error);
            showmessage(lang('删除订单成功'),'',1,'json');
        } else {
            showmessage('请勿非法访问');
        }
    }

    /* 确认收货 */
    public function finish() {
        if (checksubmit('dosubmit')) {
            $sub_sn = remove_xss($_GET['sub_sn']);
            $order = $this->table_sub->field('buyer_id')->where(array('sub_sn' => $sub_sn))->find();
            if ($order['buyer_id'] != $this->member['id']) showmessage('您无权操作该订单');
            $data = array();
            $data['msg'] = '确认订单商品收货';
            $data['o_delivery_id'] = remove_xss($_GET['o_d_id']);
            $result = $this->service_sub->set_order($sub_sn ,'finish',1 ,$data);
            if (!$result) showmessage($this->service_sub->error);
            showmessage(lang('确认订单商品收货成功'),'',1,'json');
        } else {
            showmessage('请勿非法访问');
        }
    }

}