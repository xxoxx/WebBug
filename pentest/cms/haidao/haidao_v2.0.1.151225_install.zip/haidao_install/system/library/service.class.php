<?php
class service extends base {}