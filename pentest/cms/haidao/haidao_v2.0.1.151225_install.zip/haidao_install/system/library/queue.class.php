<?php
class queue {

    protected $handler    ;

    /* 加入队列 */
    public function add($type = 'email', $method, $params, $sort) {
        $params = (is_array($params) && !empty($params)) ? json_encode($params) : $params;
        $data = array(
            'type'  => $type,
            'method' => $method,
            'params' => $params,
            'dateline' => TIMESTAMP,
            'sort' => (int) $sort
        );
        return model('queue')->add($data);
	}

    public function update($id, $status) {
        return model('queue')->where(array('id' => $id))->setField('status', 1);
    }

    public function run() {
        $queues = model('queue')->order("sort ASC, id DESC")->select();
        if(!$queues) return FALSE;
        foreach ($queues AS $queue) {
            //$this->get_handler($queue['type'])->$queue['method']($queue['params']);
        }
        return true;
    }

    public function get_handler() {
        return false;
        return $this->handler;
    }

    public function get() {
        global $members;
        print_r($members);
    }


}