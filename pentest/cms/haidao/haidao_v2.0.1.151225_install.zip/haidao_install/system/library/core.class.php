<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class core{

	private static $_app;

	public static function app() {
		return self::$_app;
	}

	public static function run() {
		if(!is_object(self::$_app)) {
			self::$_app = application::instance();
		}
		return self::$_app;
	}

	public static function handleException($exception) {
		error::exception_error($exception);
	}

	public static function handleError($errno, $errstr, $errfile, $errline) {
		if($errno & APP_DEBUG) {
			error::system_error($errstr, false, true, false);
		}
	}

	public static function handleShutdown() {
		if(($error = error_get_last()) && $error['type'] & APP_DEBUG) {
			error::system_error($error['message'], false, true, false);
		}
	}

    public static function load_class($class, $module, $layer = 'control', $initialize = false) {
		static $_class = array();
		$module = (empty($module)) ? MODULE_NAME : $module;
		$class_name = $class.'_'.$layer;
		$class_dir = APP_PATH.config('DEFAULT_H_LAYER').'/'.$module.'/'.$layer.'/';

		if(config('SUBCLASS_PREFIX') && is_file($class_dir.config('SUBCLASS_PREFIX').$class_name.EXT)) {
			$class_name = config('SUBCLASS_PREFIX').$class_name;
		}
		$class_file = $class_dir.$class_name.EXT;
		if(require_cache($class_file)) {
			$class = TRUE;
			if($initialize == TRUE && class_exists($class_name)) {
				$class = new $class_name();
			}
			$_class[$class_name] = $class;
			return $class;
		} else {
			error::system_error('_CLASS_NOT_EXIST_');
		}
		return FALSE;
	}

    public static function load_model($name, $layer = 'table', $initialize = TRUE) {
		static $_models = array();
		$module = MODULE_NAME;
		/* 插件模式 */
		if($name[0] == '#') {
			list(, $pluginid, $name) = explode("#", $name);
		}
		if(strpos($name, '/') !== FALSE) {
			list($module, $name) = explode("/", $name);
		}
		$file = $name.'_'.$layer;
		$class = $name."\\".$layer;
		if(!isset($_models[$class])) {
			$instance = FALSE;
			$files = array();
			if($pluginid) {
				$files[] = APP_PATH.'plugin/'.$pluginid.'/model/'.$layer.'/'.$file.EXT;
			} else {
				$files[] = APP_PATH.config('DEFAULT_H_LAYER').'/'.$module.'/model/'.$layer.'/'.$file.EXT;
			}
			$files[] = APP_PATH.'model/'.$layer.'/'.$file.EXT;
			if(require_array($files, TRUE) && class_exists($file)) {
				$instance = new $file();
			}

			if(!$instance) {
				$instance = new $layer($name);
			}
			$_models[$class] = $instance;
		}
		return $_models[$class];
    }

    public static function autoload($class) {
        if(FALSE !== strpos($class, '_')) {
            $array = explode('_', $class);
            $layer = (is_array($array)) ? array_pop($array) : '';
            $name = substr($class, 0, -strlen('_'.$layer));
            return self::load_class($name, '', $layer);
        } else {
            return require_cache(LIB_PATH.$class.'.class.php');
        }
	}
}
