<?php
class load {
	protected $load;

	protected $_librarys = array();
	protected $_models = array();
	protected $_helpers = array();

	public function __get($name) {
		return null;
	}

	public function __set($name, $value) {
		$this->$name = $value;
		return;
	}

	public function helper($helpers = array()) {
		static $_helpers = array();
		foreach($helpers AS $helper) {
			self::_load_helper($helper);
		}
		return true;
	}

	private function _load_helper($helper) {
		$files = array (
			APP_ROOT.'function/'.$helper.'_helper.php',
		);
//		var_dump(12);
		//if(!require_array($files, true)) {
		//	error::system_error('fd', true, true, true);
		//}
	}

	/* 加载类库 */
	public function library($librarys, $driver, $params) {
		static $_librarys = array();
		
		return '1234';
	}
	
	
	public function table($name = '') {
		static $_tables = array();
		if(!isset($_tables[$name])) {
			if(false !== strpos($name, '/')) {
				list($module, $file) = explode('/', $name);
				$folder = APP_ROOT.config('DEFAULT_H_LAYER').'/'.$module.'/';
			} elseif(false !== strpos($name, '#')) {
				list(, $pluginid, $file) = explode('#', $name);
				$folder = APP_ROOT.'plugin/'.$pluginid.'/';
			} else {
				$folder = LIB_PATH.'table/';
				$file = $name;
			}
			$filename = $folder.$file.'_table'.EXT;
			if(require_cache($filename)) {
				$class = basename($filename);
				$_tables[$name] = new $class();
			} else {
				$_tables[$name] = new table($name);
			}			
		}
		return $_tables[$name];
	}

	public function model($name) {
		static $_models = array();
		if(!isset($_models[$name])) {
			
		}
		return $_models;
	}

	public function autoload($class) {
		/**
		$class 根据下划线拆分
			list(module, class, layer) = explode("_", $class);

			如果只有一个：进入 library
			如果是两个，则默认为控制器
			如果是三个，同上

			所有的类均通过
			$this->load 的子方法加载，包括 library  model  helpers ,可以多次重复载入，不必担心重复的问题。

				$this->load->config();
				$this->load->library();
				$this->load->helper();
				$this->load->cache();
				$this->load->model();
				$this->load->table(); {
					$this->load->table('member')		// 当前模块
					$this->load->table('admin/member')  // 指定模块
					$this->load->table('#admin#member') // 插件
				}
				
					
					


			类库尽可能通过连贯方式实现，例如：
				$this->load->table('admin_user')->fetch_all_by_id();

			嵌入开发架构：
				整站分为 model（服务层） 与 table（数据层） 、control (控制器)


			语言包
				调用：
					lang(module:file, key, value) ,若未找到，则返回大写的key
					语言包在加载时通过静态变量缓存，缓存名为 {模块：文件名}
				定义：语言包通过 return array() 方式定义，不区分大小写

			关于钩子
				钩子只预埋在前台模板里可用于拓展的，可以在插件中实现不修改源文件而动态改变数据结果

			配置文件
				获取&设置 	config([file:]key, value)
			缓存方法：
				获取&设置 	cache([file:]key, value, options) 当 value 为空，则标识设置

			插件：
				访问： plugin.php?id=mod:method
				{
					访问： {mod}.inc.php
					钩子： hooks.class.php
					缓存： cache.class.php
				}
		**/

	}
}

/**
所有的钩子写入 hooks 表并缓存
module
layer
name
**/