<?php
class logic extends base{}