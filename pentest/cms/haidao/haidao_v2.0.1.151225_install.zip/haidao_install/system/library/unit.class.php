<?php
/**
 *      [Haidao] (C)2013-2099 Dmibox Science and technology co., LTD.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      http://www.haidao.la
 *      tel:400-600-2042
 */
class unit {
	private function array_urlencode($params){
		if(is_array($params)) {  
	        foreach($params as $key => $value) {  
	            $params[urlencode($key)] = $this->array_urlencode($value);  
	        }  
	    } else {  
	        $params = urlencode($params);  
	    }  
	    return $params;  	
	}
	public function array2json($params){
		return urldecode(json_encode($this->array_urlencode($params)));      
	}
}
