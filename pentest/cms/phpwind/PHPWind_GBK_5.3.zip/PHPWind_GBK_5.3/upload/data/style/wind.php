<?php
$stylepath = 'wind';
$tplpath = 'wind';
$yeyestyle = 'yes';
$tablecolor = '#A6CBE7';//table
$tdcolor = '#D4EFF7';
$tablewidth = '98%';
$mtablewidth = '98%';
$forumcolorone	= '#ffffff';
$forumcolortwo	= '#F7FAFB';
$threadcolorone = '#ffffff';
$threadcolortwo = '#F7FAFB';
$readcolorone = '#ffffff';
$readcolortwo = '#F7FAFF';
$maincolor = '#FBFBFB';
?>