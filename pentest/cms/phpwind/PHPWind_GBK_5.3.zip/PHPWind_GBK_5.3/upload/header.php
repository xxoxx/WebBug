<?php
!function_exists('readover') && exit('Forbidden');

require(R_P.'require/header.php');
?>