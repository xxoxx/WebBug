<?php
!function_exists('readover') && exit('Forbidden');
Showmsg('data_error');
?>