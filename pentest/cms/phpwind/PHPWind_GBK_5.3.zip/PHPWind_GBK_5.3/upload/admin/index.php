<?php
!function_exists('adminmsg') && exit('Forbidden');

isset($adskin) ? Cookie('adskin',$adskin) : $adskin = GetCookie('adskin');
if($adskin){
	include PrintEot('index');exit;
}
require GetLang('left2');

$leftdb = $nav_left;
$headdb = array();
$guides = 'var guides={';
$titles = 'var titles={';
$dfcate = '';

if(If_manager){
	$headdb['manager'] = $nav_head['manager'];
	$output1 = '';
	foreach($nav_manager['option'] as $key=>$val){		
		$output1 .= "'$key' : ['$val[0]','$val[1]'],";
	}
	$output1 = substr($output1,0,-1);
	$guides .= "\r\n\t'manager' : {'manager' : {{$output1}}},";
	$titles .= "'manager' : '$nav_manager[name]',";
	//$dfcate  = 'manager';
}
foreach($leftdb as $cate=>$left){
	$output1 = '';
	foreach($left as $title=>$value){
		$output2 = '';
		foreach($value['option'] as $key=>$val){
			if($rightset[$key]){
				if(!array_key_exists(0,$val)){
					foreach($val as $k=>$v){
						$output2 .= "'$k' : ['$v[0]','$v[1]'],";
					}
				} else{
					$output2 .= "'$key' : ['$val[0]','$val[1]'],";
				}
			}
		}
		if(!$output2) continue;
		$titles .= "'$title' : '$value[name]',";
		$output2 = substr($output2,0,-1);
		$output1.= "'$title' : {{$output2}},";
	}
	if(!$output1) continue;
	$output1 = substr($output1,0,-1);
	$guides .= "\r\n\t'$cate' : {{$output1}},";
	$nav_head[$cate] && $headdb[$cate] = $nav_head[$cate];
	!$dfcate && $dfcate = $cate;
}

$guides = substr($guides,0,-1)."\n}";
$titles = substr($titles,0,-1)."}";

include PrintEot('index2');exit;
?>