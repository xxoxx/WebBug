<?php
!function_exists('readover') && exit('Forbidden');

require_once PrintHack('index');footer();
?>