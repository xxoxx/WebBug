<?php
	
if(!defined('IN_HDWIKI')) {
	exit('Access Denied');
}

define('HDWIKI_VERSION', '5.1');
define('HDWIKI_RELEASE', '20121102');

?>