<?php

!defined('IN_HDWIKI') && exit('Access Denied');

class control extends base{
	
	function control(& $get,& $post){
		$this->base($get, $post);
		$this->view->setlang($this->setting['lang_name'],'back');
		$this->load('upgrade');
		if($this->hgetcookie('querystring')) {
			$this->prev_querystring = $this->hgetcookie('querystring');
		}
	}
	
	function dodefault(){
		$this->view->display('admin_upgrade');
	}
	
	function docheck() {
		$this->hsetcookie('querystring', null, 3600);
		$avaliable_count = $_ENV['upgrade']->get_available_count();
		echo (empty($avaliable_count) || $avaliable_count === 'false') ? 'false' : $avaliable_count;
	}
	
	function doinitpage() {
		$this->hsetcookie('querystring', $this->prev_querystring, 3600);
		$available_packages = $_ENV['upgrade']->get_available_packages();
		if($available_packages) {
			$this->view->assign('packages', $available_packages);
		} 
		$this->view->display('admin_upgrade_initpage');
	}
	
	function doinstall() {
		$this->hsetcookie('querystring', $this->prev_querystring, 3600);
		set_time_limit(0);
		$proceed = true;
		$first_package = $_ENV['upgrade']->get_available_packages(1);
		if(!$first_package) {
			$this->view->display('admin_upgrade_initpage');
			return;
		}
	
		$_ENV['upgrade']->start_install($first_package);
		
		$this->show_header($first_package);

		$this->flush( '<li>���ڼ������ڴ� ...');
		$this->show_status($_ENV['upgrade']->check_memory(), $proceed);

		if($proceed) {
			$this->flush( '<li>���������ļ� ...');
			$this->show_status($_ENV['upgrade']->download_package(), $proceed);
		}

		if($proceed) {
			$this->flush( '<li>����У���ļ�MD5 ...');
			$this->show_status($_ENV['upgrade']->check_md5(), $proceed);
		}
		
		if($proceed) {
			$this->flush( '<li>�����ͷ��ļ� ...');
			$this->show_status($_ENV['upgrade']->extract_zip(), $proceed);
		}

		if($proceed) {
			$this->flush( '<li>���ڼ��Ŀ��Ȩ�� ...');
			$this->show_status($_ENV['upgrade']->check_permission(), $proceed);
		}
		
		if($proceed) {
			$this->flush( '<li>���ڸ������ļ� ...');
			$this->show_status($_ENV['upgrade']->copy_newfile(), $proceed);
		}
		
		//�ж��Ƿ���� upgrade_{release_code}.php �ļ���������ڣ�ת�����ļ�����
		if($proceed) {
			$upgrade_php = "upgrade_{$first_package['release_code']}.php";
			if(file_exists(HDWIKI_ROOT.'/'.$upgrade_php)) {
				
				//ת��  upgrade_{release_code}.php
				echo("<li>���ļ�������ɡ�<span style='color:red'>��������һ������ɺ�����������,��ȴ� 10 �����Զ�������һ��</span></li>");
				echo '<script type="text/javascript">
					window.parent.set_next({action:"'.$upgrade_php.'", btn_html:"��һ��", timer: 10});
					</script>';
			} else {
				
				//������װ������ʱ�ļ�
				$this->flush( '<li>����������ʱ�ļ� ...');
				$this->show_status($_ENV['upgrade']->make_clean(), $proceed);
				
				echo("<li>{$first_package['release_code']} �������</li>");
				echo '<script type="text/javascript">window.parent.install_finish();</script>';
			}
			
		} else {
			echo '<script type="text/javascript">window.parent.install_retry();</script>'; //����
		}
		
		
		$this->show_footer();
		$this->flush();
	}

	function flush($string='') {
		echo $string;
		@ob_end_flush();
	    @ob_flush();
	    @flush();
	    @ob_start();
	}

	function show_header(&$package) {
		echo <<<HTML
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
HTML;
		echo '<meta http-equiv="Content-Type" content="text/html;charset='.WIKI_CHARSET.'">';
		echo <<<HTML
<link href="style/default/admin/admin.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.head_title { line-height: 30px; padding-top: 2px; margin-bottom: 20px; border-bottom: solid 1px #CCC; }
ul li { line-height: 24px; border-bottom: 1px solid #EEE; padding: 0 2px; position: relative; }
ul span { position: absolute; right: 0; top: 0; }
</style>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">window.parent.install_start();</script>
</head>
<body>
<div class="head_title">���ڰ�װ������ {$package['release_code']}</div>
<ul>
HTML;
	}

	function show_footer() {
		echo '</ul>';
		echo '<script type="text/javascript">window.parent.set_next({disabled: false});</script> ';
		echo '</body></html>';
	}

	function show_status($status, &$proceed) {
		if($status) {
			echo '<span style="color: green">�ɹ�</span>';
		} else {
			echo '<span style="color: red">ʧ��</span>';
			$proceed = false;
		}
		$this->flush('</li>');
 	}


}