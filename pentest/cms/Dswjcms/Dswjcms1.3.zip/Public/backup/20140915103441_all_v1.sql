--
-- MySQL database dump
-- Created by DBManage class, Power By dswj. 
-- http://dianshiweijin.com 
--
-- 主机: localhost
-- 生成日期: 2014 年  09 月 15 日 10:34
-- MySQL版本: 5.5.24-log
-- PHP 版本: 5.4.3

--
-- 数据库: `dswjjds`
--

-- -------------------------------------------------------

