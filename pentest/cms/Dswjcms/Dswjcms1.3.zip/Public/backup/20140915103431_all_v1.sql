--
-- MySQL database dump
-- Created by DBManage class, Power By dswj. 
-- http://dianshiweijin.com 
--
-- 主机: localhost
-- 生成日期: 2014 年  09 月 15 日 10:34
-- MySQL版本: 5.5.24-log
-- PHP 版本: 5.4.3

--
-- 数据库: `dswjjds`
--

-- -------------------------------------------------------

--
-- 表的结构ds_admin
--

DROP TABLE IF EXISTS `ds_admin`;
CREATE TABLE `ds_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` char(32) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_admin
--

--
-- 表的结构ds_borrow_log
--

DROP TABLE IF EXISTS `ds_borrow_log`;
CREATE TABLE `ds_borrow_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL,
  `actionname` varchar(800) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_borrow_log
--

--
-- 表的结构ds_city
--

DROP TABLE IF EXISTS `ds_city`;
CREATE TABLE `ds_city` (
  `mid` smallint(4) NOT NULL,
  `city` varchar(11) NOT NULL,
  `var` smallint(4) NOT NULL,
  PRIMARY KEY (`var`),
  UNIQUE KEY `var` (`var`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_city
--

--
-- 表的结构ds_coverdue
--

DROP TABLE IF EXISTS `ds_coverdue`;
CREATE TABLE `ds_coverdue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `money` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `days` tinyint(4) NOT NULL DEFAULT '1',
  `type` tinyint(1) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_coverdue
--

--
-- 表的结构ds_instation
--

DROP TABLE IF EXISTS `ds_instation`;
CREATE TABLE `ds_instation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '0',
  `catpid` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT '0',
  `hostid` int(11) NOT NULL DEFAULT '0' COMMENT '发送信息号码',
  `friendid` int(11) NOT NULL DEFAULT '0' COMMENT '接收信息号码',
  `hostname` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL COMMENT '发送者名称',
  `friendname` varchar(20) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL COMMENT '接收者名称',
  `title` varchar(30) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT 'no title',
  `msg` varchar(150) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `type` tinyint(1) DEFAULT '1',
  `rd` tinyint(1) DEFAULT '0',
  `status_h` tinyint(1) DEFAULT '1' COMMENT '1正常2回收3删除',
  `status_f` tinyint(1) DEFAULT '1',
  `addline` varchar(11) CHARACTER SET utf8 COLLATE utf8_estonian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_instation
--

--
-- 表的结构ds_integralconf
--

DROP TABLE IF EXISTS `ds_integralconf`;
CREATE TABLE `ds_integralconf` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `pid` tinyint(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `value` varchar(15) NOT NULL,
  `state` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_integralconf
--

--
-- 表的结构ds_links
--

DROP TABLE IF EXISTS `ds_links`;
CREATE TABLE `ds_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `url` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `time` varchar(12) NOT NULL,
  `img` varchar(25) NOT NULL,
  `order` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_links
--

--
-- 表的结构ds_membership_grade
--

DROP TABLE IF EXISTS `ds_membership_grade`;
CREATE TABLE `ds_membership_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `img` varchar(30) NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_membership_grade
--

--
-- 表的结构ds_money_log
--

DROP TABLE IF EXISTS `ds_money_log`;
CREATE TABLE `ds_money_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `actionname` varchar(40) NOT NULL,
  `total_money` decimal(20,10) NOT NULL,
  `available_funds` decimal(20,10) NOT NULL,
  `freeze_funds` decimal(20,10) NOT NULL,
  `operation` decimal(20,10) NOT NULL,
  `counterparty` varchar(16) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_money_log
--

--
-- 表的结构ds_offline
--

DROP TABLE IF EXISTS `ds_offline`;
CREATE TABLE `ds_offline` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `type` smallint(3) NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `bank` varchar(25) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_offline
--

--
-- 表的结构ds_overdue
--

DROP TABLE IF EXISTS `ds_overdue`;
CREATE TABLE `ds_overdue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `money` decimal(15,2) NOT NULL,
  `days` tinyint(4) NOT NULL DEFAULT '1',
  `type` tinyint(1) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_overdue
--

--
-- 表的结构ds_recharge
--

DROP TABLE IF EXISTS `ds_recharge`;
CREATE TABLE `ds_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ord` smallint(3) NOT NULL,
  `number` varchar(20) NOT NULL,
  `uid` int(11) NOT NULL,
  `nid` varchar(15) NOT NULL,
  `genre` tinyint(2) NOT NULL,
  `money` decimal(10,2) unsigned NOT NULL,
  `poundage` decimal(6,2) unsigned NOT NULL,
  `account_money` decimal(10,2) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `handlers` varchar(16) NOT NULL,
  `audittime` int(11) NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_recharge
--

--
-- 表的结构ds_refund
--

DROP TABLE IF EXISTS `ds_refund`;
CREATE TABLE `ds_refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nper` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `money` decimal(15,2) NOT NULL,
  `interest` decimal(15,2) NOT NULL,
  `time` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_refund
--

--
-- 表的结构ds_shield_msg
--

DROP TABLE IF EXISTS `ds_shield_msg`;
CREATE TABLE `ds_shield_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `shieldId` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '0正常1回收2删除',
  `rd` tinyint(1) DEFAULT '0' COMMENT '0未读1已读 ',
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_shield_msg
--

--
-- 表的结构ds_shuffling
--

DROP TABLE IF EXISTS `ds_shuffling`;
CREATE TABLE `ds_shuffling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `state` tinyint(1) NOT NULL,
  `time` varchar(12) NOT NULL,
  `img` varchar(25) NOT NULL,
  `order` tinyint(1) NOT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='轮播';

--
-- 转存表中的数据 ds_shuffling
--

--
-- 表的结构ds_unite
--

DROP TABLE IF EXISTS `ds_unite`;
CREATE TABLE `ds_unite` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `state` tinyint(1) NOT NULL,
  `pid` mediumint(8) NOT NULL,
  `name` varchar(15) NOT NULL,
  `value` varchar(15) NOT NULL,
  `order` mediumint(8) NOT NULL DEFAULT '5',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=274 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_unite
--

--
-- 表的结构ds_user_log
--

DROP TABLE IF EXISTS `ds_user_log`;
CREATE TABLE `ds_user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `actionname` varchar(40) NOT NULL,
  `page` varchar(100) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_user_log
--

--
-- 表的结构ds_userinfo
--

DROP TABLE IF EXISTS `ds_userinfo`;
CREATE TABLE `ds_userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(13) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `national` smallint(2) NOT NULL,
  `born` varchar(12) NOT NULL,
  `idcard` varchar(18) NOT NULL,
  `idcard_img` varchar(50) NOT NULL,
  `native_place` varchar(23) NOT NULL,
  `location` varchar(23) NOT NULL,
  `marriage` tinyint(1) NOT NULL,
  `education` tinyint(2) NOT NULL,
  `monthly_income` tinyint(2) NOT NULL,
  `housing` tinyint(1) NOT NULL,
  `buy_cars` tinyint(1) NOT NULL,
  `industry` tinyint(2) NOT NULL,
  `company` varchar(15) NOT NULL,
  `qq` varchar(12) NOT NULL,
  `bank` smallint(3) NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  `bank_account` varchar(19) NOT NULL,
  `fixed_line` varchar(15) NOT NULL,
  `cellphone` varchar(11) NOT NULL,
  `assure` int(11) unsigned NOT NULL,
  `wechat` varchar(255) NOT NULL,
  `certification` tinyint(1) NOT NULL,
  `email_audit` tinyint(1) NOT NULL,
  `cellphone_audit` tinyint(1) NOT NULL,
  `video_audit` tinyint(1) NOT NULL,
  `site_audit` tinyint(1) NOT NULL,
  `wechat_audit` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_userinfo
--

--
-- 表的结构ds_withdrawal
--

DROP TABLE IF EXISTS `ds_withdrawal`;
CREATE TABLE `ds_withdrawal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `money` decimal(10,2) unsigned NOT NULL,
  `time` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `handlers` varchar(16) NOT NULL,
  `audittime` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 ds_withdrawal
--

