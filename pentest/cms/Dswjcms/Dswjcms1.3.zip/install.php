<?php

define('THINK_PATH', './framework/');
define('APP_NAME','Install');
define('APP_PATH', './Install/');
define('APP_DEBUG', true);
include THINK_PATH."ThinkPHP.php";
?>