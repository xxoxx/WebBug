<?php
// +----------------------------------------------------------------------
// | dswjcms
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.tifaweb.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)
// +----------------------------------------------------------------------
// | Author: 宁波市鄞州区天发网络科技有限公司 <dianshiweijin@126.com>
// +----------------------------------------------------------------------
// | Released under the GNU General Public License
// +----------------------------------------------------------------------
defined('THINK_PATH') or exit();
class BorrowAction extends HomeAction {
//-------------借款标发布--------------
	//普通标显示
	public function index(){
		$linkage=$this->borrowLinkage();
		$this->assign('linkage',$linkage);
		//标题、关键字、描述
		$Site = D("Site");
		$site=$Site->field('keyword,remark,title,link')->where('link="'.$_SERVER['REQUEST_URI'].'"')->find();
		$this->assign('si',$site);
		$active['borrow']='active';
		$this->assign('active',$active);
		$head='<link  href="__PUBLIC__/css/style.css" rel="stylesheet">';
		$this->assign('head',$head);
		$Borrow=D("Borrowing");
		$borrow=$Borrow->where('uid='.$this->_session('user_uid').' and id='.$this->_get('mid'))->find();
		$borrow['data']=array_filter(explode(",",$borrow['data']));
		$this->assign('b',$borrow);
		$this->display();
    }
		
	//普通标发布
	public function ordinaryAdd(){
		$this->homeVerify();
		//$this->bidValidation(1);
		$msgTools = A('msg','Event');
		$model=D('Borrowing');
		$money=M('money');
		$mone=$money->where('uid='.$this->_session('user_uid'))->find();
		$ufees=M('ufees');
		$ufee=$ufees->field('total')->where('uid='.$this->_session('user_uid'))->find();
		$systems=$this->systems();
		if(!$this->_post('img')){
			$this->error("证明材料不能为空！");
		}
		if($create=$model->create()){
			$create['data']=",".implode(",",$this->_post('img'));
			$create['time']=time();
			$create['surplus']=$create['money'];
			$create['uid']=$this->_session('user_uid');
			$result = $model->add($create);
			if($result){
				//记录添加点
				$this->userLog('发布【'.$create['title'].'】成功，等待审核',$result);	//会员记录
				$msgTools->sendMsg(3,'会员成功发布【'.$create['title'].'】','会员'.$this->_session('user_name').'成功发布【'.$create['title'].'】，等待管理员审核！','admin',$this->_session('user_name'));//站内信
				$this->success("发标成功","__ROOT__/Center/loan/issue");			
			}else{
				 $this->error("发标失败");
			}
		}else{
			$this->error($model->getError());
			
		}
	}
	
	//普通标编辑
	public function ordinaryEdit(){
		$this->homeVerify();
		//$this->bidValidation();
		$msgTools = A('msg','Event');
		$model=D('Borrowing');
		$money=M('money');
		$mone=$money->where('uid='.$this->_session('user_uid'))->find();
		$ufees=M('ufees');
		$ufee=$ufees->field('total')->where('uid='.$this->_session('user_uid'))->find();
		$systems=$this->systems();
		//各种标条件判断
		if(!$this->_post('img')){
			$this->error("证明材料不能为空！");
		}
		if($create=$model->create()){
			$create['surplus']=$create['money'];
			$create['data']=",".implode(",",$this->_post('img'));
			$result = $model->where(array('id'=>$this->_post('sid')))->save($create);
			if($result){
				//记录添加点
				$this->userLog('【'.$create['title'].'】更新成功，等待审核',$result);	//会员记录
				$msgTools->sendMsg(3,'【'.$create['title'].'】更新成功','会员'.$this->_session('user_name').'成功更新【'.$create['title'].'】，等待管理员审核！','admin',$this->_session('user_name'));//站内信
				$this->success("更新成功");			
			}else{
				 $this->error("更新失败");
			}
		}else{
			$this->error($model->getError());
			
		}
	}
	
	//借款页
	public function welfare(){
		//标题、关键字、描述
		$Site = D("Site");
		$site=$Site->field('keyword,remark,title,link')->where('link="'.$_SERVER['REQUEST_URI'].'"')->find();
		$this->assign('si',$site);
		$active['borrow']='active';
		$this->assign('active',$active);
		$this->display();
    }
	
	//机构担保发布
	public function institution(){
		$this->homeVerify();
		//标题、关键字、描述
		$Site = D("Site");
		$site=$Site->field('keyword,remark,title,link')->where('link="'.$_SERVER['REQUEST_URI'].'"')->find();
		$this->assign('si',$site);
		$active['borrow']='active';
		$this->assign('active',$active);
		$head='<link  href="__PUBLIC__/css/style.css" rel="stylesheet">';
		$this->assign('head',$head);
		//联动值
		$unite=M("unite");
		$deadline=$unite->field('value,name')->where('pid=2')->order('`id` ASC')->select();
		$this->assign('deadline',$deadline);
		$industry=$unite->field('value,name')->where('pid=12')->order('`id` ASC')->select();
		$this->assign('industry',$industry);
		$system=$this->systems();
		$list=explode(",",$system['sys_institution']);
		$this->assign('list',$list);
		$this->display();
    }
	
	//机构担保添加
	public function instadd(){
		$this->add();
	}
	
}