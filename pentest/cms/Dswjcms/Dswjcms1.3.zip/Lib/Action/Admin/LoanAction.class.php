<?php
// +----------------------------------------------------------------------
// | dswjcms
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2014 http://www.tifaweb.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)
// +----------------------------------------------------------------------
// | Author: 宁波市鄞州区天发网络科技有限公司 <dianshiweijin@126.com>
// +----------------------------------------------------------------------
// | Released under the GNU General Public License
// +----------------------------------------------------------------------
defined('THINK_PATH') or exit();
class LoanAction extends AdminCommAction {
//--------待审核-----------
    public function review(){
		$borrow=$this->borrow_unicom(0,'state=0');
		$this->assign('borrow',$borrow);
		$this->display();
    }

//--------普通标显示-----------
	public function index(){
		$linkage=$this->borrowLinkage();
		$this->assign('linkage',$linkage);
		//标题、关键字、描述
		$Site = D("Site");
		$site=$Site->field('keyword,remark,title,link')->where('link="'.$_SERVER['REQUEST_URI'].'"')->find();
		$this->assign('si',$site);
		$active['borrow']='active';
		$this->assign('active',$active);
		$head='<link  href="__PUBLIC__/css/style.css" rel="stylesheet">';
		$this->assign('head',$head);
		$Borrow=D("Borrowing");
		$borrow=$Borrow->where('id='.$this->_get('id'))->find();
		$borrow['data']=array_filter(explode(",",$borrow['data']));
		$this->assign('b',$borrow);
		$this->display();
    }

//--------普通标编辑-----------
	public function ordinaryEdit(){
		$this->homeVerify();
		$msgTools = A('msg','Event');
		$model=D('Borrowing');
		$money=M('money');
		$mone=$money->where('uid='.$this->_post('user_uid'))->find();
		$ufees=M('ufees');
		$ufee=$ufees->field('total')->where('uid='.$this->_post('user_uid'))->find();
		$systems=$this->systems();
		if(!$this->_post('img')){
			$this->error("证明材料不能为空！");
		}
		if($create=$model->create()){
			
			$create['data']=",".implode(",",$this->_post('img'));
			$create['surplus']=$create['money'];
			$result = $model->where(array('id'=>$this->_post('sid')))->save($create);
			if($result){
				//记录添加点
				$this->Record('对'.$create['title'].'的修改');//后台操作
				$this->success("更新成功");			
			}else{
				 $this->error("更新失败");
			}
		}else{
			$this->error($model->getError());
			
		}
	}

	

//--------满标待审核-----------
    public function pending(){
		$borrow=$this->borrow_unicom(0,'state=5');	
		$this->assign('borrow',$borrow);
		$this->display();
    }
//--------贷款列表-----------
    public function entry(){
		$borrow=$this->borrow_unicom();
		$this->assign('borrow',$borrow);
		$this->display();
    }
	//推荐AJAX
	public function entry_stick(){
		$Borrowing=M('borrowing');
		$id=$this->_post('id');
		$stick=$this->_post('stick');
		$data['id']			= $id;
		if(isset($stick)){
		$data['stick']		= $stick;	
		}
		$Borrowing->save($data);
    }
	//审核页
    public function review_page(){
			$id=(int)$this->_get('id');
			$borrow=$this->borrow_information($id);
			$img=array_splice(explode(",",$borrow[0]['data']),1);
			$this->assign('borrow',$borrow);
			$this->assign('img',$img);
			$this->display();
    }
	
	//审核保存
    public function review_validation(){
			$msgTools = A('msg','Event');
			$Borrowing=D('Borrowing');
			$automatic=D('Automatic');
			$system=$this->systems();
            if(!$Borrowing->create()){
                    $this->error($Borrowing->getError());
            }
			$create=$Borrowing->create();
			$Borrow = $Borrowing->relation(true)->where('id='.$create['id'])->select();		
			$create['checktime']			=time();	//审核时间
			$create['endtime']			=time()+86400*$Borrow[0]['valid'];	//失效时间
			if($Borrow[0]['type']==7){	//流转标计算最终到期时间
				if($Borrow[0]['candra']==0){	//获取用户选择的是月标还是天标
					$month=$Borrow[0]['deadline'];
					$create['limittime']=strtotime("+$month month");
				}else{
					$day=$Borrow[0]['deadline'];
					$create['limittime']=strtotime("+$day day");
				}
			}
           if($Borrow[0]['type']==0){	//秒还标
				$counters=$this->counters($Borrow[0]['money'],$Borrow[0]['rates'],$Borrow[0]['deadline'],$Borrow[0]['candra'],$Borrow[0]['way']);	//利息计算
				if($Borrow[0]['reward_type']==1){	//金额
					$reward=$Borrow[0]['reward'];
				}else if($Borrow[0]['reward_type']==2){	//百分比
					$reward=$Borrow[0]['reward']*0.01*$Borrow[0]['money'];
				}
				$models = new Model();
				$models->query("UPDATE `ds_money` SET `available_funds` = `available_funds`-".($counters['interest']+$reward).", `freeze_funds` = `freeze_funds`+".($counters['interest']+$reward)." WHERE `uid` =".$Borrow[0]['uid']);
		   }
			$Borrowing->save($create);
			if($this->_post('state')==1){	//判断审核状态
				$stat=$state="通过";
				if($Borrow[0]['type']==0){	//秒还标
					$money=M('money');
					$moneys=$money->where('uid='.$Borrow[0]['uid'])->find();	
					$this->moneyLog(array(0,'【'.$Borrow[0]['title'].'】审核通过冻结资金',($counters['interest']+$reward),'平台',$moneys['total_money'],$moneys['available_funds'],$moneys['freeze_funds'],$Borrow[0]['uid']));	//资金记录
				}
			}else{
				$state="失败";
				$stat="失败<br>失败原因：".$Borrow['review_note'];
			}
			//记录添加点
			$this->Record('对'.$Borrow[0]['title'].'的审核');//后台操作
			$this->userLog($Borrow[0]['title'].'审核'.$state,$Borrow[0]['uid']);	//会员记录
			$msgTools->sendMsg(3,$Borrow[0]['title'].'审核'.$state,'<a href="'.__APP__.'/Loan/invest/'.$Borrow[0]['id'].'.html">【'.$Borrow[0]['title'].'】</a>'.'审核'.$stat,'admin',$Borrow[0]['uid']);//站内信
			//邮件通知
			$mailNotice['uid']=$Borrow[0]['uid'];
			$mailNotice['title']='【'.$Borrow[0]['title'].'】 审核通知';
			$mailNotice['content']='
				<div style="margin: 6px 0 60px 0;">
					<p>您申请的贷款审核状态：</p>
					<p>【'.$Borrow[0]['title'].'】 审核'.$stat.'</p>
					<p><a href="http://'.$_SERVER['HTTP_HOST'].__APP__.'/Loan/invest/'.$Borrow[0]['id'].'.html">http://'.$_SERVER['HTTP_HOST'].__APP__.'/Loan/invest/'.$Borrow[0]['id'].'.html</a></p>
					<p>如果您的邮箱不支持链接点击，请将以上链接地址拷贝到你的浏览器地址栏中。</p>
				</div>
				<div style="color: #999;">
					<p>发件时间：'.date('Y/m/d H:i:s').'</p>
					<p>此邮件为系统自动发出的，请勿直接回复。</p>
				</div>';
			$this->mailNotice($mailNotice);
			$this->success('审核成功', '__URL__/entry');
			
    }
	
	/*
	*
	*复审
	*
	*/
	public function borrowUpda(){
		$sid=intval($this->_post('id'));
		$state=intval($this->_post('state'));
		$borr=$this->borr($sid);
		$model = M('borrowing');
		if($borr['candra']==0){	//获取用户选择的是月标还是天标
			$month=$borr['deadlinea'];
			$limittime=strtotime("+$month month");
		}else{
			$day=$borr['deadlinea'];
			$limittime=strtotime("+$day day");
		}
		$create['reviewtime']			=time();
		$create['limittime']			=$limittime;	//逾期时间
		$create['state']				=$state;
		$result = $model->where(array('id'=>$sid))->save($create);
		$borr['state']=$state;	//获取审核状态
		if($result){
			 $this->fullApproval($borr);
			 $this->Record('对'.$borr['title'].'的复审通过');//后台操作
			 //$this->success('复审通过',$u);
			 echo '<p class="green">复审通过</p>';
			echo '<p class="jump">
			页面自动 <a href="'.__ROOT__.'/Admin/Loan/pending.html">跳转</a> 等待时间： <b>3秒</b>
			</p>';
			
		}else{
			$this->Record('对'.$borr['title'].'的复审失败');//后台操作
			//$this->error("复审失败");
			echo '<p class="red">复审失败！</p>';
			echo '<p class="jump">
			页面自动 <a href="'.__ROOT__.'/Admin/Loan/pending.html">跳转</a> 等待时间： <b>3秒</b>
			</p>';
			}			 			
	}
	
		
	//导出EXCEL
	public function integExport(){
		$typ=$this->_post('type');
		$stat=$this->_post('state');
		$type=($typ=='0' || $typ)?"type=".$typ:'';
		$state=($stat=='0' || $stat)?"state=".$stat:'';
		$where=trim($type." and ".$state,' and ');
		$list=$borrow=$this->borrow_unicom(0,$where);
		$data['title']="贷款列表";
		$data['name']=array(
							array('n'=>'用户名','u'=>'username'),
							array('n'=>'标题','u'=>'title'),
							array('n'=>'金额','u'=>'money'),
							array('n'=>'利率','u'=>'rates'),
							array('n'=>'期限','u'=>'deadlines'),
							array('n'=>'类型','u'=>'type_name'),
							array('n'=>'状态','u'=>'state_name')
							);
		foreach($list as $l){
			$content[]=array(
							'username'		=>$l['username'],
							'title'			=>$l['title'],
							'money'			=>$l['money'],
							'rates'			=>$l['rates'],
							'deadlines'		=>$l['deadlines'],
							'type_name'		=>$l['type_name'],
							'state_name'	=>$l['state_name']
							);
		}
		$data['content']=$content;
		$excel=$this->excelExport($data);
			$this->Record('导出“贷款列表”');//后台操作
			$this->success("导出成功","__URL__/entry");
		
	}
	
	//用户编辑显示AJAX
     public function userajax(){
		$id=$this->_post("id");
		$borrow=$this->borrow_information($id);
		$tmp.='
			<div class="modal-body">
    <table class="table table-striped table-bordered table-condensed">
    <tbody>
    <tr><th>会员ID：</th><td>'.$borrow[0]['id'].'</td><th>用户名：</th><td>'.$borrow[0]['username'].'</td></tr>
    <tr><th>真实姓名：</th><td>'.$borrow[0]['name'].'</td><th>性别：</th><td>'.$borrow[0]['gender'].'</td></tr>
    <tr><th>民族：</th><td>'.$borrow[0]['national'].'</td><th>出生日期：</th><td>'.date('Y-m-d H:i:s',$borrow[0]['born']).'</td></tr>
    <tr><th>身份证：</th><td>'.$borrow[0]['idcard'];
	foreach($borrow[0]['idcard_img'] as $id=>$img){
		$tmp.='&nbsp;&nbsp;&nbsp;&nbsp;<a href="/Public/uploadify/uploads/idcard/'.$img.'" class="cboxElement">证件'.($id+1).'</a>';
	}
	$tmp.='</td><th>籍贯：</th><td>'.$borrow[0]['native_place'].'</td></tr>
    <tr><th>所在地：</th><td>'.$borrow[0]['location'].'</td><th>婚姻状况：</th><td>'.$borrow[0]['marriage'].'</td></tr>
    <tr><th>学历：</th><td>'.$borrow[0]['education'].'</td><th>月收入：</th><td>'.$borrow[0]['monthly_income'].'</td></tr>
    <tr><th>住房条件：</th><td>'.$borrow[0]['housing'].'</td><th>购车情况：</th><td>'.$borrow[0]['buy_cars'].'</td></tr>
    <tr><th>行业：</th><td>'.$borrow[0]['industry'].'</td><th>公司：</th><td>'.$borrow[0]['company'].'</td></tr>
    <tr><th>QQ：</th><td>'.$borrow[0]['qq'].'</td><th>邮箱：</th><td>'.$borrow[0]['email'].'</td></tr>
    <tr><th>固话：</th><td>'.$borrow[0]['fixed_line'].'</td><th>手机：</th><td>'.$borrow[0]['cellphone'].'</td></tr>
    <tr><!--<th>微信：</th><td>'.$borrow[0]['wechat'].'</td>--><th>认证：</th>
	<td>';
	if($borrow[0]['email_audit']>1){
		$tmp.='<a class="icon icon-orange icon-envelope-closed ajax-link" href="#"  data-rel="tooltip" title="邮箱已认证"></a>';
	}else{
		$tmp.='<a class="icon icon-envelope-closed ajax-link" href="#" data-rel="tooltip" title="邮箱未认证"></a>';
	}
	if($borrow[0]['certification']>1){
		$tmp.='<a class="icon icon-orange icon-profile" href="#"  data-rel="tooltip" title="实名已认证"></a>';
	}else{
		$tmp.='<a class="icon icon-profile" href="#" data-rel="tooltip" title="实名未认证"></a>';
	}
	if($borrow[0]['video_audit']>1){
		$tmp.='<a class="icon icon-orange icon-comment-video ajax-link" href="#"  data-rel="tooltip" title="视频已认证"></a>';
	}else{
		$tmp.='<a class="icon icon-comment-video ajax-link" href="#" data-rel="tooltip" title="视频未认证"></a>';
	}
	if($borrow[0]['site_audit']>1){
		$tmp.='<a class="icon icon-orange icon-users ajax-link" href="#"  data-rel="tooltip" title="现场已认证"></a>';
	}else{
		$tmp.='<a class="icon icon-users ajax-link" href="#" data-rel="tooltip" title="现场未认证"></a>';
	}
	if($borrow[0]['cellphone_audit']>1){
		$tmp.='<a class="icon icon-orange icon-cellphone ajax-link" href="#"  data-rel="tooltip" title="手机已认证"></a>';
	}else{
		$tmp.='<a class="icon icon-cellphone ajax-link" href="#" data-rel="tooltip" title="手机未认证"></a>';
	}
	$tmp.='</td>
	<th></th><td></td><th>
	</tr>
    
	</tbody>
    </table>
 
    </div>
		';
		echo $tmp;
    }
	
	//--------待审核-----------
    public function overduebid(){
		$overdue=$this->verdue();//逾期信息
		$this->assign('audit',$overdue);
		$endjs='
//编辑
function edit(id){
	var loading=\'<div class="invest_loading"><div><img src="__PUBLIC__/bootstrap/img/ajax-loaders/ajax-loader-1.gif"/></div><div>加载中...</div> </div>\';
	$(".integral_subject").html(loading);
		$("#edits").load("__URL__/userajax", {id:id});
}
		';
		$this->assign('endjs',$endjs);
		$this->display();
	}
	
	/**
	* @标信息
	* @id		单条借款传入ID
	* @作者		shop猫
	* @版权		宁波天发网络
	* @官网		http://www.tifaweb.com http://www.dswjcms.com
	*/
	public function borrows($id){
		$borrowing = M("borrowing");
		return $borrowing->where('id='.$id)->field('stick,state')->find();
	}
	
	
	//投资记录
	public function irecord(){
		$record=$this->bRecord();
		$this->assign('record',$record);
		$this->display();
	}
	
	//导出EXCEL(投资记录)
	public function recordExport(){
		$list=$this->bRecord();
		$data['title']="投资记录";
		$data['name']=array(
							array('n'=>'ID','u'=>'id'),
							array('n'=>'用户ID','u'=>'uid'),
							array('n'=>'用户组','u'=>'type'),
							array('n'=>'总金额','u'=>'total'),
							array('n'=>'可用金额','u'=>'available'),
							array('n'=>'操作金额','u'=>'operation'),
							array('n'=>'操作说明','u'=>'instructions'),
							);
		foreach($list as $l){
			switch($l['type']){
				case 1:
				$type="借款标发布";
				break;
				case 2:
				$type="借款标审核后";
				break;
				case 3:
				$type="借款中投资人操作";
				break;
				case 4:
				$type="借款中借款人操作";
				break;
				case 5:
				$type="复审中投资人操作";
				break;
				case 6:
				$type="复审中借款人操作";
				break;
				case 7:
				$type="复审后投资人操作";
				break;
				case 8:
				$type="复审后借款人操作";
				break;
				case 9:
				$type="借款到期收款";
				break;
				case 10:
				$type="借款到期还款";
				break;
				case 11:
				$type="逾期";
				break;
				case 12:
				$type="提现";
				break;
				case 15:
				$type="流转标投资人操作";
				break;
				case 16:
				$type="流转标借款人操作";
				break;
				case 17:
				$type="流标";
				break;
			}
			$content[]=array(
							'id'				=>' '.$l['id'],
							'uid'				=>' '.$l['actionname']['uid'],
							'type'				=>$type,
							'total'				=>$l['actionname']['total'],
							'available'			=>$l['actionname']['available'],
							'operation'			=>$l['actionname']['operation'],
							'instructions'		=>strip_tags($l['actionname']['instructions'])
							);
		}
		$data['content']=$content;
		$excel=$this->excelExport($data);
		$this->Record('投资记录导出成功');//后台操作
			$this->success("导出成功","__URL__/record.html");
		
	}
}
?>