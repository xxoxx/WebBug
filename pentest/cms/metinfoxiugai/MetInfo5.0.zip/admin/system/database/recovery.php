<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 
$depth='../';
require_once $depth.'../login/login_check.php';
require_once 'global.func.php';
$listclass[2]='class="now"';
$rurls='../system/database/recovery.php?anyid='.$anyid.'&lang='.$lang;
if($action=='delete'){
    if(is_array($filenames)) {
        foreach($filenames as $filename){
            if(fileext($filename)=='sql'){
				if(substr_count(trim($filename),'../'))die('met2');
                @unlink('../databack/'.$filename);
            }
        }
    }else{
	if(substr_count(trim($filenames),'../'))die('met2');
        if(fileext($filenames)=='sql'){
		$filenamearray=explode(".sql",$filenames);
            @unlink('../../databack/'.$filenames);
			@unlink('../../databack/sql/metinfo_'.$filenamearray[0].".zip");
        }else{
		    @unlink('../../databack/'.$fileon.'/'.$filenames);
		}
    }
	metsave($rurls,'',$depth);
}elseif($dosubmit){
	$fileid = $fileid ? $fileid : 1;
	$filename = $pre.$fileid.'.sql';
	$filepath = '../../databack/'.$filename;
	if(file_exists($filepath)){
		$sql = file_get_contents($filepath);
		if(substr($sql,28,3)!='5.0')metsave($rurls,$lang_dataerr1,$depth);
		sql_execute($sql);
		$fileid++;
		metsave($rurls."&pre=".$pre."&fileid=".$fileid."&dosubmit=1","{$lang_setdbDBFile} {$filename} {$lang_setdbImportOK}{$lang_setdbImportcen}",$depth,'','',1);
	}else{
		require_once '../../column/global.func.php';
		$query="select * from $met_column where ((module<=5 and module>0) or (module=8)) and (classtype=1 or releclass!=0)";
		$result= $db->get_all($query);
		$sysflie=array(1=>'about',2=>'news',3=>'product',4=>'download',5=>'img',6=>'job',7=>'message',8=>'feedback');
		foreach($result as $key=>$val){
			if(array_search($val[foldername],$sysflie)===false){
				if(!file_exists(ROOTPATH.$val['foldername']))@mkdir(ROOTPATH.$val['foldername'], 0777); 
				column_copyconfig($val['foldername'],$val['module'],$val['id']);
			}
		}
		deldir(ROOTPATH.'cache');	
		metsave($rurls,$lang_setdbDBRestoreOK,$depth,'','',2);
	}
}else{
	$sqlfiles = glob('../../databack/*.sql');
	if(is_array($sqlfiles)){
		 $prepre = '';
		 $info = $infos = array();
		 foreach($sqlfiles as $id=>$sqlfile){
			preg_match("/([a-z0-9_]+_[0-9]{8}_[0-9a-z]{4}_)([0-9]+)\.sql/i",basename($sqlfile),$num);
			$info['filename'] = basename($sqlfile);
			$info['filesize'] = round(filesize($sqlfile)/(1024*1024), 2);
			$info['maketime'] = date('Y-m-d H:i:s', filemtime($sqlfile));
			$info['pre'] = $num[1];
			$info['number'] = $num[2];
			if(!$id) $prebgcolor = '#E4EDF9';
			if($info['pre'] == $prepre){
				$info['bgcolor'] = $prebgcolor;
			}else{
				$info['bgcolor'] = $prebgcolor == '#E4EDF9' ? '#F1F3F5' : '#E4EDF9';
			}
			$prebgcolor = $info['bgcolor'];
			$prepre = $info['pre'];
			$infos[] = $info;
		}
	}
	foreach($infos as $key=>$val){
		$val['time']=strtotime($val['maketime']);
		$infos1[]=$val;
	}
	function array_sort($arr,$keys,$type='asc'){ 
		$keysvalue = $new_array = array();
		foreach ($arr as $k=>$v){
			$keysvalue[$k] = $v[$keys];
		}
		if($type == 'asc'){
			asort($keysvalue);
		}else{
			arsort($keysvalue);
		}
		reset($keysvalue);
		foreach ($keysvalue as $k=>$v){
			$new_array[$k] = $arr[$k];
		}
		return $new_array; 
	} 
	$infos=array_sort($infos1,'time','we');
	$css_url=$depth."../templates/".$met_skin."/css";
	$img_url=$depth."../templates/".$met_skin."/images";
	include_once template('system/database/recovery');footer();
}
# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>