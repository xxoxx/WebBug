<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 
require_once '../login/login_check.php';
require_once ROOTPATH.'include/export.func.php';
$authurlself=$_SERVER ['HTTP_HOST'];
$authcode=trim($authcode);
$authpass=trim($authpass);
$cs=isset($cs)?$cs:1;
$listclass[$cs]='class="now"';
$rurls='../system/authcode.php?anyid='.$anyid.'&cs='.$cs.'&lang='.$lang;
if($action=="modify"){
	$authurl=authcode($authcode, 'DECODE', $authpass);
	$authurl=explode("|",$authurl);
	foreach($authurl as $val){
		if(strstr($_SERVER ['HTTP_HOST'],$val)){
			$query ="update $met_otherinfo set 
				  authpass    ='$authpass',
				  authcode    ='$authcode',
				  authtext    ='{$lang_authTip3}'
				  where id='1'";
			$db->query($query);
			metsave($rurls,$lang_jsok);
		}
	}
	metsave($rurls,$lang_authTip2);
}else{
	$authinfo = $db->get_one("SELECT * FROM $met_otherinfo where id=1");
	if(!$authinfo){
		metsave('-1',$lang_dataerror);
	}
	if($authinfo[authcode]=='')$authinfo[authcode]="{$lang_authTip4}";
}
if($cs==1){
	$met_file='/authorize.php';
	$authinfo=$db->get_one("SELECT * FROM $met_otherinfo where id=1");
	if($authinfo['authcode']&&$authinfo['authpass']){
		$post_data = array('met_code'=>$authinfo['authcode'],'met_key'=>$authinfo['authpass']);
		$info=curl_post($post_data,30);
		$usertemp=explode('|',$info);
		if($usertemp[0]!='NOUSER'){
			$user['domain']=$usertemp[1];
			$user['webname']=$usertemp[3];
			$user['type']=$usertemp[2];
			$user['buytime']=date('Y-m-d',$usertemp[4]);
			$user['lifetime']=$user['lifetime']?date('Y-m-d',$usertemp[5]):'永久';
			$user['service']=$usertemp[6];
		}
	}
	else{
		$usertemp[0]='NOUSER';
	}
	if($autcod){
		echo $user['type'];
		die;
	}
}
$rooturl="..";
$css_url="../templates/".$met_skin."/css";
$img_url="../templates/".$met_skin."/images";
include template('system/authcode');
footer();
# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>