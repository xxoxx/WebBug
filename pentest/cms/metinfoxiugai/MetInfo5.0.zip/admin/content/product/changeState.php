<?php
# MetInfo Enterprise Content Management System 
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved. 
$depth='../';
require_once $depth.'../login/login_check.php';
$backurl="../content/product/index.php?anyid={$anyid}&lang=$lang&class1=$class1&class2=$class2&class3=$class3";
if($action=='copy'){
	$query= "select * from $met_column where id='$copyclass1'";
	$result1=$db->get_one($query);
	if(!$result1){
		metsave('-1',$lang_dataerror,$depth);
		exit();
	}
	$allidlist=explode(',',$allid);
	$k=count($allidlist)-1;
	for($i=0;$i<$k; $i++){
		$query = "insert into {$met_product} select '',title,ctitle,keywords,description,content,'{$copyclass1}','{$copyclass2}','{$copyclass3}',no_order,wap_ok,new_ok,imgurl,imgurls,displayimg,com_ok,hits,updatetime,addtime,issue,access,top_ok,'','{$copylang}',content1,content2,content3,content4,contentinfo,contentinfo1,contentinfo2,contentinfo3,contentinfo4,recycle  from {$met_product} where id='{$allidlist[$i]}'";
		$db->query($query);
	}
	metsave($backurl,'',$depth);
}elseif($action=="moveto"){
	$allidlist=explode(',',$allid);
	$k=count($allidlist)-1;
	$query= "select * from $met_column where id='$moveclass1'";
	$result1=$db->get_one($query);
	if(!$result1){
		metsave('-1',$lang_dataerror,$depth);
		exit();
	}
	for($i=0;$i<$k; $i++){
		$filname= '';
		if($movelang!=$lang)$filname = "filename = '',";
		$query = "update {$met_product} SET";
		$query = $query."
						  class1             = '$moveclass1',
						  class2             = '$moveclass2',
						  class3             = '$moveclass3',
						  access             = '$access',
						  {$filname}
						  lang               = '$movelang'";
		$query = $query." where id='$allidlist[$i]'";
		$db->query($query);
	}
	metsave($backurl,'',$depth);
}else{
	$admin_list = $db->get_one("SELECT * FROM $met_product WHERE id='$id'");
	if(!$admin_list)metsave('-1',$lang_loginNoid,$depth);
	$query = "update $met_product SET ";
	if(isset($new_ok)){
		$new_ok=$new_ok==1?0:1;
		$query = $query."new_ok             = '$new_ok',";
	}
	if(isset($com_ok)){
		$com_ok=$com_ok==1?0:1;
		$query = $query."com_ok             = '$com_ok',";
	}
	if(isset($top_ok)){
		$top_ok=$top_ok==1?0:1;
		$query = $query."top_ok             = '$top_ok',";
	}
	if(isset($wap_ok)){
		$wap_ok=$wap_ok==1?0:1;
		$query = $query."wap_ok             = '$wap_ok',";
	}
	$query = $query."id='$id' where id='$id'";
	$db->query($query);
	if($top_ok==1)$page=0;
	metsave("../content/product/index.php?anyid={$anyid}&lang=$lang&class1=$class1&class2=$class2&class3=$class3".'&modify='.$id.'&page='.$page,'',$depth);
}

# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>
